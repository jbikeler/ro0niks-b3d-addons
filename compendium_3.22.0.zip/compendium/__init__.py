# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Compendium",
    "author" : "Ben Ikeler", 
    "description" : "",
    "blender" : (5, 2, 0),
    "version" : (3, 22, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
from bpy.app.handlers import persistent
import math
import gpu
from mathutils import Vector
from bpy_extras.view3d_utils import region_2d_to_location_3d, region_2d_to_vector_3d
import os
import numpy as np


addon_keymaps = {}
_icons = None
mirrorempty = {'sna_objectname': '', 'sna_newempty': '', 'sna_foundobject': False, 'sna_modname': '', }
pie__sculpt = {'sna_brushpath': '', }


def find_user_keyconfig(key):
    km, kmi = addon_keymaps[key]
    for item in bpy.context.window_manager.keyconfigs.user.keymaps[km.name].keymap_items:
        found_item = False
        if kmi.idname == item.idname:
            found_item = True
            for name in dir(kmi.properties):
                if not name in ["bl_rna", "rna_type"] and not name[0] == "_":
                    if name in kmi.properties and name in item.properties and not kmi.properties[name] == item.properties[name]:
                        found_item = False
        if found_item:
            return item
    print(f"Couldn't find keymap item for {key}, using addon keymap instead. This won't be saved across sessions!")
    return kmi


def sna_formatchangelog_2DFCA_38FC2():
    return 'Changelog Version ' + str(tuple(tuple(bpy.context.scene.sn.version))).replace('(', '').replace(')', '').replace(',', '.').replace(' ', '') + ':'


def sna_getobjectproperty_427FF_5BA5F(ObjectName):
    return bpy.data.objects[ObjectName]


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


def sna_add_to_view3d_mt_editor_menus_C65F5(self, context):
    if not ((not 'PAINT_WEIGHT'==bpy.context.mode)):
        layout = self.layout
        op = layout.operator('sna.open_weight_paint_info_96579', text='', icon_value=147, emboss=True, depress=False)


class SNA_MT_D7A07(bpy.types.Menu):
    bl_idname = "SNA_MT_D7A07"
    bl_label = "Weight Paint Info"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.operator_context = "INVOKE_DEFAULT"
        col_2F27A = layout.column(heading='', align=False)
        col_2F27A.alert = False
        col_2F27A.enabled = True
        col_2F27A.active = True
        col_2F27A.use_property_split = False
        col_2F27A.use_property_decorate = False
        col_2F27A.scale_x = 1.0
        col_2F27A.scale_y = 1.0
        col_2F27A.alignment = 'Expand'.upper()
        col_2F27A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_2F27A.label(text='Mirror Notes', icon_value=215)
        col_2F27A.label(text='Brush will mirror only X', icon_value=69)
        col_2F27A.label(text='Bones that you want to mirror need the the same name and an L or R suffix ( _ or . )', icon_value=69)
        col_2F27A.label(text='To mirror weight paint to the other side after painting:', icon_value=69)
        col_2F27A.label(text='- Weight Paint Mode > Bone Selection > Select bone you want the weight paint to be copied FROM', icon_value=0)
        col_2F27A.label(text='- Edit Mode OR Weight Paint Mode with Vertex Selection > Select verts that you want weight to be copied TO', icon_value=0)
        col_2F27A.label(text='- Weight Paint Mode  > Vertex Selection', icon_value=0)
        col_2F27A.label(text='- Weights > Mirror > (Be sure Mirror Weight, Flip Group Names, and All Groups are checked in popup)', icon_value=0)
        col_2F27A.label(text='- Other bone should have mirrored weight', icon_value=0)
        op = col_2F27A.operator('sna.open_weight_paint_info_links_4d4c6', text='Weight Paint Info Links', icon_value=0, emboss=True, depress=False)


class SNA_OT_Open_Weight_Paint_Info_96579(bpy.types.Operator):
    bl_idname = "sna.open_weight_paint_info_96579"
    bl_label = "Open Weight Paint Info"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.wm.call_menu(name="SNA_MT_D7A07")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Open_Weight_Paint_Info_Links_4D4C6(bpy.types.Operator):
    bl_idname = "sna.open_weight_paint_info_links_4d4c6"
    bl_label = "Open Weight Paint Info Links"
    bl_description = "Open weight paint information in browser tabs"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('bpy.ops.wm.url_open(url="https://www.youtube.com/watch?v=Ha_YU5xJsSc")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_outliner_ht_header_A76C5(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('outliner.show_active', text='', icon_value=16, emboss=True, depress=False)


def sna_add_to_view3d_mt_curve_add_7FD4D(self, context):
    if not (False):
        layout = self.layout
        layout.separator(factor=1.0)
        op = layout.operator('sna.add_bezier_pipe_e6f6d', text='Bezier Pipe', icon_value=460, emboss=True, depress=False)
        op = layout.operator('sna.add_bezier_rectangle_f8009', text='Bezier Rectangle', icon_value=719, emboss=True, depress=False)
        op = layout.operator('sna.add_empty_curve_43edf', text='Empty Curve', icon_value=263, emboss=True, depress=False)


def sna_add_to_view3d_mt_mesh_add_86EDB(self, context):
    if not (False):
        layout = self.layout
        layout.separator(factor=1.0)
        op = layout.operator('sna.add_single_vert_bfe7d', text='Signal Vert', icon_value=69, emboss=True, depress=False)
        op = layout.operator('sna.add_edge_2ddef', text='Single Edge', icon_value=494, emboss=True, depress=False)


class SNA_PT_COMPENDIUM_A8331(bpy.types.Panel):
    bl_label = 'Compendium'
    bl_idname = 'SNA_PT_COMPENDIUM_A8331'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_83AF6 = layout.column(heading='', align=False)
        col_83AF6.alert = False
        col_83AF6.enabled = True
        col_83AF6.active = True
        col_83AF6.use_property_split = False
        col_83AF6.use_property_decorate = False
        col_83AF6.scale_x = 1.0
        col_83AF6.scale_y = 1.0
        col_83AF6.alignment = 'Expand'.upper()
        col_83AF6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_FC6E1 = col_83AF6.row(heading='', align=False)
        row_FC6E1.alert = False
        row_FC6E1.enabled = True
        row_FC6E1.active = True
        row_FC6E1.use_property_split = False
        row_FC6E1.use_property_decorate = False
        row_FC6E1.scale_x = 1.0
        row_FC6E1.scale_y = 1.0
        row_FC6E1.alignment = 'Expand'.upper()
        row_FC6E1.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_FC6E1.label(text='Control Panel', icon_value=0)
        row_17323 = row_FC6E1.row(heading='', align=False)
        row_17323.alert = False
        row_17323.enabled = True
        row_17323.active = True
        row_17323.use_property_split = False
        row_17323.use_property_decorate = False
        row_17323.scale_x = 1.0
        row_17323.scale_y = 1.0
        row_17323.alignment = 'Right'.upper()
        row_17323.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_17323.operator('sna.toggle_settings_04ec7', text='', icon_value=154, emboss=True, depress=bpy.context.scene.sna_showrendersettings)
        split_70E87 = col_83AF6.split(factor=0.5, align=True)
        split_70E87.alert = False
        split_70E87.enabled = True
        split_70E87.active = True
        split_70E87.use_property_split = False
        split_70E87.use_property_decorate = False
        split_70E87.scale_x = 1.0
        split_70E87.scale_y = 1.0
        split_70E87.alignment = 'Expand'.upper()
        if not True: split_70E87.operator_context = "EXEC_DEFAULT"
        op = split_70E87.operator('sna.toggle_tools_f006f', text='', icon_value=131, emboss=True, depress=bpy.context.scene.sna_showtools)
        op = split_70E87.operator('sna.toggle_workflow_panel_c058b', text='', icon_value=245, emboss=True, depress=bpy.context.scene.sna_showworkflow)
        split_EDA05 = col_83AF6.split(factor=1.0, align=True)
        split_EDA05.alert = False
        split_EDA05.enabled = True
        split_EDA05.active = True
        split_EDA05.use_property_split = False
        split_EDA05.use_property_decorate = False
        split_EDA05.scale_x = 1.0
        split_EDA05.scale_y = 1.0
        split_EDA05.alignment = 'Expand'.upper()
        if not True: split_EDA05.operator_context = "EXEC_DEFAULT"
        op = split_EDA05.operator('sna.toggle_item_info_b0c71', text='', icon_value=147, emboss=True, depress=bpy.context.scene.sna_showiteminfo)


class SNA_OT_Toggle_Tools_F006F(bpy.types.Operator):
    bl_idname = "sna.toggle_tools_f006f"
    bl_label = "Toggle Tools"
    bl_description = "Show Tools Panel"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showtools = (not bpy.context.scene.sna_showtools)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Settings_04Ec7(bpy.types.Operator):
    bl_idname = "sna.toggle_settings_04ec7"
    bl_label = "Toggle Settings"
    bl_description = "Show Settings Panel"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showrendersettings = (not bpy.context.scene.sna_showrendersettings)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Item_Info_B0C71(bpy.types.Operator):
    bl_idname = "sna.toggle_item_info_b0c71"
    bl_label = "Toggle Item Info"
    bl_description = "Show Item Info Panel"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showiteminfo = (not bpy.context.scene.sna_showiteminfo)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Workflow_Panel_C058B(bpy.types.Operator):
    bl_idname = "sna.toggle_workflow_panel_c058b"
    bl_label = "Toggle Workflow Panel"
    bl_description = "Show  Workflow Panel"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showworkflow = (not bpy.context.scene.sna_showworkflow)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_view3d_ht_tool_header_6C6E7(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.opensidepanel_55c7a', text='Compendium', icon_value=0, emboss=True, depress=False)


class SNA_MT_A3D1B(bpy.types.Menu):
    bl_idname = "SNA_MT_A3D1B"
    bl_label = "Compendium"

    @classmethod
    def poll(cls, context):
        return not ((not ('OBJECT'==bpy.context.mode or 'EDIT_MESH'==bpy.context.mode)))

    def draw(self, context):
        layout = self.layout.menu_pie()
        if 'EDIT_MESH'==bpy.context.mode:
            if bpy.context.tool_settings.mesh_select_mode[0]:
                op = layout.operator('mesh.dissolve_verts', text='Dissolve Verts', icon_value=0, emboss=True, depress=False)
            else:
                if bpy.context.tool_settings.mesh_select_mode[1]:
                    op = layout.operator('mesh.dissolve_edges', text='Dissolve Edges', icon_value=0, emboss=True, depress=False)
                    op.use_verts = True
                else:
                    op = layout.operator('mesh.delete', text='Delete Faces Only', icon_value=0, emboss=True, depress=False)
                    op.type = 'ONLY_FACE'
        else:
            if (bpy.data.scenes['Scene'].transform_orientation_slots[0].type == 'GLOBAL'):
                op = layout.operator('sna.set_orientation_transform_97638', text='Local', icon_value=611, emboss=True, depress=False)
                op.sna_transformid = 'LOCAL'
            else:
                op = layout.operator('sna.set_orientation_transform_97638', text='Global', icon_value=610, emboss=True, depress=False)
                op.sna_transformid = 'GLOBAL'
        if (bpy.data.scenes['Scene'].transform_orientation_slots[0].type == 'CURSOR'):
            op = layout.operator('sna.set_orientation_global_and_pivot_median_465f2', text='Orient to Global', icon_value=610, emboss=True, depress=False)
        else:
            op = layout.operator('sna.set_orientation_cursor_acb4a', text='Orient to Cursor', icon_value=623, emboss=True, depress=False)
        if 'EDIT_MESH'==bpy.context.mode:
            if sna_fngetactive_F6274():
                op = layout.operator('mesh.merge', text='At Last', icon_value=0, emboss=True, depress=False)
                op.type = 'LAST'
            else:
                if bpy.context.tool_settings.mesh_select_mode[2]:
                    op = layout.operator('mesh.select_linked', text='Select Linked', icon_value=0, emboss=True, depress=False)
                else:
                    layout.separator(factor=1.0)
        else:
            layout.separator(factor=1.0)
        if 'OBJECT'==bpy.context.mode:
            layout.prop(bpy.data.scenes['Scene'].tool_settings, 'use_snap', text='', icon_value=0, emboss=True)
        else:
            row_3550D = layout.row(heading='', align=True)
            row_3550D.alert = False
            row_3550D.enabled = True
            row_3550D.active = True
            row_3550D.use_property_split = False
            row_3550D.use_property_decorate = False
            row_3550D.scale_x = 1.2000000476837158
            row_3550D.scale_y = 1.5
            row_3550D.alignment = 'Expand'.upper()
            row_3550D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_3550D.prop(bpy.data.scenes['Scene'].tool_settings, 'use_mesh_automerge', text='', icon_value=0, emboss=True)
            row_3550D.prop(bpy.data.scenes['Scene'].tool_settings, 'use_proportional_edit', text='', icon_value=0, emboss=True)
            row_3550D.prop(bpy.data.scenes['Scene'].tool_settings, 'use_snap', text='', icon_value=0, emboss=True)
        col_68C1A = layout.column(heading='', align=False)
        col_68C1A.alert = False
        col_68C1A.enabled = True
        col_68C1A.active = True
        col_68C1A.use_property_split = False
        col_68C1A.use_property_decorate = False
        col_68C1A.scale_x = 1.0
        col_68C1A.scale_y = 1.0
        col_68C1A.alignment = 'Expand'.upper()
        col_68C1A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_AC21F = col_68C1A.row(heading='', align=True)
        row_AC21F.alert = False
        row_AC21F.enabled = True
        row_AC21F.active = True
        row_AC21F.use_property_split = False
        row_AC21F.use_property_decorate = False
        row_AC21F.scale_x = 1.2000000476837158
        row_AC21F.scale_y = 1.5
        row_AC21F.alignment = 'Expand'.upper()
        row_AC21F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        if 'EDIT_MESH'==bpy.context.mode:
            if (bpy.data.scenes['Scene'].transform_orientation_slots[0].type == 'GLOBAL'):
                op = row_AC21F.operator('sna.set_orientation_transform_97638', text='', icon_value=611, emboss=True, depress=False)
                op.sna_transformid = 'LOCAL'
            else:
                op = row_AC21F.operator('sna.set_orientation_transform_97638', text='', icon_value=610, emboss=True, depress=False)
                op.sna_transformid = 'GLOBAL'
        else:
            op = row_AC21F.operator('sna.set_orientation_transform_97638', text='', icon_value=549, emboss=True, depress=False)
            op.sna_transformid = 'PARENT'
        op = row_AC21F.operator('sna.set_orientation_transform_97638', text='', icon_value=612, emboss=True, depress=False)
        op.sna_transformid = 'NORMAL'
        op = row_AC21F.operator('sna.set_orientation_transform_97638', text='', icon_value=623, emboss=True, depress=False)
        op.sna_transformid = 'CURSOR'
        row_33CC2 = col_68C1A.row(heading='', align=True)
        row_33CC2.alert = False
        row_33CC2.enabled = True
        row_33CC2.active = True
        row_33CC2.use_property_split = False
        row_33CC2.use_property_decorate = False
        row_33CC2.scale_x = 1.2000000476837158
        row_33CC2.scale_y = 1.5
        row_33CC2.alignment = 'Expand'.upper()
        row_33CC2.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_33CC2.operator('sna.set_transform_pivot_dfa9e', text='', icon_value=581, emboss=True, depress=False)
        op.sna_transform_id = 'Individual'
        op = row_33CC2.operator('sna.set_transform_pivot_dfa9e', text='', icon_value=582, emboss=True, depress=False)
        op.sna_transform_id = 'Median'
        op = row_33CC2.operator('sna.set_transform_pivot_dfa9e', text='', icon_value=580, emboss=True, depress=False)
        op.sna_transform_id = 'Cursor'
        if 'OBJECT'==bpy.context.mode:
            box_CFA38 = layout.box()
            box_CFA38.alert = False
            box_CFA38.enabled = True
            box_CFA38.active = True
            box_CFA38.use_property_split = False
            box_CFA38.use_property_decorate = False
            box_CFA38.alignment = 'Expand'.upper()
            box_CFA38.scale_x = 1.0
            box_CFA38.scale_y = 1.0
            if not True: box_CFA38.operator_context = "EXEC_DEFAULT"
            col_8863B = box_CFA38.column(heading='', align=True)
            col_8863B.alert = False
            col_8863B.enabled = True
            col_8863B.active = True
            col_8863B.use_property_split = False
            col_8863B.use_property_decorate = False
            col_8863B.scale_x = 1.0
            col_8863B.scale_y = 1.0
            col_8863B.alignment = 'Expand'.upper()
            col_8863B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_247FC = col_8863B.row(heading='', align=True)
            row_247FC.alert = False
            row_247FC.enabled = True
            row_247FC.active = True
            row_247FC.use_property_split = False
            row_247FC.use_property_decorate = False
            row_247FC.scale_x = 1.2000000476837158
            row_247FC.scale_y = 1.2000000476837158
            row_247FC.alignment = 'Expand'.upper()
            row_247FC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_247FC.operator('sna.quick_wrap_63b55', text='', icon_value=358, emboss=True, depress=False)
            if bpy.context.view_layer.objects.active:
                if bpy.context.view_layer.objects.active.type == 'MESH':
                    op = row_247FC.operator('sna.mirror_empty_f8d10', text='', icon_value=478, emboss=True, depress=False)
            row_B19BB = col_8863B.row(heading='', align=True)
            row_B19BB.alert = False
            row_B19BB.enabled = True
            row_B19BB.active = True
            row_B19BB.use_property_split = False
            row_B19BB.use_property_decorate = False
            row_B19BB.scale_x = 1.2000000476837158
            row_B19BB.scale_y = 1.2000000476837158
            row_B19BB.alignment = 'Expand'.upper()
            row_B19BB.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_B19BB.operator('object.move_to_collection', text='', icon_value=251, emboss=True, depress=False)
            op = row_B19BB.operator('sna.send_selected_to_backup_5ac5a', text='', icon_value=657, emboss=True, depress=False)
            op = row_B19BB.operator('sna.duplicate_send_to_backup_8be30', text='', icon_value=73, emboss=True, depress=False)
        else:
            box_7F50B = layout.box()
            box_7F50B.alert = False
            box_7F50B.enabled = True
            box_7F50B.active = True
            box_7F50B.use_property_split = False
            box_7F50B.use_property_decorate = False
            box_7F50B.alignment = 'Expand'.upper()
            box_7F50B.scale_x = 1.0
            box_7F50B.scale_y = 1.0
            if not True: box_7F50B.operator_context = "EXEC_DEFAULT"
            col_C9B5A = box_7F50B.column(heading='', align=False)
            col_C9B5A.alert = False
            col_C9B5A.enabled = True
            col_C9B5A.active = True
            col_C9B5A.use_property_split = False
            col_C9B5A.use_property_decorate = False
            col_C9B5A.scale_x = 1.0
            col_C9B5A.scale_y = 1.0
            col_C9B5A.alignment = 'Expand'.upper()
            col_C9B5A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_A5A46 = col_C9B5A.row(heading='', align=True)
            row_A5A46.alert = False
            row_A5A46.enabled = True
            row_A5A46.active = True
            row_A5A46.use_property_split = False
            row_A5A46.use_property_decorate = False
            row_A5A46.scale_x = 1.0
            row_A5A46.scale_y = 1.0
            row_A5A46.alignment = 'Expand'.upper()
            row_A5A46.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_A5A46.operator('mesh.knife_tool', text='', icon_value=555, emboss=True, depress=False)
            op.use_occlude_geometry = True
            op.xray = True
        if 'OBJECT'==bpy.context.mode:
            col_679D0 = layout.column(heading='', align=False)
            col_679D0.alert = False
            col_679D0.enabled = True
            col_679D0.active = True
            col_679D0.use_property_split = False
            col_679D0.use_property_decorate = False
            col_679D0.scale_x = 1.0
            col_679D0.scale_y = 1.0
            col_679D0.alignment = 'Expand'.upper()
            col_679D0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_679D0.label(text='Special Show/Hide', icon_value=0)
            split_3FF7B = col_679D0.split(factor=0.5, align=True)
            split_3FF7B.alert = False
            split_3FF7B.enabled = True
            split_3FF7B.active = True
            split_3FF7B.use_property_split = False
            split_3FF7B.use_property_decorate = False
            split_3FF7B.scale_x = 1.0
            split_3FF7B.scale_y = 1.2000000476837158
            split_3FF7B.alignment = 'Expand'.upper()
            if not True: split_3FF7B.operator_context = "EXEC_DEFAULT"
            op = split_3FF7B.operator('sna.special_hide_unselected_29928', text='Unselected', icon_value=29, emboss=True, depress=False)
            op = split_3FF7B.operator('sna.special_hide_selected_1c458', text='Selected', icon_value=30, emboss=True, depress=False)
            op = col_679D0.operator('sna.special_show_all_7e124', text='Show All', icon_value=16, emboss=True, depress=False)
        else:
            if bpy.context.tool_settings.mesh_select_mode[0]:
                op = layout.operator('mesh.vert_connect_path', text='Join', icon_value=0, emboss=True, depress=False)
            else:
                layout.separator(factor=1.0)
        op = layout.operator('view3d.view_selected', text='', icon_value=115, emboss=True, depress=False)


def sna_fngetactive_F6274():
    me = bpy.context.active_object.data
    has_active = None
    me = bpy.context.active_object.data
    has_active = None
    bm = bmesh.from_edit_mesh(me)
    has_active
    for elem in reversed(bm.select_history):
        if isinstance(elem, bmesh.types.BMVert):
            has_active = True
            print(has_active)
            return has_active
        else:
            has_active = False
            return has_active
    return has_active
    return has_active


class SNA_OT_Forgotten_Tools_Link_F1Fdb(bpy.types.Operator):
    bl_idname = "sna.forgotten_tools_link_f1fdb"
    bl_label = "Forgotten Tools Link"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('bpy.ops.wm.url_open(url="https://stanpancakes.gumroad.com/l/JJNfR")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Edge_Flow_Link_Fd608(bpy.types.Operator):
    bl_idname = "sna.edge_flow_link_fd608"
    bl_label = "Edge Flow Link"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('bpy.ops.wm.url_open(url="https://github.com/BenjaminSauder/EdgeFlow/releases")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Togglem3_8535A(bpy.types.Operator):
    bl_idname = "sna.togglem3_8535a"
    bl_label = "ToggleM3"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.preferences.inputs.use_mouse_emulate_3_button = (not bpy.context.preferences.inputs.use_mouse_emulate_3_button)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnshiftefalse_18B1F(Toggle):
    bpy.context.window_manager.keyconfigs.active.keymaps['Mesh'].keymap_items['transform.edge_crease'].active = Toggle
    bpy.context.window_manager.keyconfigs.user.keymaps['Pose'].keymap_items['pose.breakdown'].active = Toggle


class SNA_OT_Toggle_Off_Shift_Es_F193C(bpy.types.Operator):
    bl_idname = "sna.toggle_off_shift_es_f193c"
    bl_label = "Toggle Off Shift Es"
    bl_description = "Sets all default Shift E keys to false so they wont interfere with compendium pies"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnshiftefalse_18B1F(False)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


@persistent
def load_post_handler_F84BC(dummy):
    sna_fnshiftefalse_18B1F(False)


class SNA_OT_Toggle_On_Shift_Es_8Ad96(bpy.types.Operator):
    bl_idname = "sna.toggle_on_shift_es_8ad96"
    bl_label = "Toggle On Shift Es"
    bl_description = "Sets all default Shift E keys to true so they behave as default Blender intended"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnshiftefalse_18B1F(True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


# --- Item Info Panel -----------
# Location


def reset_x_loc():
    obj = bpy.context.view_layer.objects.active
    obj.location = (0.0, obj.location[1], obj.location[2])


def reset_y_loc():
    obj = bpy.context.view_layer.objects.active
    obj.location = (obj.location[0], 0.0, obj.location[2])


def reset_z_loc():
    obj = bpy.context.view_layer.objects.active
    obj.location = (obj.location[0], obj.location[1], 0.0)


# Rotation Euler


def reset_x_rot_euler():
    obj = bpy.context.view_layer.objects.active
    obj.rotation_euler = (0.0, obj.rotation_euler[1], obj.rotation_euler[2])


def reset_y_rot_euler():
    obj = bpy.context.view_layer.objects.active
    obj.rotation_euler = (obj.rotation_euler[0], 0.0, obj.rotation_euler[2])


def reset_z_rot_euler():
    obj = bpy.context.view_layer.objects.active
    obj.rotation_euler = (obj.rotation_euler[0], obj.rotation_euler[1], 0.0)


# Rotation Quaternion


def reset_w_rot_quaternion():
    obj = bpy.context.view_layer.objects.active
    obj.rotation_quaternion = (1.0, obj.rotation_quaternion[1], obj.rotation_quaternion[2], obj.rotation_quaternion[3])


def reset_x_rot_quaternion():
    obj = bpy.context.view_layer.objects.active
    obj.rotation_quaternion = (obj.rotation_quaternion[0], 0.0, obj.rotation_quaternion[2], obj.rotation_quaternion[3])


def reset_y_rot_quaternion():
    obj = bpy.context.view_layer.objects.active
    obj.rotation_quaternion = (obj.rotation_quaternion[0], obj.rotation_quaternion[1], 0.0, obj.rotation_quaternion[3])


def reset_z_rot_quaternion():
    obj = bpy.context.view_layer.objects.active
    obj.rotation_quaternion = (obj.rotation_quaternion[0], obj.rotation_quaternion[1], obj.rotation_quaternion[2], 0.0)


#Scale


def reset_x_scale():
    obj = bpy.context.view_layer.objects.active
    obj.scale = (1.0, obj.scale[1], obj.scale[2])


def reset_y_scale():
    obj = bpy.context.view_layer.objects.active
    obj.scale = (obj.scale[0], 1.0, obj.scale[2])


def reset_z_scale():
    obj = bpy.context.view_layer.objects.active
    obj.scale = (obj.scale[0], obj.scale[1], 1.0)


# --- Edit Mode Special Orientations --------------------


def set_global_and_median():
    bpy.data.scenes['Scene'].transform_orientation_slots[0].type = 'GLOBAL'
    bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'


def set_all_to_cursor():
    bpy.data.scenes['Scene'].transform_orientation_slots[0].type = 'CURSOR'
    bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'


# --- Workflow Presets --------------------
#Uses global properties from Serpens (preffixed by sna_)


def set_sculpt_workflow():
    bpy.context.scene.sna_sculptworkflow = True
    bpy.context.scene.sna_vpworkflow = False
    bpy.context.scene.sna_wpworkflow = False


def set_vp_workflow():
    bpy.context.scene.sna_sculptworkflow = False
    bpy.context.scene.sna_vpworkflow = True
    bpy.context.scene.sna_wpworkflow = False


def set_wp_workflow():
    bpy.context.scene.sna_sculptworkflow = False
    bpy.context.scene.sna_vpworkflow = False
    bpy.context.scene.sna_wpworkflow = True


def set_snap_mode(mode : str):
    if mode == 'PRO':
        bpy.context.scene.tool_settings.snap_elements = set(['VERTEX','EDGE_MIDPOINT', 'FACE_MIDPOINT'])
        bpy.context.scene.tool_settings.use_snap_align_rotation = False
    else:
        bpy.context.scene.tool_settings.snap_elements = set([mode])
        bpy.context.scene.tool_settings.use_snap_align_rotation = True
    bpy.context.scene.tool_settings.use_snap_rotate = True
    bpy.context.scene.tool_settings.use_snap_translate = True
    bpy.context.scene.tool_settings.snap_target = 'CENTER'


# --- Render Presets --------------------


def set_render_resolution(x_res: int, y_res: int):
    ren = bpy.context.scene.render
    ren.resolution_x = x_res
    ren.resolution_y = y_res


# --- Viewport Presets --------------------


def shading_to_matcap():
    active_shading = bpy.context.area.spaces.active.shading
    active_shading.type = 'SOLID'
    active_shading.light = 'MATCAP'
    active_shading.color_type = 'OBJECT'


def shading_to_flat_vertex():
    bpy.context.area.spaces.active.shading.type = 'SOLID'
    bpy.context.area.spaces.active.shading.light = 'FLAT'
    bpy.context.area.spaces.active.shading.color_type = 'VERTEX'


def shading_to_preview():
    bpy.context.area.spaces.active.shading.type = 'MATERIAL'


# --- Custom Ops --------------------


def move_selected_to_backup():
    """Moves all currently selected objects into the backup collection."""
    # Send the whole selection array directly to the core helper
    link_to_collection(bpy.context.selected_objects, "Backup Objects", move_only=True)


def duplicate_to_backup():
    """Duplicates selected objects and sends copies to the backup collection."""
    copies = []
    for obj in bpy.context.selected_objects:
        obj_copy = obj.copy()
        if obj.data:
            obj_copy.data = obj.data.copy()
        obj_copy.name = f"{obj.name}_Backup"
        copies.append(obj_copy)
    # Send the list of fresh duplicates to the core helper (move_only=False)
    link_to_collection(copies, "Backup Objects", move_only=False)


# --- Helpers ---------------


def link_to_collection(targets, collection_name, move_only=True):
    """
    Finds or creates a collection by name, and processes target objects.
    Accepts either a single bpy.types.Object or a list of objects.
    If move_only is True, it safely unlinks targets from old collections.
    """
    # 1. Get or create the collection
    target_col = bpy.data.collections.get(collection_name)
    if not target_col:
        target_col = bpy.data.collections.new(collection_name)
        bpy.context.scene.collection.children.link(target_col) 
    # 2. Normalize input to a list so it handles single objects or lists seamlessly
    objects_list = [targets] if not isinstance(targets, (list, tuple, set)) else list(targets)
    # 3. Process the objects
    for obj in objects_list:
        if obj.name not in target_col.objects:
            target_col.objects.link(obj)
        if move_only:
            for col in list(obj.users_collection):
                if col != target_col:
                    col.objects.unlink(obj)
    return target_col


def open_side_panel_to_category(context, category_name: str):
    """
    Ensures the N-panel (sidebar) is visible and sets the active tab to the given category name.
    Args:
        context (bpy.context): Blender context.
        category_name (str): The name of the tab to switch to.
    Returns:
        bool: True if successful, False otherwise.
    """
    area = context.area
    space = context.space_data
    if not area or not space:
        return False
    # Ensure sidebar is visible
    if hasattr(space, 'show_region_ui'):
        space.show_region_ui = True
    # Find the UI region (N-panel region)
    ui_region = None
    for region in area.regions:
        if region.type == 'UI':
            ui_region = region
            break
    if not ui_region:
        return False
    # Try to switch to the specified category tab
    try:
        ui_region.active_panel_category = category_name
        area.tag_redraw()
        return True
    except Exception as e:
        print(f"[Sidebar] Could not switch to category '{category_name}': {e}")
        return False


def call_function_by_name(func_name, *args, **kwargs):
    """
    Highly flexible universal function runner.
    Handles empty kwargs, missing args, and prevents nested array errors.
    """
    func = globals().get(func_name)
    if not func or not callable(func):
        print(f"Error: Function '{func_name}' not found or is not callable.")
        return None
    final_args = list(args)
    if len(final_args) == 1 and isinstance(final_args[0], (list, tuple)):
        final_args = list(final_args[0])
    final_kwargs = kwargs if kwargs is not None else {}
    try:
        return func(*final_args, **final_kwargs)
    except TypeError as e:
        print(f"TypeError caught in runner for '{func_name}': {e}")
        print(f"Attempted to pass Args: {final_args} | Kwargs: {final_kwargs}")
        return None


import bmesh
import blf
from gpu_extras.batch import batch_for_shader
from mathutils.geometry import intersect_line_plane
# ---------------------------------------------------------------------------
# Core geometry functions
# ---------------------------------------------------------------------------


def get_intersection_points(plane_co, plane_no, target_objs, depsgraph, tangent=None, half_width=None):
    """tangent + half_width (both optional) bound the plane along the
    direction of the drawn line, so the cut doesn't extend infinitely
    sideways past what was actually drawn (important for e.g. wrapping
    just one section of a torus instead of slicing all the way through)."""
    points = []
    for ob in target_objs:
        ob_eval = ob.evaluated_get(depsgraph)
        mesh = ob_eval.to_mesh()
        mw = ob.matrix_world
        for edge in mesh.edges:
            p1 = mw @ mesh.vertices[edge.vertices[0]].co
            p2 = mw @ mesh.vertices[edge.vertices[1]].co
            hit = intersect_line_plane(p1, p2, plane_co, plane_no)
            if hit is None:
                continue
            edge_vec = p2 - p1
            edge_len_sq = edge_vec.length_squared
            if edge_len_sq == 0:
                continue
            t = (hit - p1).dot(edge_vec) / edge_len_sq
            if not (0.0 <= t <= 1.0):
                continue
            if tangent is not None and half_width is not None:
                local_u = (hit - plane_co).dot(tangent)
                if abs(local_u) > half_width:
                    continue
            points.append(hit)
        ob_eval.to_mesh_clear()
    return points


def order_ring_points(points, plane_co, plane_no):
    """Project points into the plane's 2D space and take their convex
    hull. This gives correctly cyclic-ordered ring points AND naturally
    discards any point sitting inside the outer boundary -- which is
    exactly what happens when a second object's geometry clips through
    the one we actually want the outline of."""
    if len(points) < 3:
        return points
    normal = plane_no.normalized()
    arbitrary = Vector((1, 0, 0)) if abs(normal.x) < 0.9 else Vector((0, 1, 0))
    tangent = normal.cross(arbitrary).normalized()
    bitangent = normal.cross(tangent).normalized()
    centroid = sum(points, Vector((0, 0, 0))) / len(points)
    # project to 2D (x, y) but keep the original 3D point attached
    projected = []
    for p in points:
        local = p - centroid
        x = local.dot(tangent)
        y = local.dot(bitangent)
        projected.append((x, y, p))
    # de-duplicate near-identical 2D positions so the hull isn't confused
    # by coincident points from overlapping edges
    unique = []
    for entry in sorted(projected, key=lambda t: (t[0], t[1])):
        if unique and abs(entry[0] - unique[-1][0]) < 1e-9 and abs(entry[1] - unique[-1][1]) < 1e-9:
            continue
        unique.append(entry)
    projected = unique
    if len(projected) < 3:
        return [p[2] for p in projected]

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lower = []
    for p in projected:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    upper = []
    for p in reversed(projected):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    hull = lower[:-1] + upper[:-1]
    if len(hull) < 3:
        return [p[2] for p in projected]
    return [p[2] for p in hull]


def resample_ring_even(ordered_points, count):
    n = len(ordered_points)
    if n < 3:
        return ordered_points
    seg_lengths = []
    total = 0.0
    for i in range(n):
        a = ordered_points[i]
        b = ordered_points[(i + 1) % n]
        d = (b - a).length
        seg_lengths.append(d)
        total += d
    if total == 0.0:
        return ordered_points[:count]
    step = total / count
    result = []
    acc = 0.0
    idx = 0
    for i in range(count):
        target = i * step
        while acc + seg_lengths[idx] < target and idx < n - 1:
            acc += seg_lengths[idx]
            idx += 1
        seg_len = seg_lengths[idx] if seg_lengths[idx] > 0 else 1e-9
        local_t = (target - acc) / seg_len
        a = ordered_points[idx]
        b = ordered_points[(idx + 1) % n]
        result.append(a.lerp(b, max(0.0, min(1.0, local_t))))
    return result


def align_ring_b_to_a(ring_a, ring_b):
    n = len(ring_a)
    best_offset = 0
    best_reversed = False
    best_score = None
    for reversed_flag in (False, True):
        candidate = list(reversed(ring_b)) if reversed_flag else ring_b
        for offset in range(n):
            score = sum((ring_a[i] - candidate[(i + offset) % n]).length_squared for i in range(n))
            if best_score is None or score < best_score:
                best_score = score
                best_offset = offset
                best_reversed = reversed_flag
    candidate = list(reversed(ring_b)) if best_reversed else ring_b
    return [candidate[(i + best_offset) % n] for i in range(n)]


def ring_centroid(points):
    return sum(points, Vector((0, 0, 0))) / len(points)


def get_plane_from_line(region, rv3d, p1_2d, p2_2d, depth_point):
    view_dir = region_2d_to_vector_3d(region, rv3d, (p1_2d + p2_2d) * 0.5)
    p1_3d = region_2d_to_location_3d(region, rv3d, p1_2d, depth_point)
    p2_3d = region_2d_to_location_3d(region, rv3d, p2_2d, depth_point)
    line_dir = p2_3d - p1_3d
    line_length = line_dir.length
    if line_length < 1e-6:
        return None
    tangent = line_dir / line_length
    plane_point = (p1_3d + p2_3d) * 0.5
    normal = tangent.cross(view_dir)
    if normal.length < 1e-6:
        return None
    normal.normalize()
    half_width = line_length * 0.5
    return plane_point, normal, tangent, half_width


# ---------------------------------------------------------------------------
# Modal operator
# ---------------------------------------------------------------------------
# Events we never touch - let Blender's default navigation handle these.
NAV_PASSTHROUGH_TYPES = {
    'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE',
    'NUMPAD_0', 'NUMPAD_1', 'NUMPAD_2', 'NUMPAD_3', 'NUMPAD_4',
    'NUMPAD_5', 'NUMPAD_6', 'NUMPAD_7', 'NUMPAD_8', 'NUMPAD_9',
    'NUMPAD_PERIOD', 'NUMPAD_PLUS', 'NUMPAD_MINUS',
    'TRACKPADPAN', 'TRACKPADZOOM', 'NDOF_MOTION',


}
class CBL2_OT_ring_wrap_modal(bpy.types.Operator):
    """Click-drag lines across selected mesh(es) to build a bridged quad
    wrap following the object's shape. Draw as many lines as you need."""
    bl_idname = "cbl2.ring_wrap_modal"
    bl_label = "Ring Wrap"
    bl_options = {"REGISTER", "UNDO"}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.targets = []
        self.depsgraph = None
        self.region = None
        self.rv3d = None
        self.depth_point = None
        self.drag_start = None
        self.drag_current = None
        self.rings = []            # list of ordered (raw) point lists, in path order
        self.ring_centroids = []   # parallel list of centroids
        self.primary_axis = None
        self.segments = 16
        self.thickness = 0.05
        self.result_obj = None
        self.draw_handler_2d = None
        self.draw_handler_3d = None
        self.adjust_mode = None
        self.mouse_start_x = 0
        self.thickness_start = 0.0
        self.segments_start = 16
        self.res_accum = 0.0

    @classmethod
    def poll(cls, context):
        try:
            return any(o.type == 'MESH' for o in context.selected_objects)
        except Exception:
            return False

    def invoke(self, context, event):
        try:
            return self._invoke(context, event)
        except Exception as exc:
            self.report({'ERROR'}, f"Ring Wrap failed to start: {exc}")
            return {'CANCELLED'}

    def _invoke(self, context, event):
        self.targets = [o for o in context.selected_objects if o.type == 'MESH']
        if not self.targets:
            self.report({'WARNING'}, "Select at least one mesh object first")
            return {'CANCELLED'}
        if not context.area or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "Run this from the 3D Viewport")
            return {'CANCELLED'}
        self.depsgraph = context.evaluated_depsgraph_get()
        self.region = context.region
        self.rv3d = context.region_data
        centers = []
        for ob in self.targets:
            local_center = sum((Vector(c) for c in ob.bound_box), Vector()) / 8
            centers.append(ob.matrix_world @ local_center)
        self.depth_point = sum(centers, Vector()) / len(centers)
        self.draw_handler_2d = bpy.types.SpaceView3D.draw_handler_add(
            self.draw_callback_2d, (), 'WINDOW', 'POST_PIXEL'
        )
        self.draw_handler_3d = bpy.types.SpaceView3D.draw_handler_add(
            self.draw_callback_3d, (), 'WINDOW', 'POST_VIEW'
        )
        context.window_manager.modal_handler_add(self)
        context.area.tag_redraw()
        self.report({'INFO'}, "Click-drag a line across the mesh. Draw more to refine, Enter to finish")
        return {'RUNNING_MODAL'}

    def draw_callback_2d(self):
        if self.drag_start and self.drag_current:
            shader = gpu.shader.from_builtin('UNIFORM_COLOR')
            batch = batch_for_shader(shader, 'LINES', {"pos": [self.drag_start, self.drag_current]})
            shader.bind()
            shader.uniform_float("color", (1.0, 0.9, 0.1, 1.0))
            batch.draw(shader)
        self.draw_hud()

    def draw_hud(self):
        font_id = 0
        padding = 8
        line_gap = 4
        hints = "Draw: LMB    Thickness: S    Resolution: D    Confirm: Enter/RMB"
        status = f"Rings: {len(self.rings)}    Thickness: {self.thickness:.3f}    Res: {self.segments}    Cancel: Esc"
        if self.adjust_mode == 'THICKNESS':
            status += "    [adjusting]"
        elif self.adjust_mode == 'RESOLUTION':
            status += "    [adjusting]"
        blf.size(font_id, 14)
        hints_w, hints_h = blf.dimensions(font_id, hints)
        status_w, status_h = blf.dimensions(font_id, status)
        box_w = max(hints_w, status_w) + padding * 2
        box_h = hints_h + status_h + line_gap + padding * 2
        x, y = 20, 20
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        verts = ((x, y), (x + box_w, y), (x + box_w, y + box_h), (x, y + box_h))
        indices = ((0, 1, 2), (2, 3, 0))
        batch = batch_for_shader(shader, 'TRIS', {"pos": verts}, indices=indices)
        gpu.state.blend_set('ALPHA')
        shader.bind()
        shader.uniform_float("color", (0.0, 0.0, 0.0, 0.55))
        batch.draw(shader)
        gpu.state.blend_set('NONE')
        blf.color(font_id, 1.0, 1.0, 1.0, 1.0)
        blf.position(font_id, x + padding, y + padding, 0)
        blf.draw(font_id, status)
        blf.position(font_id, x + padding, y + padding + status_h + line_gap, 0)
        blf.draw(font_id, hints)

    def draw_callback_3d(self):
        if not self.rings:
            return
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        gpu.state.depth_test_set('LESS_EQUAL')
        gpu.state.line_width_set(2.0)
        for ring in self.rings:
            loop_coords = list(ring) + [ring[0]]
            batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": loop_coords})
            shader.bind()
            shader.uniform_float("color", (0.1, 0.9, 1.0, 1.0))
            batch.draw(shader)
        gpu.state.depth_test_set('NONE')
        gpu.state.line_width_set(1.0)

    def modal(self, context, event):
        try:
            return self._modal(context, event)
        except Exception as exc:
            self.report({'ERROR'}, f"Ring Wrap error, cancelling: {exc}")
            self.cleanup(context, keep_result=True)
            return {'CANCELLED'}

    def _modal(self, context, event):
        context.area.tag_redraw()
        if event.type in NAV_PASSTHROUGH_TYPES:
            return {'PASS_THROUGH'}
        if self.adjust_mode:
            return self.handle_adjust(event)
        if event.type == 'MOUSEMOVE':
            if self.drag_start:
                self.drag_current = Vector((event.mouse_region_x, event.mouse_region_y))
            return {'RUNNING_MODAL'}
        if event.type == 'LEFTMOUSE':
            if event.value == 'PRESS':
                self.drag_start = Vector((event.mouse_region_x, event.mouse_region_y))
                self.drag_current = self.drag_start.copy()
            elif event.value == 'RELEASE':
                if self.drag_start and self.drag_current and (self.drag_current - self.drag_start).length > 2:
                    ok = self.finish_line()
                    if not ok:
                        self.report({'WARNING'}, "No clean intersection along that line")
                self.drag_start = None
                self.drag_current = None
            return {'RUNNING_MODAL'}
        if event.type == 'S' and event.value == 'PRESS':
            self.adjust_mode = 'THICKNESS'
            self.mouse_start_x = event.mouse_region_x
            self.thickness_start = self.thickness
            return {'RUNNING_MODAL'}
        if event.type == 'D' and event.value == 'PRESS':
            self.adjust_mode = 'RESOLUTION'
            self.mouse_start_x = event.mouse_region_x
            self.segments_start = self.segments
            self.res_accum = 0.0
            return {'RUNNING_MODAL'}
        if event.type in ('RET', 'NUMPAD_ENTER', 'RIGHTMOUSE') and event.value == 'PRESS':
            if len(self.rings) < 2:
                self.report({'WARNING'}, "Draw at least 2 lines before confirming wrap")
                return {'RUNNING_MODAL'}
            self.cleanup(context, keep_result=True)
            return {'FINISHED'}
        if event.type == 'ESC':
            self.cleanup(context, keep_result=False)
            return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def handle_adjust(self, event):
        if event.type == 'MOUSEMOVE':
            delta_px = event.mouse_region_x - self.mouse_start_x
            self.mouse_start_x = event.mouse_region_x
            if self.adjust_mode == 'THICKNESS':
                sensitivity = 0.0001 if event.shift else 0.001
                self.thickness = self.thickness + delta_px * sensitivity
                if self.result_obj:
                    self.result_obj.modifiers["Solidify"].thickness = self.thickness
            elif self.adjust_mode == 'RESOLUTION':
                threshold = 40.0 if event.shift else 10.0
                self.res_accum += delta_px
                while self.res_accum >= threshold:
                    self.segments = min(128, self.segments + 1)
                    self.res_accum -= threshold
                while self.res_accum <= -threshold:
                    self.segments = max(3, self.segments - 1)
                    self.res_accum += threshold
                self.rebuild_all()
            return {'RUNNING_MODAL'}
        if event.type in ('LEFTMOUSE', 'RIGHTMOUSE', 'S', 'D', 'RET', 'NUMPAD_ENTER') and event.value == 'PRESS':
            self.adjust_mode = None
            return {'RUNNING_MODAL'}
        if event.type == 'ESC':
            self.thickness = self.thickness_start
            self.segments = self.segments_start
            if self.result_obj:
                self.result_obj.modifiers["Solidify"].thickness = self.thickness
            self.rebuild_all()
            self.adjust_mode = None
            return {'RUNNING_MODAL'}
        return {'RUNNING_MODAL'}

    def finish_line(self):
        plane = get_plane_from_line(self.region, self.rv3d, self.drag_start, self.drag_current, self.depth_point)
        if plane is None:
            return False
        plane_co, plane_no, tangent, half_width = plane
        raw_points = get_intersection_points(
            plane_co, plane_no, self.targets, self.depsgraph,
            tangent=tangent, half_width=half_width
        )
        if len(raw_points) < 3:
            return False
        ordered = order_ring_points(raw_points, plane_co, plane_no)
        self.insert_ring(ordered)
        self.rebuild_all()
        if len(self.rings) == 1:
            self.report({'INFO'}, "First line set. Draw another to bridge, or draw more in between to refine the wrap")
        return True

    def insert_ring(self, ordered_points):
        centroid = ring_centroid(ordered_points)
        if len(self.rings) == 0:
            self.rings.append(ordered_points)
            self.ring_centroids.append(centroid)
            return
        if len(self.rings) == 1:
            self.rings.append(ordered_points)
            self.ring_centroids.append(centroid)
            axis = self.ring_centroids[1] - self.ring_centroids[0]
            self.primary_axis = axis.normalized() if axis.length > 1e-6 else Vector((0, 0, 1))
            return
        proj = (centroid - self.ring_centroids[0]).dot(self.primary_axis)
        existing_proj = [(c - self.ring_centroids[0]).dot(self.primary_axis) for c in self.ring_centroids]
        insert_idx = 0
        for p in existing_proj:
            if proj > p:
                insert_idx += 1
        self.rings.insert(insert_idx, ordered_points)
        self.ring_centroids.insert(insert_idx, centroid)

    def rebuild_all(self):
        if len(self.rings) < 2:
            return
        resampled = [resample_ring_even(r, self.segments) for r in self.rings]
        aligned = [resampled[0]]
        for i in range(1, len(resampled)):
            aligned.append(align_ring_b_to_a(aligned[i - 1], resampled[i]))
        bm = bmesh.new()
        n = self.segments
        prev_verts = None
        for ring in aligned:
            cur_verts = [bm.verts.new(p) for p in ring]
            if prev_verts is not None:
                for i in range(n):
                    i2 = (i + 1) % n
                    bm.faces.new((prev_verts[i], prev_verts[i2], cur_verts[i2], cur_verts[i]))
            prev_verts = cur_verts
        bm.normal_update()
        if self.result_obj is None:
            mesh_data = bpy.data.meshes.new("RingWrap")
            bm.to_mesh(mesh_data)
            bm.free()
            for f in mesh_data.polygons:
                f.use_smooth = True
            obj = bpy.data.objects.new("RingWrap", mesh_data)
            bpy.context.scene.collection.objects.link(obj)
            solidify = obj.modifiers.new(name="Solidify", type='SOLIDIFY')
            solidify.solidify_mode = 'EXTRUDE'
            solidify.offset = 1
            solidify.thickness = self.thickness
            self.result_obj = obj
            bpy.context.view_layer.objects.active = obj
        else:
            self.result_obj.data.clear_geometry()
            bm.to_mesh(self.result_obj.data)
            bm.free()
            for f in self.result_obj.data.polygons:
                f.use_smooth = True

    def cleanup(self, context, keep_result=False):
        if self.draw_handler_2d:
            bpy.types.SpaceView3D.draw_handler_remove(self.draw_handler_2d, 'WINDOW')
            self.draw_handler_2d = None
        if self.draw_handler_3d:
            bpy.types.SpaceView3D.draw_handler_remove(self.draw_handler_3d, 'WINDOW')
            self.draw_handler_3d = None
        if not keep_result and self.result_obj:
            bpy.data.objects.remove(self.result_obj, do_unlink=True)
            self.result_obj = None
        context.area.tag_redraw()


classes = (CBL2_OT_ring_wrap_modal,)


def sna_append_object_17D2E(object_name):
    before_data = list(bpy.data.objects)
    bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'compendium_assets.blend') + r'\Object', filename=object_name, link=False)
    new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
    appended_D17B2 = None if not new_data else new_data[0]


def special_hide_objects(objects):
    """Saves the current collection name, moves objects to 'HiddenObjects', and hides it."""
    if not objects:
        return
    for obj in objects:
        if obj.users_collection:
            # Cache the active collection name on the object custom property
            obj.sna_lastcollection = obj.users_collection[0].name
    # Move them to the hidden pool via our master helper
    hidden_col = link_to_collection(objects, 'HiddenObjects', move_only=True)
    hidden_col.hide_viewport = True


def special_show_all():
    """Restores all objects from 'HiddenObjects' back to their cached home collections."""
    hidden_col = bpy.data.collections.get('HiddenObjects')
    if not hidden_col:
        return
    # Use a fixed static list clone so moving objects out doesn't break the loop
    objects_to_restore = list(hidden_col.all_objects)
    for obj in objects_to_restore:
        last_col_name = getattr(obj, "sna_lastcollection", "Collection")
        if last_col_name != 'original':
            # Send it home via our master helper
            link_to_collection(obj, last_col_name, move_only=True)
            # Setup a localized timer closure to cleanly mark the object flag reset

            def reset_flag(target_obj=obj):
                target_obj.sna_lastcollection = 'original'
                return None 
            bpy.app.timers.register(reset_flag, first_interval=0.1)


def special_hide_selected():
    """Hides currently selected objects using the special system."""
    special_hide_objects(list(bpy.context.selected_objects))


def special_hide_unselected():
    """Hides everything except what is currently selected using the special system."""
    selected_set = set(bpy.context.selected_objects)
    unselected = [obj for obj in bpy.data.objects if obj not in selected_set]
    special_hide_objects(unselected)


def add_current_cam_location_serpens():
    scene = bpy.context.scene
    active_obj = bpy.context.view_layer.objects.active
    if not active_obj or scene.sna_locationname == '':
        return
    new_item = scene.sna_camlocs.add()
    new_item.name = scene.sna_locationname
    new_item.location = active_obj.location
    orig_mode = active_obj.rotation_mode
    active_obj.rotation_mode = 'QUATERNION'
    new_item.rotation = active_obj.rotation_quaternion
    active_obj.rotation_mode = orig_mode
    scene.sna_locationname = ''


def set_camera_to_saved_serpens(item_id):
    scene = bpy.context.scene
    active_obj = bpy.context.view_layer.objects.active
    if not active_obj or item_id >= len(scene.sna_camlocs):
        return
    saved_target = scene.sna_camlocs[item_id]
    active_obj.location = saved_target.location
    orig_mode = active_obj.rotation_mode
    active_obj.rotation_mode = 'QUATERNION'
    active_obj.rotation_quaternion = saved_target.rotation
    active_obj.rotation_mode = orig_mode


def remove_saved_cam_location_serpens(item_id):
    scene = bpy.context.scene
    if item_id < len(scene.sna_camlocs):
        scene.sna_camlocs.remove(item_id)


# --- Forgotten ------------------------
# --- Seperate Duplicate ------------------------


def _selected_elements(bm, mode):
    """Yield selected elements of the given mode ('VERT', 'EDGE', 'FACE')
    from a BMesh, but only if that mode is part of the current select_mode.
    """
    if mode not in bm.select_mode:
        return
    for element in getattr(bm, mode.lower() + "s"):
        if element.select:
            yield element


def separate_duplicate(context):
    """Duplicate selected mesh elements and separate them into a new mesh.
    Preserves the original selection (bpy.ops.mesh.duplicate() would
    otherwise wipe it), since we want the source mesh to stay selected
    exactly as it was before the duplicate/separate.
    Returns {'CANCELLED'} if nothing was selected, else {'FINISHED'}.
    """
    obj = context.active_object
    bm = bmesh.from_edit_mesh(obj.data)
    active_face = bm.faces.active
    faces = list(_selected_elements(bm, 'FACE'))
    edges = list(_selected_elements(bm, 'EDGE'))
    verts = list(_selected_elements(bm, 'VERT'))
    if not any((faces, edges, verts)):
        return {'CANCELLED'}
    history = list(bm.select_history)
    bpy.ops.mesh.duplicate()
    bpy.ops.mesh.separate(type='SELECTED')
    # bpy.ops.mesh.* calls operate at the C level and can invalidate
    # existing bmesh element references (especially separate(), which
    # spins off a new mesh datablock) - re-fetch before touching bm again.
    bm = bmesh.from_edit_mesh(obj.data)
    elements_by_mode = {'FACE': faces, 'EDGE': edges, 'VERT': verts}
    for mode, elements in elements_by_mode.items():
        if mode in bm.select_mode:
            for element in elements:
                element.select = True
    if history:
        bm.select_history.clear()
        for element in history:
            try:
                bm.select_history.add(element)
            except (ReferenceError, ValueError):
                pass  # element no longer valid after duplicate/separate
        bm.select_history.validate()
    if active_face:
        bm.faces.active = active_face
    bm.select_flush_mode()
    bmesh.update_edit_mesh(obj.data)
    return {'FINISHED'}


# --- Straighten ---------------------------


def find_loops(edges):
    """Group a flat list of selected BMEdges into ordered vertex-chain loops.
    Intersections (verts with >2 selected edges) act as loop boundaries."""
    edges = list(edges)  # don't mutate caller's list
    result = []
    while edges:
        current_edge = edges.pop()
        ve, vs = current_edge.verts[:]
        loop = [vs, ve]
        if sum(e.select for e in ve.link_edges) > 2:
            ve = None
        if sum(e.select for e in vs.link_edges) > 2:
            vs = None
        done = not ve and not vs
        while not done:
            done = True
            i = len(edges)
            while i:
                i -= 1
                ed = edges[i]
                v1, v2 = ed.verts[:]
                if v1 == ve:
                    loop.append(v2)
                    ve = loop[-1]
                    del edges[i]
                    done = sum(e.select for e in ve.link_edges) > 2
                    if done:
                        ve = None
                elif v2 == ve:
                    loop.append(v1)
                    ve = loop[-1]
                    del edges[i]
                    done = sum(e.select for e in ve.link_edges) > 2
                    if done:
                        ve = None
                elif v1 == vs:
                    loop.insert(0, v2)
                    vs = loop[0]
                    del edges[i]
                    done = sum(e.select for e in vs.link_edges) > 2
                    if done:
                        vs = None
                elif v2 == vs:
                    loop.insert(0, v1)
                    vs = loop[0]
                    del edges[i]
                    done = sum(e.select for e in vs.link_edges) > 2
                    if done:
                        vs = None
        result.append(loop)
    return result


def straighten_loop(loop, regular=False):
    """Move interior verts of a loop onto the straight line between its
    two endpoints. regular=True spaces them evenly; otherwise spacing
    is proportional to the original segment lengths."""
    v0 = loop[0]
    v1 = loop[-1]
    if v1 == v0 or len(loop) < 3:
        return
    d = v1.co - v0.co
    pos = v0.co.copy()
    if regular:
        step = d / (len(loop) - 1)
        for v in loop[1:-1]:
            pos += step
            v.co = pos
    else:
        segments = np.zeros(len(loop) - 1, dtype=np.float32)
        for i in range(len(loop) - 1):
            segments[i] = (loop[i + 1].co - loop[i].co).length
        total = np.sum(segments)
        if total == 0:
            return
        segments /= total
        for i, v in enumerate(loop[1:-1]):
            pos += d * segments[i]
            v.co = pos


def straighten(context, regular=True):
    """Straighten selected edge loops on every mesh currently in edit mode
    (intersections are left as loop boundaries and not moved)."""
    for obj in context.objects_in_mode_unique_data:
        mesh = obj.data
        bm = bmesh.from_edit_mesh(mesh)
        loops = find_loops([e for e in bm.edges if e.select])
        for loop in loops:
            straighten_loop(loop, regular)
        bm.normal_update()
        bmesh.update_edit_mesh(mesh)
    return {'FINISHED'}


class SNA_OT_Set_Transform_Pivot_Dfa9E(bpy.types.Operator):
    bl_idname = "sna.set_transform_pivot_dfa9e"
    bl_label = "Set Transform Pivot"
    bl_description = "Set Transform Pivot (See python for Id)"
    bl_options = {"REGISTER", "UNDO"}
    sna_transform_id: bpy.props.StringProperty(name='Transform Id', description='', options={'HIDDEN'}, default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if self.sna_transform_id == "Median":
            exec("bpy.context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'")
        elif self.sna_transform_id == "Cursor":
            exec("bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'")
        elif self.sna_transform_id == "Individual":
            exec("bpy.context.scene.tool_settings.transform_pivot_point = 'INDIVIDUAL_ORIGINS'")
        else:
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Show_Ops_F6C25(bpy.types.Operator):
    bl_idname = "sna.show_ops_f6c25"
    bl_label = "Show Ops"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showops = (not bpy.context.scene.sna_showops)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Mirror_Empty_F8D10(bpy.types.Operator):
    bl_idname = "sna.mirror_empty_f8d10"
    bl_label = "Mirror Empty"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnmirrorcompemtpy_CCFBA()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Send_Selected_To_Backup_5Ac5A(bpy.types.Operator):
    bl_idname = "sna.send_selected_to_backup_5ac5a"
    bl_label = "Send Selected To Backup"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('move_selected_to_backup()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Show_Creases_48169(bpy.types.Operator):
    bl_idname = "sna.toggle_show_creases_48169"
    bl_label = "Toggle Show Creases"
    bl_description = "Show Creases on Objects"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.area.spaces.active.overlay.show_edge_crease = (not bpy.context.area.spaces.active.overlay.show_edge_crease)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Show_Sharps_28E50(bpy.types.Operator):
    bl_idname = "sna.toggle_show_sharps_28e50"
    bl_label = "Toggle Show Sharps"
    bl_description = "Show Sharps on Objects"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.area.spaces.active.overlay.show_edge_sharp = (not bpy.context.area.spaces.active.overlay.show_edge_sharp)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Show_Bevels_Cb2F7(bpy.types.Operator):
    bl_idname = "sna.toggle_show_bevels_cb2f7"
    bl_label = "Toggle Show Bevels"
    bl_description = "Show Bevels on Objects"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.area.spaces.active.overlay.show_edge_bevel_weight = (not bpy.context.area.spaces.active.overlay.show_edge_bevel_weight)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Show_Seams_7408D(bpy.types.Operator):
    bl_idname = "sna.toggle_show_seams_7408d"
    bl_label = "Toggle Show Seams"
    bl_description = "Show Seams on Objects"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.area.spaces.active.overlay.show_edge_seams = (not bpy.context.area.spaces.active.overlay.show_edge_seams)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Shading_Matcap_E9F4F(bpy.types.Operator):
    bl_idname = "sna.set_shading_matcap_e9f4f"
    bl_label = "Set Shading MatCap"
    bl_description = "Set Viewport Shading: Solid, MatCap, Object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('shading_to_matcap()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Shading_Flat_87Cbc(bpy.types.Operator):
    bl_idname = "sna.set_shading_flat_87cbc"
    bl_label = "Set Shading Flat"
    bl_description = "Set Viewport Shading: Solid, Flat, Attribute"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('shading_to_flat_vertex()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Shading_Preview_9Ad3C(bpy.types.Operator):
    bl_idname = "sna.set_shading_preview_9ad3c"
    bl_label = "Set Shading Preview"
    bl_description = "Set Viewport Shading: Material Preview"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('shading_to_preview()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Special_Hide_Selected_1C458(bpy.types.Operator):
    bl_idname = "sna.special_hide_selected_1c458"
    bl_label = "Special Hide Selected"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('special_hide_selected()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Special_Show_All_7E124(bpy.types.Operator):
    bl_idname = "sna.special_show_all_7e124"
    bl_label = "Special Show All"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('special_show_all()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Special_Hide_Unselected_29928(bpy.types.Operator):
    bl_idname = "sna.special_hide_unselected_29928"
    bl_label = "Special Hide Unselected"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('special_hide_unselected()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Wireframe_C8C58(bpy.types.Operator):
    bl_idname = "sna.toggle_wireframe_c8c58"
    bl_label = "Toggle Wireframe"
    bl_description = "Show wireframe on active object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.show_wire = (not bpy.context.view_layer.objects.active.show_wire)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Duplicate_Send_To_Backup_8Be30(bpy.types.Operator):
    bl_idname = "sna.duplicate_send_to_backup_8be30"
    bl_label = "Duplicate Send To Backup"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('duplicate_to_backup()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Display_In_Front_67De2(bpy.types.Operator):
    bl_idname = "sna.toggle_display_in_front_67de2"
    bl_label = "Toggle Display In Front"
    bl_description = "Toggle show in front for amature bones"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.show_in_front = (not bpy.context.view_layer.objects.active.show_in_front)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Show_Stretch_8Ca4E(bpy.types.Operator):
    bl_idname = "sna.toggle_show_stretch_8ca4e"
    bl_label = "Toggle Show Stretch"
    bl_description = "Show UV stretch heatmap"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.area.spaces[0].uv_editor.show_stretch = (not bpy.context.area.spaces[0].uv_editor.show_stretch)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Vertex_Paint_Workflow_B1688(bpy.types.Operator):
    bl_idname = "sna.set_vertex_paint_workflow_b1688"
    bl_label = "Set Vertex Paint Workflow"
    bl_description = "Changes tools to quickly adapt to a vertex painting workflow"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('set_vp_workflow()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Weight_Paint_Workflow_C2Eda(bpy.types.Operator):
    bl_idname = "sna.set_weight_paint_workflow_c2eda"
    bl_label = "Set Weight Paint Workflow"
    bl_description = "Changes tools to quickly adapt to a weight painting workflow"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('set_wp_workflow()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Sculpt_Workflow_27F56(bpy.types.Operator):
    bl_idname = "sna.set_sculpt_workflow_27f56"
    bl_label = "Set Sculpt Workflow"
    bl_description = "Changes tools to quickly adapt to a  scupting workflow"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('set_sculpt_workflow()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Camera_Loaction_1E5F9(bpy.types.Operator):
    bl_idname = "sna.add_camera_loaction_1e5f9"
    bl_label = "Add Camera Loaction"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('add_current_cam_location_serpens()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Setcameratolocation_78754(bpy.types.Operator):
    bl_idname = "sna.setcameratolocation_78754"
    bl_label = "SetCameraToLocation"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_id: bpy.props.IntProperty(name='ID', description='', options={'HIDDEN'}, default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        func_name = 'set_camera_to_saved_serpens'
        args = [self.sna_id]
        call_function_by_name(func_name, *args)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Remove_Camera_Location_37A38(bpy.types.Operator):
    bl_idname = "sna.remove_camera_location_37a38"
    bl_label = "Remove Camera Location"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_id: bpy.props.IntProperty(name='ID', description='', options={'HIDDEN'}, default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        func_name = 'remove_saved_cam_location_serpens'
        args = [self.sna_id]
        call_function_by_name(func_name, *args)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Screen_Peset_45D5E(bpy.types.Operator):
    bl_idname = "sna.set_screen_peset_45d5e"
    bl_label = " Set Screen Peset"
    bl_description = "Preset for setting the render to a square resolution. "
    bl_options = {"REGISTER", "UNDO"}
    sna_preset: bpy.props.StringProperty(name='Preset', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if self.sna_preset == "2k":
            exec('set_render_resolution(2560, 1440)')
        elif self.sna_preset == "FullHD":
            exec('set_render_resolution(1920, 1080)')
        elif self.sna_preset == "520":
            exec('set_render_resolution(520, 520)')
        elif self.sna_preset == "1040":
            exec('set_render_resolution(1040, 1040)')
        elif self.sna_preset == "2480":
            exec('set_render_resolution(2480, 2480)')
        else:
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Workflow_Options_05D4C(bpy.types.Operator):
    bl_idname = "sna.toggle_workflow_options_05d4c"
    bl_label = "Toggle Workflow Options"
    bl_description = "Shows and hides the options for specified workflow"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showwfoptions = (not bpy.context.scene.sna_showwfoptions)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Single_Vert_Bfe7D(bpy.types.Operator):
    bl_idname = "sna.add_single_vert_bfe7d"
    bl_label = "Add Single Vert"
    bl_description = "Adds a single vert object to project"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_append_object_17D2E('SingleVert')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Edge_2Ddef(bpy.types.Operator):
    bl_idname = "sna.add_edge_2ddef"
    bl_label = "Add Edge"
    bl_description = "Adds a single edge object to project"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_append_object_17D2E('X_Edge')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Bezier_Pipe_E6F6D(bpy.types.Operator):
    bl_idname = "sna.add_bezier_pipe_e6f6d"
    bl_label = "Add Bezier Pipe"
    bl_description = "Add simple bezier curve with a circle profile"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_append_object_17D2E('BezierPipe')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Bezier_Rectangle_F8009(bpy.types.Operator):
    bl_idname = "sna.add_bezier_rectangle_f8009"
    bl_label = "Add Bezier Rectangle"
    bl_description = "Add simple bezier curve with a rectangle profile"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_append_object_17D2E('BezierRectangle')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Empty_Curve_43Edf(bpy.types.Operator):
    bl_idname = "sna.add_empty_curve_43edf"
    bl_label = "Add Empty Curve"
    bl_description = "Add empty curve object (for easy use of the pen tool)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_append_object_17D2E('EmptyCurve')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Opensidepanel_55C7A(bpy.types.Operator):
    bl_idname = "sna.opensidepanel_55c7a"
    bl_label = "OpenSidePanel"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('open_side_panel_to_category(context, category_name="Compendium")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Orientation_Cursor_Acb4A(bpy.types.Operator):
    bl_idname = "sna.set_orientation_cursor_acb4a"
    bl_label = "Set Orientation Cursor"
    bl_description = "Set the transform orientation to 3D Cursor"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('set_all_to_cursor()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Orientation_Global_And_Pivot_Median_465F2(bpy.types.Operator):
    bl_idname = "sna.set_orientation_global_and_pivot_median_465f2"
    bl_label = "Set Orientation Global and Pivot Median"
    bl_description = "Set the transform orientation to Global and the transform pivot to Median"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('set_global_and_median()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Show_Face_Normals_D2Fbc(bpy.types.Operator):
    bl_idname = "sna.toggle_show_face_normals_d2fbc"
    bl_label = "Toggle Show Face Normals"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.area.spaces[0].overlay.show_face_orientation = (not bpy.context.area.spaces[0].overlay.show_face_orientation)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Quick_Wrap_63B55(bpy.types.Operator):
    bl_idname = "sna.quick_wrap_63b55"
    bl_label = "Quick Wrap"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.view_layer.objects.selected:
            exec("bpy.ops.cbl2.ring_wrap_modal('INVOKE_DEFAULT')")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_Rotation_Euler_065Ea(bpy.types.Operator):
    bl_idname = "sna.reset_rotation_euler_065ea"
    bl_label = "Reset Rotation Euler"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_axis_value: bpy.props.StringProperty(name='Axis Value', description='', options={'HIDDEN'}, default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if self.sna_axis_value == "X Axis":
            exec('reset_x_rot_euler()')
        elif self.sna_axis_value == "Y Axis":
            exec('reset_y_rot_euler()')
        elif self.sna_axis_value == "Z Axis":
            exec('reset_z_rot_euler()')
        else:
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_Rotation_Quaternion_451Ec(bpy.types.Operator):
    bl_idname = "sna.reset_rotation_quaternion_451ec"
    bl_label = "Reset Rotation Quaternion"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_axis: bpy.props.StringProperty(name='Axis', description='', options={'HIDDEN'}, default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if self.sna_axis == "W Axis":
            exec('reset_w_rot_quaternion()')
        elif self.sna_axis == "X Axis":
            exec('reset_x_rot_quaternion()')
        elif self.sna_axis == "Y Axis":
            exec('reset_y_rot_quaternion()')
        elif self.sna_axis == "Z Axis":
            exec('reset_z_rot_quaternion()')
        else:
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_Location_1Beb6(bpy.types.Operator):
    bl_idname = "sna.reset_location_1beb6"
    bl_label = "Reset Location"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_axis: bpy.props.StringProperty(name='Axis', description='', options={'HIDDEN'}, default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if self.sna_axis == "X Axis":
            exec('reset_x_loc()')
        elif self.sna_axis == "Y Axis":
            exec('reset_y_loc()')
        elif self.sna_axis == "Z Axis":
            exec('reset_z_loc()')
        else:
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_Scale_2228C(bpy.types.Operator):
    bl_idname = "sna.reset_scale_2228c"
    bl_label = "Reset Scale"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_axis: bpy.props.StringProperty(name='Axis', description='', options={'HIDDEN'}, default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if self.sna_axis == "X Axis":
            exec('reset_x_scale()')
        elif self.sna_axis == "Y Axis":
            exec('reset_y_scale()')
        elif self.sna_axis == "Z Axis":
            exec('reset_z_scale()')
        else:
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Orientation_Transform_97638(bpy.types.Operator):
    bl_idname = "sna.set_orientation_transform_97638"
    bl_label = "Set Orientation Transform"
    bl_description = "Set the transform orientation. (See Python for Id)"
    bl_options = {"REGISTER", "UNDO"}
    sna_transformid: bpy.props.StringProperty(name='TransformId', description='', options={'HIDDEN'}, default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.transform_orientation_slots[0].type = self.sna_transformid
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnviewportuniversal_70EA3(layout_function, ):
    row_314F8 = layout_function.row(heading='', align=False)
    row_314F8.alert = False
    row_314F8.enabled = True
    row_314F8.active = True
    row_314F8.use_property_split = False
    row_314F8.use_property_decorate = False
    row_314F8.scale_x = 1.0
    row_314F8.scale_y = 1.0
    row_314F8.alignment = 'Expand'.upper()
    row_314F8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    col_E3402 = row_314F8.column(heading='', align=False)
    col_E3402.alert = False
    col_E3402.enabled = True
    col_E3402.active = True
    col_E3402.use_property_split = False
    col_E3402.use_property_decorate = False
    col_E3402.scale_x = 1.4500000476837158
    col_E3402.scale_y = 3.299999952316284
    col_E3402.alignment = 'Expand'.upper()
    col_E3402.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    op = col_E3402.operator('view3d.toggle_xray', text='', icon_value=647, emboss=True, depress=bpy.context.area.spaces.active.shading.show_xray)
    if bpy.context.view_layer.objects.active:
        col_0ACEB = row_314F8.column(heading='', align=True)
        col_0ACEB.alert = False
        col_0ACEB.enabled = True
        col_0ACEB.active = True
        col_0ACEB.use_property_split = False
        col_0ACEB.use_property_decorate = False
        col_0ACEB.scale_x = 1.0
        col_0ACEB.scale_y = 1.100000023841858
        col_0ACEB.alignment = 'Expand'.upper()
        col_0ACEB.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_0ACEB.operator('sna.toggle_wireframe_c8c58', text='Show Wireframe', icon_value=508, emboss=True, depress=bpy.context.view_layer.objects.active.show_wire)
        op = col_0ACEB.operator('sna.toggle_show_face_normals_d2fbc', text='Show Face Normals', icon_value=619, emboss=True, depress=bpy.context.area.spaces[0].overlay.show_face_orientation)
        col_00A79 = col_0ACEB.column(heading='', align=True)
        col_00A79.alert = False
        col_00A79.enabled = bpy.context.view_layer.objects.active.type == 'ARMATURE'
        col_00A79.active = True
        col_00A79.use_property_split = False
        col_00A79.use_property_decorate = False
        col_00A79.scale_x = 1.0
        col_00A79.scale_y = 1.0
        col_00A79.alignment = 'Expand'.upper()
        col_00A79.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_00A79.operator('sna.toggle_display_in_front_67de2', text='Bones in Front', icon_value=217, emboss=True, depress=bpy.context.view_layer.objects.active.show_in_front)
    else:
        col_DC128 = row_314F8.column(heading='', align=True)
        col_DC128.alert = False
        col_DC128.enabled = True
        col_DC128.active = True
        col_DC128.use_property_split = False
        col_DC128.use_property_decorate = False
        col_DC128.scale_x = 1.0
        col_DC128.scale_y = 1.100000023841858
        col_DC128.alignment = 'Expand'.upper()
        col_DC128.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_DC128.label(text='', icon_value=0)
        row_AB0B2 = col_DC128.row(heading='', align=False)
        row_AB0B2.alert = False
        row_AB0B2.enabled = True
        row_AB0B2.active = True
        row_AB0B2.use_property_split = False
        row_AB0B2.use_property_decorate = False
        row_AB0B2.scale_x = 0.9699999094009399
        row_AB0B2.scale_y = 1.0
        row_AB0B2.alignment = 'Center'.upper()
        row_AB0B2.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_AB0B2.template_icon(icon_value=55, scale=1.0)
        row_AB0B2.label(text='Select Object', icon_value=0)
        row_AB0B2.template_icon(icon_value=55, scale=1.0)
    col_08A16 = row_314F8.column(heading='', align=True)
    col_08A16.alert = False
    col_08A16.enabled = True
    col_08A16.active = True
    col_08A16.use_property_split = False
    col_08A16.use_property_decorate = False
    col_08A16.scale_x = 1.0
    col_08A16.scale_y = 1.100000023841858
    col_08A16.alignment = 'Expand'.upper()
    col_08A16.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    op = col_08A16.operator('sna.set_shading_matcap_e9f4f', text='', icon_value=336, emboss=True, depress=False)
    op = col_08A16.operator('sna.set_shading_flat_87cbc', text='', icon_value=644, emboss=True, depress=False)
    op = col_08A16.operator('sna.set_shading_preview_9ad3c', text='', icon_value=205, emboss=True, depress=False)


def sna_fnmirrorcompemtpy_CCFBA():
    if bpy.context.view_layer.objects.selected:
        mirrorempty['sna_objectname'] = bpy.context.view_layer.objects.active.name
        if bpy.context.scene.sna_usecompendiumempty:
            sna_fnfindempty_6DACB()
        else:
            sna_fncreateempty_0F0F5()


def sna_fnfindempty_6DACB():
    for i_55B66 in range(len(bpy.data.objects)):
        if (bpy.data.objects[i_55B66].name == 'CompendiumEmpty'):
            mirrorempty['sna_foundobject'] = True
            break
    if mirrorempty['sna_foundobject']:
        sna_fnaddmirroremptymod_E16E4('CompendiumEmpty')
    else:
        sna_fncreateempty_0F0F5()


def sna_fncreateempty_0F0F5():
    bpy.ops.object.empty_add('INVOKE_DEFAULT', type='PLAIN_AXES', radius=1.0, align='WORLD', location=(0.0, 0.0, 0.0), rotation=(0.0, 0.0, 0.0), scale=(1.0, 1.0, 1.0))
    bpy.context.view_layer.objects.active.name = 'CompendiumEmpty'
    mirrorempty['sna_newempty'] = bpy.context.view_layer.objects.active.name
    sna_fnaddmirroremptymod_E16E4(mirrorempty['sna_newempty'])


def sna_fnaddmirroremptymod_E16E4(EmptyName):
    modifier_B2CEA = bpy.data.objects[mirrorempty['sna_objectname']].modifiers.new(name='Mirror Empty Mod', type='MIRROR', )
    output_0_5ba5f = sna_getobjectproperty_427FF_5BA5F(EmptyName)
    modifier_B2CEA.mirror_object = output_0_5ba5f


class SNA_PT_EDIT_TOOLS_8CCA4(bpy.types.Panel):
    bl_label = 'Edit Tools'
    bl_idname = 'SNA_PT_EDIT_TOOLS_8CCA4'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 3
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not (bpy.context.scene.sna_showtools and 'EDIT_MESH'==bpy.context.mode)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='OPS', icon_value=0)
        box_FDBD2 = layout.box()
        box_FDBD2.alert = False
        box_FDBD2.enabled = True
        box_FDBD2.active = True
        box_FDBD2.use_property_split = False
        box_FDBD2.use_property_decorate = False
        box_FDBD2.alignment = 'Expand'.upper()
        box_FDBD2.scale_x = 1.0
        box_FDBD2.scale_y = 1.0
        if not True: box_FDBD2.operator_context = "EXEC_DEFAULT"
        col_0198B = box_FDBD2.column(heading='', align=False)
        col_0198B.alert = False
        col_0198B.enabled = True
        col_0198B.active = True
        col_0198B.use_property_split = False
        col_0198B.use_property_decorate = False
        col_0198B.scale_x = 1.0
        col_0198B.scale_y = 1.0
        col_0198B.alignment = 'Expand'.upper()
        col_0198B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_0198B.operator('sna.seperate_duplicate_8a92b', text='Seperate Duplicate', icon_value=0, emboss=True, depress=False)
        col_0198B.label(text='Straighten', icon_value=0)
        op = col_0198B.operator('sna.even_0df34', text='Even', icon_value=0, emboss=True, depress=False)
        op = col_0198B.operator('sn.dummy_button_operator', text='Proportional', icon_value=0, emboss=True, depress=False)
        box_1B8F3 = layout.box()
        box_1B8F3.alert = False
        box_1B8F3.enabled = True
        box_1B8F3.active = True
        box_1B8F3.use_property_split = False
        box_1B8F3.use_property_decorate = False
        box_1B8F3.alignment = 'Expand'.upper()
        box_1B8F3.scale_x = 1.0
        box_1B8F3.scale_y = 1.0
        if not True: box_1B8F3.operator_context = "EXEC_DEFAULT"
        col_6F0F4 = box_1B8F3.column(heading='', align=False)
        col_6F0F4.alert = False
        col_6F0F4.enabled = True
        col_6F0F4.active = True
        col_6F0F4.use_property_split = False
        col_6F0F4.use_property_decorate = False
        col_6F0F4.scale_x = 1.0
        col_6F0F4.scale_y = 1.0
        col_6F0F4.alignment = 'Expand'.upper()
        col_6F0F4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        if property_exists("bpy.context.preferences.addons['bl_ext.blender_org.looptools']", globals(), locals()):
            col_55FE6 = col_6F0F4.column(heading='', align=False)
            col_55FE6.alert = False
            col_55FE6.enabled = True
            col_55FE6.active = True
            col_55FE6.use_property_split = False
            col_55FE6.use_property_decorate = False
            col_55FE6.scale_x = 1.0
            col_55FE6.scale_y = 1.0
            col_55FE6.alignment = 'Expand'.upper()
            col_55FE6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_55FE6.label(text='LoopTools', icon_value=0)
            op = col_55FE6.operator('mesh.looptools_relax', text='Relax', icon_value=0, emboss=True, depress=False)
            op.regular = True
            op = col_55FE6.operator('mesh.looptools_flatten', text='Flatten', icon_value=0, emboss=True, depress=False)
            op.influence = 100.0
            op = col_55FE6.operator('mesh.looptools_circle', text='Circle', icon_value=0, emboss=True, depress=False)
        if property_exists("bpy.context.preferences.addons['bl_ext.blender_org.EdgeFlow']", globals(), locals()):
            col_77A4E = col_6F0F4.column(heading='', align=False)
            col_77A4E.alert = False
            col_77A4E.enabled = True
            col_77A4E.active = True
            col_77A4E.use_property_split = False
            col_77A4E.use_property_decorate = False
            col_77A4E.scale_x = 1.0
            col_77A4E.scale_y = 1.0
            col_77A4E.alignment = 'Expand'.upper()
            col_77A4E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_77A4E.label(text='Edge Flow', icon_value=0)
            op = col_77A4E.operator('mesh.set_edge_flow', text='Set Edge Flow', icon_value=0, emboss=True, depress=False)
            op = col_77A4E.operator('mesh.set_edge_linear', text='Set Linear Flow', icon_value=0, emboss=True, depress=False)
            op = col_77A4E.operator('mesh.set_edge_curve', text='Set Edge Curve', icon_value=0, emboss=True, depress=False)


class SNA_OT_Seperate_Duplicate_8A92B(bpy.types.Operator):
    bl_idname = "sna.seperate_duplicate_8a92b"
    bl_label = "Seperate Duplicate"
    bl_description = "Duplicate selected mesh elements and separate them into a new mesh."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('separate_duplicate(context)')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Even_0Df34(bpy.types.Operator):
    bl_idname = "sna.even_0df34"
    bl_label = "Even"
    bl_description = "Straighten selected edge loops. Spaces elements evenly."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('straighten(context, true)')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Proportional_45B9B(bpy.types.Operator):
    bl_idname = "sna.proportional_45b9b"
    bl_label = "Proportional"
    bl_description = "Straighten selected edge loops. Spacing is proportional to the original segment lengths."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('straighten(context, false)')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_ITEM_INFO_98572(bpy.types.Panel):
    bl_label = 'Item Info'
    bl_idname = 'SNA_PT_ITEM_INFO_98572'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 1
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not bpy.context.scene.sna_showiteminfo))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if bpy.context.view_layer.objects.active:
            if 'OBJECT'==bpy.context.mode:
                col_81D10 = layout.column(heading='', align=False)
                col_81D10.alert = False
                col_81D10.enabled = True
                col_81D10.active = True
                col_81D10.use_property_split = False
                col_81D10.use_property_decorate = False
                col_81D10.scale_x = 1.0
                col_81D10.scale_y = 1.0
                col_81D10.alignment = 'Expand'.upper()
                col_81D10.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                col_81D10.label(text='Location', icon_value=0)
                row_2533A = col_81D10.row(heading='', align=True)
                row_2533A.alert = False
                row_2533A.enabled = True
                row_2533A.active = True
                row_2533A.use_property_split = False
                row_2533A.use_property_decorate = False
                row_2533A.scale_x = 1.0
                row_2533A.scale_y = 1.0
                row_2533A.alignment = 'Expand'.upper()
                row_2533A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                col_31DDF = row_2533A.column(heading='', align=True)
                col_31DDF.alert = False
                col_31DDF.enabled = True
                col_31DDF.active = True
                col_31DDF.use_property_split = False
                col_31DDF.use_property_decorate = False
                col_31DDF.scale_x = 1.0
                col_31DDF.scale_y = 1.0
                col_31DDF.alignment = 'Expand'.upper()
                col_31DDF.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                col_31DDF.prop(bpy.context.view_layer.objects.active, 'location', text='', icon_value=0, emboss=True)
                col_7500E = row_2533A.column(heading='', align=True)
                col_7500E.alert = False
                col_7500E.enabled = True
                col_7500E.active = True
                col_7500E.use_property_split = False
                col_7500E.use_property_decorate = False
                col_7500E.scale_x = 1.25
                col_7500E.scale_y = 1.0
                col_7500E.alignment = 'Right'.upper()
                col_7500E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                op = col_7500E.operator('sna.reset_location_1beb6', text='', icon_value=23, emboss=True, depress=False)
                op.sna_axis = 'X Axis'
                op = col_7500E.operator('sna.reset_location_1beb6', text='', icon_value=23, emboss=True, depress=False)
                op.sna_axis = 'Y Axis'
                op = col_7500E.operator('sna.reset_location_1beb6', text='', icon_value=23, emboss=True, depress=False)
                op.sna_axis = 'Z Axis'
                col_81D10.label(text='Rotation', icon_value=0)
                row_F7C5B = col_81D10.row(heading='', align=True)
                row_F7C5B.alert = False
                row_F7C5B.enabled = True
                row_F7C5B.active = True
                row_F7C5B.use_property_split = False
                row_F7C5B.use_property_decorate = False
                row_F7C5B.scale_x = 1.0
                row_F7C5B.scale_y = 1.0
                row_F7C5B.alignment = 'Expand'.upper()
                row_F7C5B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                col_69E30 = row_F7C5B.column(heading='', align=True)
                col_69E30.alert = False
                col_69E30.enabled = True
                col_69E30.active = True
                col_69E30.use_property_split = False
                col_69E30.use_property_decorate = False
                col_69E30.scale_x = 1.0
                col_69E30.scale_y = 1.0
                col_69E30.alignment = 'Expand'.upper()
                col_69E30.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                if bpy.context.view_layer.objects.active.rotation_mode == "QUATERNION":
                    col_69E30.prop(bpy.context.view_layer.objects.active, 'rotation_quaternion', text='', icon_value=0, emboss=True)
                else:
                    col_69E30.prop(bpy.context.view_layer.objects.active, 'rotation_euler', text='', icon_value=0, emboss=True)
                if bpy.context.view_layer.objects.active.rotation_mode == "QUATERNION":
                    col_D81DD = row_F7C5B.column(heading='', align=True)
                    col_D81DD.alert = False
                    col_D81DD.enabled = True
                    col_D81DD.active = True
                    col_D81DD.use_property_split = False
                    col_D81DD.use_property_decorate = False
                    col_D81DD.scale_x = 1.25
                    col_D81DD.scale_y = 1.0
                    col_D81DD.alignment = 'Right'.upper()
                    col_D81DD.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                    op = col_D81DD.operator('sna.reset_rotation_quaternion_451ec', text='', icon_value=23, emboss=True, depress=False)
                    op.sna_axis = 'W Axis'
                    op = col_D81DD.operator('sna.reset_rotation_quaternion_451ec', text='', icon_value=23, emboss=True, depress=False)
                    op.sna_axis = 'X Axis'
                    op = col_D81DD.operator('sna.reset_rotation_quaternion_451ec', text='', icon_value=23, emboss=True, depress=False)
                    op.sna_axis = 'Y Axis'
                    op = col_D81DD.operator('sna.reset_rotation_quaternion_451ec', text='', icon_value=23, emboss=True, depress=False)
                    op.sna_axis = 'Z Axis'
                else:
                    col_F4B6E = row_F7C5B.column(heading='', align=True)
                    col_F4B6E.alert = False
                    col_F4B6E.enabled = True
                    col_F4B6E.active = True
                    col_F4B6E.use_property_split = False
                    col_F4B6E.use_property_decorate = False
                    col_F4B6E.scale_x = 1.25
                    col_F4B6E.scale_y = 1.0
                    col_F4B6E.alignment = 'Right'.upper()
                    col_F4B6E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                    op = col_F4B6E.operator('sna.reset_rotation_euler_065ea', text='', icon_value=23, emboss=True, depress=False)
                    op.sna_axis_value = 'X Axis'
                    op = col_F4B6E.operator('sna.reset_rotation_euler_065ea', text='', icon_value=23, emboss=True, depress=False)
                    op.sna_axis_value = 'Y Axis'
                    op = col_F4B6E.operator('sna.reset_rotation_euler_065ea', text='', icon_value=23, emboss=True, depress=False)
                    op.sna_axis_value = 'Z Axis'
                col_81D10.prop(bpy.context.view_layer.objects.active, 'rotation_mode', text='', icon_value=0, emboss=True)
                col_81D10.label(text='Scale', icon_value=0)
                row_B5371 = col_81D10.row(heading='', align=True)
                row_B5371.alert = False
                row_B5371.enabled = True
                row_B5371.active = True
                row_B5371.use_property_split = False
                row_B5371.use_property_decorate = False
                row_B5371.scale_x = 1.0
                row_B5371.scale_y = 1.0
                row_B5371.alignment = 'Expand'.upper()
                row_B5371.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                col_B814F = row_B5371.column(heading='', align=True)
                col_B814F.alert = False
                col_B814F.enabled = True
                col_B814F.active = True
                col_B814F.use_property_split = False
                col_B814F.use_property_decorate = False
                col_B814F.scale_x = 1.0
                col_B814F.scale_y = 1.0
                col_B814F.alignment = 'Expand'.upper()
                col_B814F.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                col_B814F.prop(bpy.context.view_layer.objects.active, 'scale', text='', icon_value=0, emboss=True)
                col_98DBC = row_B5371.column(heading='', align=True)
                col_98DBC.alert = False
                col_98DBC.enabled = True
                col_98DBC.active = True
                col_98DBC.use_property_split = False
                col_98DBC.use_property_decorate = False
                col_98DBC.scale_x = 1.25
                col_98DBC.scale_y = 1.0
                col_98DBC.alignment = 'Right'.upper()
                col_98DBC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                op = col_98DBC.operator('sna.reset_scale_2228c', text='', icon_value=23, emboss=True, depress=False)
                op.sna_axis = 'X Axis'
                op = col_98DBC.operator('sna.reset_scale_2228c', text='', icon_value=23, emboss=True, depress=False)
                op.sna_axis = 'Y Axis'
                op = col_98DBC.operator('sna.reset_scale_2228c', text='', icon_value=23, emboss=True, depress=False)
                op.sna_axis = 'Z Axis'
            else:
                layout.label(text='Edit Mode In Progress', icon_value=0)
        else:
            layout.label(text='No Active Item', icon_value=0)


class SNA_PT_OBJECT_TOOLS_F8454(bpy.types.Panel):
    bl_label = 'Object Tools'
    bl_idname = 'SNA_PT_OBJECT_TOOLS_F8454'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 3
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not (bpy.context.scene.sna_showtools and 'OBJECT'==bpy.context.mode)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='OPS', icon_value=0)
        box_0A9C5 = layout.box()
        box_0A9C5.alert = False
        box_0A9C5.enabled = True
        box_0A9C5.active = True
        box_0A9C5.use_property_split = False
        box_0A9C5.use_property_decorate = False
        box_0A9C5.alignment = 'Expand'.upper()
        box_0A9C5.scale_x = 1.0
        box_0A9C5.scale_y = 1.0
        if not True: box_0A9C5.operator_context = "EXEC_DEFAULT"
        col_6FAD6 = box_0A9C5.column(heading='', align=False)
        col_6FAD6.alert = False
        col_6FAD6.enabled = True
        col_6FAD6.active = True
        col_6FAD6.use_property_split = False
        col_6FAD6.use_property_decorate = False
        col_6FAD6.scale_x = 1.0
        col_6FAD6.scale_y = 1.0
        col_6FAD6.alignment = 'Expand'.upper()
        col_6FAD6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_6FAD6.operator('object.origin_set', text='Set Origin (Volume)', icon_value=0, emboss=True, depress=False)
        op.type = 'ORIGIN_CENTER_OF_VOLUME'
        op = col_6FAD6.operator('object.origin_set', text='Set Origin (Cursor)', icon_value=0, emboss=True, depress=False)
        op.type = 'ORIGIN_CURSOR'
        op = col_6FAD6.operator('object.convert', text='Convert To Mesh', icon_value=0, emboss=True, depress=False)
        op.target = 'MESH'
        col_69370 = layout.column(heading='', align=True)
        col_69370.alert = False
        col_69370.enabled = True
        col_69370.active = True
        col_69370.use_property_split = False
        col_69370.use_property_decorate = False
        col_69370.scale_x = 1.0
        col_69370.scale_y = 1.0
        col_69370.alignment = 'Expand'.upper()
        col_69370.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_69370.operator('sna.toggle_more_object_options_37109', text='', icon_value=(34 if bpy.context.scene.sna_showmoreobjectopts else 33), emboss=True, depress=False)
        if bpy.context.scene.sna_showmoreobjectopts:
            col_909AE = col_69370.column(heading='', align=False)
            col_909AE.alert = False
            col_909AE.enabled = True
            col_909AE.active = True
            col_909AE.use_property_split = False
            col_909AE.use_property_decorate = False
            col_909AE.scale_x = 1.0
            col_909AE.scale_y = 1.0
            col_909AE.alignment = 'Expand'.upper()
            col_909AE.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            box_EF552 = col_909AE.box()
            box_EF552.alert = False
            box_EF552.enabled = True
            box_EF552.active = True
            box_EF552.use_property_split = False
            box_EF552.use_property_decorate = False
            box_EF552.alignment = 'Expand'.upper()
            box_EF552.scale_x = 1.0
            box_EF552.scale_y = 1.0
            if not True: box_EF552.operator_context = "EXEC_DEFAULT"
            col_D0F08 = box_EF552.column(heading='', align=False)
            col_D0F08.alert = False
            col_D0F08.enabled = True
            col_D0F08.active = True
            col_D0F08.use_property_split = False
            col_D0F08.use_property_decorate = False
            col_D0F08.scale_x = 1.0
            col_D0F08.scale_y = 1.0
            col_D0F08.alignment = 'Expand'.upper()
            col_D0F08.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            split_EFF9B = col_D0F08.split(factor=0.75, align=False)
            split_EFF9B.alert = False
            split_EFF9B.enabled = True
            split_EFF9B.active = True
            split_EFF9B.use_property_split = False
            split_EFF9B.use_property_decorate = False
            split_EFF9B.scale_x = 1.0
            split_EFF9B.scale_y = 1.75
            split_EFF9B.alignment = 'Expand'.upper()
            if not True: split_EFF9B.operator_context = "EXEC_DEFAULT"
            op = split_EFF9B.operator('sna.call_bake_normals_2223e', text='Bake Normals', icon_value=127, emboss=True, depress=False)
            op = split_EFF9B.operator('sna.bake_normals_quick_settings_8158b', text='', icon_value=702, emboss=True, depress=False)
            col_FD0DE = col_D0F08.column(heading='', align=False)
            col_FD0DE.alert = False
            col_FD0DE.enabled = True
            col_FD0DE.active = True
            col_FD0DE.use_property_split = False
            col_FD0DE.use_property_decorate = False
            col_FD0DE.scale_x = 1.0
            col_FD0DE.scale_y = 1.0
            col_FD0DE.alignment = 'Expand'.upper()
            col_FD0DE.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_589E6 = col_FD0DE.column(heading='', align=False)
            col_589E6.alert = False
            col_589E6.enabled = True
            col_589E6.active = True
            col_589E6.use_property_split = False
            col_589E6.use_property_decorate = False
            col_589E6.scale_x = 1.0
            col_589E6.scale_y = 1.0
            col_589E6.alignment = 'Expand'.upper()
            col_589E6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_72EAF = col_589E6.row(heading='', align=True)
            row_72EAF.alert = False
            row_72EAF.enabled = True
            row_72EAF.active = True
            row_72EAF.use_property_split = False
            row_72EAF.use_property_decorate = False
            row_72EAF.scale_x = 1.0
            row_72EAF.scale_y = 1.0
            row_72EAF.alignment = 'Expand'.upper()
            row_72EAF.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_72EAF.prop(bpy.context.scene.render, 'engine', text='', icon_value=0, emboss=True)
            row_72EAF.prop(bpy.context.scene.cycles, 'device', text='', icon_value=0, emboss=True)
            row_89A69 = col_589E6.row(heading='', align=True)
            row_89A69.alert = False
            row_89A69.enabled = True
            row_89A69.active = True
            row_89A69.use_property_split = False
            row_89A69.use_property_decorate = False
            row_89A69.scale_x = 1.0
            row_89A69.scale_y = 1.0
            row_89A69.alignment = 'Expand'.upper()
            row_89A69.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_89A69.prop(bpy.context.scene.cycles, 'bake_type', text='', icon_value=0, emboss=True)
            row_89A69.prop(bpy.context.scene.cycles, 'samples', text='', icon_value=0, emboss=True)
            col_589E6.prop(bpy.context.scene.render.bake, 'use_selected_to_active', text='Selected To Active', icon_value=0, emboss=True)
            col_589E6.prop(bpy.context.scene.render.bake, 'cage_extrusion', text='Extrusion', icon_value=0, emboss=True)
            box_D4299 = col_909AE.box()
            box_D4299.alert = False
            box_D4299.enabled = True
            box_D4299.active = True
            box_D4299.use_property_split = False
            box_D4299.use_property_decorate = False
            box_D4299.alignment = 'Expand'.upper()
            box_D4299.scale_x = 1.0
            box_D4299.scale_y = 1.0
            if not True: box_D4299.operator_context = "EXEC_DEFAULT"
            col_68D9D = box_D4299.column(heading='', align=False)
            col_68D9D.alert = False
            col_68D9D.enabled = True
            col_68D9D.active = True
            col_68D9D.use_property_split = False
            col_68D9D.use_property_decorate = False
            col_68D9D.scale_x = 1.0
            col_68D9D.scale_y = 1.0
            col_68D9D.alignment = 'Expand'.upper()
            col_68D9D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_68D9D.label(text='Explode Options', icon_value=0)
            col_68D9D.prop(bpy.context.scene, 'sna_margin', text='Margin', icon_value=0, emboss=True)
            col_68D9D.prop(bpy.context.scene, 'sna_items', text='Axis', icon_value=0, emboss=True)
            row_DD7F3 = col_68D9D.row(heading='', align=True)
            row_DD7F3.alert = False
            row_DD7F3.enabled = True
            row_DD7F3.active = True
            row_DD7F3.use_property_split = False
            row_DD7F3.use_property_decorate = False
            row_DD7F3.scale_x = 1.0
            row_DD7F3.scale_y = 1.2699999809265137
            row_DD7F3.alignment = 'Expand'.upper()
            row_DD7F3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_CFA20 = row_DD7F3.column(heading='', align=True)
            col_CFA20.alert = False
            col_CFA20.enabled = True
            col_CFA20.active = True
            col_CFA20.use_property_split = False
            col_CFA20.use_property_decorate = False
            col_CFA20.scale_x = 1.0
            col_CFA20.scale_y = 2.0
            col_CFA20.alignment = 'Expand'.upper()
            col_CFA20.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_CFA20.operator('sna.explode_selected_05499', text='Explode', icon_value=468, emboss=True, depress=False)
            row_5C81D = row_DD7F3.row(heading='', align=True)
            row_5C81D.alert = False
            row_5C81D.enabled = True
            row_5C81D.active = True
            row_5C81D.use_property_split = False
            row_5C81D.use_property_decorate = False
            row_5C81D.scale_x = 1.0
            row_5C81D.scale_y = 1.0
            row_5C81D.alignment = 'Right'.upper()
            row_5C81D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_CF894 = row_5C81D.column(heading='', align=True)
            col_CF894.alert = False
            col_CF894.enabled = True
            col_CF894.active = True
            col_CF894.use_property_split = False
            col_CF894.use_property_decorate = False
            col_CF894.scale_x = 1.1799999475479126
            col_CF894.scale_y = 1.0
            col_CF894.alignment = 'Expand'.upper()
            col_CF894.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_CF894.operator('sna.reset_all_world_origin_943b2', text='', icon_value=135, emboss=True, depress=False)
            op = col_CF894.operator('view3d.snap_selected_to_cursor', text='', icon_value=623, emboss=True, depress=False)


class SNA_OT_Explode_Selected_05499(bpy.types.Operator):
    bl_idname = "sna.explode_selected_05499"
    bl_label = "Explode Selected"
    bl_description = "Evenly space all selected objects along specified axis"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnexplodeselected_32E49()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnexplodeselected_32E49():
    objects = bpy.context.view_layer.objects.selected
    margin = bpy.context.scene.sna_margin
    axis = bpy.context.scene.sna_items

    def explode_objects(objects, axis, margin):
        # Sort objects based on their current location
        sorted_objects = sorted(objects, key=lambda obj: obj.location)
        # Get the starting position at (0, 0, 0)
        current_position = Vector((0, 0, 0))
        # Explode objects along the chosen axis
        for obj in sorted_objects:
            bbox = get_bbox(obj)
            obj.location = current_position
            # Update position based on bounding box size + margin along the chosen axis
            if axis == 'x':
                current_position.x += bbox['size'].x + margin
            elif axis == '-x':
                current_position.x -= bbox['size'].x + margin
            elif axis == 'y':
                current_position.y += bbox['size'].y + margin
            elif axis == '-y':
                current_position.y -= bbox['size'].y + margin
            elif axis == 'z':
                current_position.z += bbox['size'].z + margin
            elif axis == '-z':
                current_position.z -= bbox['size'].z + margin

    def get_bbox(obj):
        corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
        # Get world space Min / Max
        box_min = Vector((corners[0].x, corners[0].y, corners[0].z))
        box_max = Vector((corners[0].x, corners[0].y, corners[0].z))
        for corner in corners:
            box_min.x = min(box_min.x, corner.x)
            box_min.y = min(box_min.y, corner.y)
            box_min.z = min(box_min.z, corner.z)
            box_max.x = max(box_max.x, corner.x)
            box_max.y = max(box_max.y, corner.y)
            box_max.z = max(box_max.z, corner.z)
        return {
            'min': box_min, 
            'max': box_max, 
            'size': box_max - box_min,
            'center': box_min + (box_max - box_min) / 2
        }
    explode_objects(objects, axis, margin)


class SNA_OT_Reset_All_World_Origin_943B2(bpy.types.Operator):
    bl_idname = "sna.reset_all_world_origin_943b2"
    bl_label = "Reset All World Origin"
    bl_description = "Set location of selected objects to 0,0,0"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_fnresettoworld_9870B()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fnresettoworld_9870B():
    for i_9FC85 in range(len(bpy.context.view_layer.objects.selected)):
        bpy.context.view_layer.objects.selected[i_9FC85].location = (0.0, 0.0, 0.0)


class SNA_OT_Toggle_More_Object_Options_37109(bpy.types.Operator):
    bl_idname = "sna.toggle_more_object_options_37109"
    bl_label = "Toggle More Object Options"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_showmoreobjectopts = (not bpy.context.scene.sna_showmoreobjectopts)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Call_Bake_Normals_2223E(bpy.types.Operator):
    bl_idname = "sna.call_bake_normals_2223e"
    bl_label = "Call Bake Normals"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('run_bake()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Bake_Normals_Quick_Settings_8158B(bpy.types.Operator):
    bl_idname = "sna.bake_normals_quick_settings_8158b"
    bl_label = "Bake Normals Quick Settings"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('set_bake_normal_preset()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_SETTINGS_PANEL_A1997(bpy.types.Panel):
    bl_label = 'Settings Panel'
    bl_idname = 'SNA_PT_SETTINGS_PANEL_A1997'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 5
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not bpy.context.scene.sna_showrendersettings))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Compendium Settings', icon_value=0)
        box_407F8 = layout.box()
        box_407F8.alert = False
        box_407F8.enabled = True
        box_407F8.active = True
        box_407F8.use_property_split = False
        box_407F8.use_property_decorate = False
        box_407F8.alignment = 'Expand'.upper()
        box_407F8.scale_x = 1.0
        box_407F8.scale_y = 1.0
        if not True: box_407F8.operator_context = "EXEC_DEFAULT"
        box_407F8.prop(bpy.context.scene, 'sna_usecompendiumempty', text='Use Compendium Empty', icon_value=0, emboss=True)
        box_407F8.prop(bpy.context.preferences.inputs, 'use_mouse_emulate_3_button', text='Emulate Mouse 3', icon_value=0, emboss=True)
        layout.label(text='Render Settings:', icon_value=0)
        box_DBA4D = layout.box()
        box_DBA4D.alert = False
        box_DBA4D.enabled = True
        box_DBA4D.active = True
        box_DBA4D.use_property_split = False
        box_DBA4D.use_property_decorate = False
        box_DBA4D.alignment = 'Expand'.upper()
        box_DBA4D.scale_x = 1.0
        box_DBA4D.scale_y = 1.0
        if not True: box_DBA4D.operator_context = "EXEC_DEFAULT"
        box_DBA4D.prop(bpy.context.scene.render, 'film_transparent', text='Transparent Background', icon_value=0, emboss=True)
        box_47E4A = box_DBA4D.box()
        box_47E4A.alert = False
        box_47E4A.enabled = True
        box_47E4A.active = True
        box_47E4A.use_property_split = False
        box_47E4A.use_property_decorate = False
        box_47E4A.alignment = 'Expand'.upper()
        box_47E4A.scale_x = 1.0
        box_47E4A.scale_y = 1.0
        if not True: box_47E4A.operator_context = "EXEC_DEFAULT"
        col_6E868 = box_47E4A.column(heading='', align=False)
        col_6E868.alert = False
        col_6E868.enabled = True
        col_6E868.active = True
        col_6E868.use_property_split = False
        col_6E868.use_property_decorate = False
        col_6E868.scale_x = 1.0
        col_6E868.scale_y = 1.0
        col_6E868.alignment = 'Expand'.upper()
        col_6E868.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_6E868.label(text='Screen Res', icon_value=0)
        op = col_6E868.operator('sna.set_screen_peset_45d5e', text='Full HD', icon_value=0, emboss=True, depress=False)
        op.sna_preset = 'FullHD'
        op = col_6E868.operator('sna.set_screen_peset_45d5e', text='2K', icon_value=0, emboss=True, depress=False)
        op.sna_preset = '2k'
        op = col_6E868.operator('sna.set_screen_peset_45d5e', text='Square 520', icon_value=0, emboss=True, depress=False)
        op.sna_preset = '520'
        op = col_6E868.operator('sna.set_screen_peset_45d5e', text='Square 1040', icon_value=0, emboss=True, depress=False)
        op.sna_preset = '1040'
        op = col_6E868.operator('sna.set_screen_peset_45d5e', text='Square 2080', icon_value=0, emboss=True, depress=False)
        op.sna_preset = '2080'
        box_DBA4D.prop(bpy.context.scene.render.image_settings, 'file_format', text='', icon_value=0, emboss=True)


class SNA_PT_VERTEX_PAINT_TOOLS_D5E3C(bpy.types.Panel):
    bl_label = 'Vertex Paint Tools'
    bl_idname = 'SNA_PT_VERTEX_PAINT_TOOLS_D5E3C'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'VCM'
    bl_order = 3
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not 'PAINT_VERTEX'==bpy.context.mode))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_fnviewportuniversal_70EA3(layout_function, )


class SNA_PT_WEIGHT_PAINT_TOOLS_BB3C6(bpy.types.Panel):
    bl_label = 'Weight Paint Tools'
    bl_idname = 'SNA_PT_WEIGHT_PAINT_TOOLS_BB3C6'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 3
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not ('PAINT_WEIGHT'==bpy.context.mode and bpy.context.scene.sna_showtools)))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_1BB24 = layout.column(heading='', align=False)
        col_1BB24.alert = False
        col_1BB24.enabled = True
        col_1BB24.active = True
        col_1BB24.use_property_split = False
        col_1BB24.use_property_decorate = False
        col_1BB24.scale_x = 1.0
        col_1BB24.scale_y = 1.0
        col_1BB24.alignment = 'Expand'.upper()
        col_1BB24.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_1BB24.separator(factor=1.0)
        col_1BB24.label(text='Weight Paint', icon_value=0)
        row_8451C = col_1BB24.row(heading='', align=True)
        row_8451C.alert = False
        row_8451C.enabled = True
        row_8451C.active = True
        row_8451C.use_property_split = False
        row_8451C.use_property_decorate = False
        row_8451C.scale_x = 1.4500000476837158
        row_8451C.scale_y = 1.3899999856948853
        row_8451C.alignment = 'Expand'.upper()
        row_8451C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_E7972 = row_8451C.row(heading='', align=True)
        row_E7972.alert = False
        row_E7972.enabled = True
        row_E7972.active = True
        row_E7972.use_property_split = False
        row_E7972.use_property_decorate = False
        row_E7972.scale_x = 1.0
        row_E7972.scale_y = 1.0
        row_E7972.alignment = 'Expand'.upper()
        row_E7972.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_D46DB = row_E7972.row(heading='', align=True)
        row_D46DB.alert = False
        row_D46DB.enabled = True
        row_D46DB.active = True
        row_D46DB.use_property_split = False
        row_D46DB.use_property_decorate = False
        row_D46DB.scale_x = 1.0
        row_D46DB.scale_y = 1.0
        row_D46DB.alignment = 'Left'.upper()
        row_D46DB.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_D46DB.operator('sna.toggle_weight_1d114', text='', icon_value=100, emboss=True, depress=False)
        op.sna_is_zero = True
        row_E7972.prop(bpy.context.scene.tool_settings.unified_paint_settings, 'weight', text='Weight', icon_value=0, emboss=True)
        row_7B503 = row_E7972.row(heading='', align=True)
        row_7B503.alert = False
        row_7B503.enabled = True
        row_7B503.active = True
        row_7B503.use_property_split = False
        row_7B503.use_property_decorate = False
        row_7B503.scale_x = 1.0
        row_7B503.scale_y = 1.0
        row_7B503.alignment = 'Right'.upper()
        row_7B503.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_7B503.operator('sna.toggle_weight_1d114', text='', icon_value=101, emboss=True, depress=False)
        op.sna_is_zero = False
        row_8451C.separator(factor=1.0)
        row_0F41B = row_8451C.row(heading='', align=True)
        row_0F41B.alert = False
        row_0F41B.enabled = True
        row_0F41B.active = True
        row_0F41B.use_property_split = False
        row_0F41B.use_property_decorate = False
        row_0F41B.scale_x = 1.0
        row_0F41B.scale_y = 1.0
        row_0F41B.alignment = 'Right'.upper()
        row_0F41B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_0F41B.operator('sna.custom_set_weight_2f5d4', text='', icon_value=192, emboss=True, depress=False)
        col_1BB24.label(text='OPS', icon_value=0)
        row_0C2FC = col_1BB24.row(heading='', align=False)
        row_0C2FC.alert = False
        row_0C2FC.enabled = True
        row_0C2FC.active = True
        row_0C2FC.use_property_split = False
        row_0C2FC.use_property_decorate = False
        row_0C2FC.scale_x = 1.0
        row_0C2FC.scale_y = 1.0
        row_0C2FC.alignment = 'Expand'.upper()
        row_0C2FC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_0C2FC.operator('object.vertex_group_smooth', text='Smooth', icon_value=0, emboss=True, depress=False)
        op = row_0C2FC.operator('object.vertex_group_mirror', text='Mirror', icon_value=0, emboss=True, depress=False)
        if (bpy.context.view_layer.objects.active.data.use_paint_mask_vertex or bpy.context.view_layer.objects.active.data.use_paint_mask):
            row_28FE8 = col_1BB24.row(heading='', align=True)
            row_28FE8.alert = False
            row_28FE8.enabled = True
            row_28FE8.active = True
            row_28FE8.use_property_split = False
            row_28FE8.use_property_decorate = False
            row_28FE8.scale_x = 1.0
            row_28FE8.scale_y = 1.0
            row_28FE8.alignment = 'Expand'.upper()
            row_28FE8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            if bpy.context.view_layer.objects.active.data.use_paint_mask_vertex:
                op = row_28FE8.operator('paint.vert_select_less', text='Less', icon_value=91, emboss=True, depress=False)
            else:
                op = row_28FE8.operator('paint.face_select_less', text='Less', icon_value=91, emboss=True, depress=False)
            if bpy.context.view_layer.objects.active.data.use_paint_mask_vertex:
                op = row_28FE8.operator('paint.vert_select_more', text='More', icon_value=48, emboss=True, depress=False)
            else:
                op = row_28FE8.operator('paint.face_select_more', text='More', icon_value=48, emboss=True, depress=False)
            row_28FE8.separator(factor=1.0)
            if bpy.context.view_layer.objects.active.data.use_paint_mask_vertex:
                op = row_28FE8.operator('paint.vert_select_linked', text='Linked', icon_value=79, emboss=True, depress=False)
            else:
                op = row_28FE8.operator('paint.vert_select_linked', text='Linked', icon_value=79, emboss=True, depress=False)


class SNA_OT_Custom_Set_Weight_2F5D4(bpy.types.Operator):
    bl_idname = "sna.custom_set_weight_2f5d4"
    bl_label = "Custom Set Weight"
    bl_description = "Set weight of selected verts and refreshes view"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        prev_context = bpy.context.area.type
        bpy.context.area.type = 'VIEW_3D'
        bpy.ops.paint.weight_set('INVOKE_DEFAULT', )
        bpy.context.area.type = prev_context
        if bpy.context and bpy.context.screen:
            for a in bpy.context.screen.areas:
                a.tag_redraw()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Weight_1D114(bpy.types.Operator):
    bl_idname = "sna.toggle_weight_1d114"
    bl_label = "Toggle Weight"
    bl_description = "Set weight to 0 or 1"
    bl_options = {"REGISTER", "UNDO"}
    sna_is_zero: bpy.props.BoolProperty(name='is_zero', description='', options={'HIDDEN'}, default=False)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if self.sna_is_zero:
            bpy.context.scene.tool_settings.unified_paint_settings.weight = 0.0
        else:
            bpy.context.scene.tool_settings.unified_paint_settings.weight = 1.0
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_WORKFLOW_4ACA3(bpy.types.Panel):
    bl_label = 'Workflow'
    bl_idname = 'SNA_PT_WORKFLOW_4ACA3'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Compendium'
    bl_order = 2
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((not bpy.context.scene.sna_showworkflow))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_715CD = layout.row(heading='', align=False)
        row_715CD.alert = False
        row_715CD.enabled = True
        row_715CD.active = True
        row_715CD.use_property_split = False
        row_715CD.use_property_decorate = False
        row_715CD.scale_x = 1.0
        row_715CD.scale_y = 1.0
        row_715CD.alignment = 'Expand'.upper()
        row_715CD.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_715CD.label(text='Viewport', icon_value=0)
        row_99721 = row_715CD.row(heading='', align=True)
        row_99721.alert = False
        row_99721.enabled = True
        row_99721.active = True
        row_99721.use_property_split = False
        row_99721.use_property_decorate = False
        row_99721.scale_x = 1.0
        row_99721.scale_y = 1.0
        row_99721.alignment = 'Right'.upper()
        row_99721.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_99721.operator('sna.set_pro_snap_b7a8b', text='', icon_value=86, emboss=True, depress=False)
        op = row_99721.operator('sna.set_snap_face_1fc09', text='', icon_value=597, emboss=True, depress=False)
        op = row_99721.operator('sna.set_snap_increment_aff86', text='', icon_value=599, emboss=True, depress=False)
        box_7A73C = layout.box()
        box_7A73C.alert = False
        box_7A73C.enabled = True
        box_7A73C.active = True
        box_7A73C.use_property_split = False
        box_7A73C.use_property_decorate = False
        box_7A73C.alignment = 'Expand'.upper()
        box_7A73C.scale_x = 1.0
        box_7A73C.scale_y = 1.0
        if not True: box_7A73C.operator_context = "EXEC_DEFAULT"
        layout_function = box_7A73C
        sna_fnviewportuniversal_70EA3(layout_function, )
        if 'EDIT_MESH'==bpy.context.mode:
            row_02D6E = box_7A73C.row(heading='', align=True)
            row_02D6E.alert = False
            row_02D6E.enabled = True
            row_02D6E.active = True
            row_02D6E.use_property_split = False
            row_02D6E.use_property_decorate = False
            row_02D6E.scale_x = 1.0
            row_02D6E.scale_y = 1.100000023841858
            row_02D6E.alignment = 'Expand'.upper()
            row_02D6E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_02D6E.operator('sna.toggle_show_creases_48169', text='Crease', icon_value=0, emboss=True, depress=bpy.context.area.spaces.active.overlay.show_edge_crease)
            op = row_02D6E.operator('sna.toggle_show_sharps_28e50', text='Sharp', icon_value=0, emboss=True, depress=bpy.context.area.spaces.active.overlay.show_edge_sharp)
            op = row_02D6E.operator('sna.toggle_show_bevels_cb2f7', text='Bevel', icon_value=0, emboss=True, depress=bpy.context.area.spaces.active.overlay.show_edge_bevel_weight)
            op = row_02D6E.operator('sna.toggle_show_seams_7408d', text='Seams', icon_value=0, emboss=True, depress=bpy.context.area.spaces.active.overlay.show_edge_seams)
        if (bpy.context.view_layer.objects.active == None):
            pass
        else:
            if bpy.context.view_layer.objects.active.type == 'CAMERA':
                box_7A73C.prop(bpy.context.area.spaces[0], 'lock_camera', text='Camera To View', icon_value=(650 if bpy.context.area.spaces[0].lock_camera else 654), emboss=True)
        if (bpy.context.view_layer.objects.active == None):
            pass
        else:
            if bpy.context.view_layer.objects.active.type == 'CAMERA':
                box_0A973 = box_7A73C.box()
                box_0A973.alert = False
                box_0A973.enabled = True
                box_0A973.active = True
                box_0A973.use_property_split = False
                box_0A973.use_property_decorate = False
                box_0A973.alignment = 'Expand'.upper()
                box_0A973.scale_x = 1.0
                box_0A973.scale_y = 1.0
                if not True: box_0A973.operator_context = "EXEC_DEFAULT"
                col_569F9 = box_0A973.column(heading='', align=False)
                col_569F9.alert = False
                col_569F9.enabled = True
                col_569F9.active = True
                col_569F9.use_property_split = False
                col_569F9.use_property_decorate = False
                col_569F9.scale_x = 1.0
                col_569F9.scale_y = 1.0
                col_569F9.alignment = 'Expand'.upper()
                col_569F9.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                col_569F9.label(text='Camera Locations', icon_value=0)
                row_65B5A = col_569F9.row(heading='', align=True)
                row_65B5A.alert = False
                row_65B5A.enabled = True
                row_65B5A.active = True
                row_65B5A.use_property_split = False
                row_65B5A.use_property_decorate = False
                row_65B5A.scale_x = 1.0
                row_65B5A.scale_y = 1.0
                row_65B5A.alignment = 'Expand'.upper()
                row_65B5A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_FD1A0 = row_65B5A.row(heading='', align=False)
                row_FD1A0.alert = False
                row_FD1A0.enabled = True
                row_FD1A0.active = True
                row_FD1A0.use_property_split = False
                row_FD1A0.use_property_decorate = False
                row_FD1A0.scale_x = 1.0
                row_FD1A0.scale_y = 1.0
                row_FD1A0.alignment = 'Expand'.upper()
                row_FD1A0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_FD1A0.prop(bpy.context.scene, 'sna_locationname', text='', icon_value=0, emboss=True)
                row_D10F3 = row_65B5A.row(heading='', align=False)
                row_D10F3.alert = False
                row_D10F3.enabled = True
                row_D10F3.active = True
                row_D10F3.use_property_split = False
                row_D10F3.use_property_decorate = False
                row_D10F3.scale_x = 1.0
                row_D10F3.scale_y = 1.0
                row_D10F3.alignment = 'Right'.upper()
                row_D10F3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                op = row_D10F3.operator('sna.add_camera_loaction_1e5f9', text='', icon_value=48, emboss=True, depress=False)
                col_569F9.separator(factor=1.0)
                for i_25855 in range(len(bpy.context.scene.sna_camlocs)):
                    row_3F6B2 = col_569F9.row(heading='', align=True)
                    row_3F6B2.alert = False
                    row_3F6B2.enabled = True
                    row_3F6B2.active = True
                    row_3F6B2.use_property_split = False
                    row_3F6B2.use_property_decorate = False
                    row_3F6B2.scale_x = 1.0
                    row_3F6B2.scale_y = 1.0
                    row_3F6B2.alignment = 'Expand'.upper()
                    row_3F6B2.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                    row_71A8B = row_3F6B2.row(heading='', align=True)
                    row_71A8B.alert = False
                    row_71A8B.enabled = True
                    row_71A8B.active = True
                    row_71A8B.use_property_split = False
                    row_71A8B.use_property_decorate = False
                    row_71A8B.scale_x = 1.0
                    row_71A8B.scale_y = 1.0
                    row_71A8B.alignment = 'Expand'.upper()
                    row_71A8B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                    op = row_71A8B.operator('sna.setcameratolocation_78754', text=bpy.context.scene.sna_camlocs[i_25855].name, icon_value=0, emboss=True, depress=False)
                    op.sna_id = i_25855
                    row_6D4AC = row_3F6B2.row(heading='', align=True)
                    row_6D4AC.alert = False
                    row_6D4AC.enabled = True
                    row_6D4AC.active = True
                    row_6D4AC.use_property_split = False
                    row_6D4AC.use_property_decorate = False
                    row_6D4AC.scale_x = 1.0
                    row_6D4AC.scale_y = 1.0
                    row_6D4AC.alignment = 'Right'.upper()
                    row_6D4AC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                    op = row_6D4AC.operator('sna.remove_camera_location_37a38', text='', icon_value=108, emboss=True, depress=False)
                    op.sna_id = i_25855
        col_E705A = layout.column(heading='', align=True)
        col_E705A.alert = False
        col_E705A.enabled = True
        col_E705A.active = True
        col_E705A.use_property_split = False
        col_E705A.use_property_decorate = False
        col_E705A.scale_x = 1.0
        col_E705A.scale_y = 1.0
        col_E705A.alignment = 'Expand'.upper()
        col_E705A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_E705A.operator('sna.toggle_workflow_options_05d4c', text='', icon_value=(34 if bpy.context.scene.sna_showwfoptions else 33), emboss=True, depress=False)
        if bpy.context.scene.sna_showwfoptions:
            row_4E062 = col_E705A.row(heading='', align=True)
            row_4E062.alert = False
            row_4E062.enabled = True
            row_4E062.active = True
            row_4E062.use_property_split = False
            row_4E062.use_property_decorate = False
            row_4E062.scale_x = 1.0
            row_4E062.scale_y = 1.0
            row_4E062.alignment = 'Expand'.upper()
            row_4E062.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_4E062.operator('sna.set_sculpt_workflow_27f56', text='Sculpt', icon_value=0, emboss=True, depress=bpy.context.scene.sna_sculptworkflow)
            op = row_4E062.operator('sna.set_vertex_paint_workflow_b1688', text='Vertex', icon_value=0, emboss=True, depress=bpy.context.scene.sna_vpworkflow)
            op = row_4E062.operator('sna.set_weight_paint_workflow_c2eda', text='Weight', icon_value=0, emboss=True, depress=bpy.context.scene.sna_wpworkflow)
        if bpy.context.scene.sna_wpworkflow:
            row_33757 = layout.row(heading='', align=True)
            row_33757.alert = False
            row_33757.enabled = True
            row_33757.active = True
            row_33757.use_property_split = False
            row_33757.use_property_decorate = False
            row_33757.scale_x = 1.0
            row_33757.scale_y = 1.0
            row_33757.alignment = 'Expand'.upper()
            row_33757.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_33757.label(text='Auto Select', icon_value=0)
            op = row_33757.operator('sna.toggleautoselectarmature_c5316', text='None', icon_value=0, emboss=True, depress=(bpy.context.scene.sna_selectweightpaintmode == 'NoAuto'))
            op.sna_selection = 'NoAuto'
            op = row_33757.operator('sna.toggleautoselectarmature_c5316', text='Vertex', icon_value=0, emboss=True, depress=(bpy.context.scene.sna_selectweightpaintmode == 'Vertex'))
            op.sna_selection = 'Vertex'
            op = row_33757.operator('sna.toggleautoselectarmature_c5316', text='Armature', icon_value=0, emboss=True, depress=(bpy.context.scene.sna_selectweightpaintmode == 'Armature'))
            op.sna_selection = 'Armature'


class SNA_OT_Toggleautoselectarmature_C5316(bpy.types.Operator):
    bl_idname = "sna.toggleautoselectarmature_c5316"
    bl_label = "ToggleAutoSelectArmature"
    bl_description = "Set switching behavior for Weight Paint Mode. None - Behaves as default. Vertex - Auto enables vertex selection. Armature - If object has a parent armature, this will auto select it so you can select(alt click) the bones you are painting."
    bl_options = {"REGISTER", "UNDO"}

    def sna_selection_enum_items(self, context):
        return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]
    sna_selection: bpy.props.EnumProperty(name='Selection', description='', options={'HIDDEN'}, items=[('NoAuto', 'NoAuto', '', 0, 0), ('Vertex', 'Vertex', '', 0, 1), ('Armature', 'Armature', '', 0, 2)])

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if self.sna_selection == "NoAuto":
            bpy.context.scene.sna_selectweightpaintmode = self.sna_selection
        elif self.sna_selection == "Vertex":
            bpy.context.scene.sna_selectweightpaintmode = self.sna_selection
        elif self.sna_selection == "Armature":
            bpy.context.scene.sna_selectweightpaintmode = self.sna_selection
        else:
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Snap_Increment_Aff86(bpy.types.Operator):
    bl_idname = "sna.set_snap_increment_aff86"
    bl_label = "Set Snap Increment"
    bl_description = "Set the snap mode to: Snap Base > Center, Snap Target > Increment, Snap Rotate, Snap Translate, Align Rotation"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('set_snap_mode("INCREMENT")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Snap_Face_1Fc09(bpy.types.Operator):
    bl_idname = "sna.set_snap_face_1fc09"
    bl_label = "Set Snap Face"
    bl_description = "Set the snap mode to: Snap Base > Center, Snap Target > Face, Snap Rotate, Snap Translate, Align Rotation"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('set_snap_mode("FACE")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Pro_Snap_B7A8B(bpy.types.Operator):
    bl_idname = "sna.set_pro_snap_b7a8b"
    bl_label = "Set Pro Snap"
    bl_description = "Set the snap mode to work well with Gizmo Pro: Snap Base > Center, Snap Target > Vertex/Edge Center/Face Center, Snap Rotate, Snap Translate"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('set_snap_mode("PRO")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_MT_F2EBE(bpy.types.Menu):
    bl_idname = "SNA_MT_F2EBE"
    bl_label = "Compendium Modes Pie"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.menu_pie()
        if ('OBJECT'==bpy.context.mode or 'EDIT_MESH'==bpy.context.mode):
            if bpy.context.view_layer.objects.active.type == 'MESH':
                op = layout.operator('sna.vert_mode_34ed6', text='Vert', icon_value=592, emboss=True, depress=False)
            else:
                layout.separator(factor=1.0)
        else:
            if 'PAINT_WEIGHT'==bpy.context.mode:
                layout.prop(bpy.context.view_layer.objects.active.data, 'use_paint_mask', text='', icon_value=0, emboss=True)
            else:
                layout.separator(factor=1.0)
        if ('OBJECT'==bpy.context.mode or 'EDIT_MESH'==bpy.context.mode):
            if bpy.context.view_layer.objects.active.type == 'MESH':
                op = layout.operator('sna.face_mode_44e6b', text='Face', icon_value=571, emboss=True, depress=False)
            else:
                layout.separator(factor=1.0)
        else:
            if 'PAINT_WEIGHT'==bpy.context.mode:
                if (bpy.context.view_layer.objects.active.parent == None):
                    layout.separator(factor=1.0)
                else:
                    if bpy.context.view_layer.objects.active.parent.type == 'ARMATURE':
                        layout.prop(bpy.context.view_layer.objects.active.data, 'use_paint_bone_selection', text='', icon_value=0, emboss=True)
                    else:
                        layout.separator(factor=1.0)
            else:
                layout.separator(factor=1.0)
        if ('OBJECT'==bpy.context.mode or 'EDIT_MESH'==bpy.context.mode):
            if bpy.context.view_layer.objects.active.type == 'MESH':
                op = layout.operator('sna.edge_mode_74d78', text='Edge', icon_value=565, emboss=True, depress=False)
            else:
                layout.separator(factor=1.0)
        else:
            if 'PAINT_WEIGHT'==bpy.context.mode:
                layout.prop(bpy.context.view_layer.objects.active.data, 'use_paint_mask_vertex', text='', icon_value=0, emboss=False)
            else:
                layout.separator(factor=1.0)
        if 'OBJECT'==bpy.context.mode:
            op = layout.operator('object.mode_set', text='Edit', icon_value=163, emboss=True, depress=False)
            op.mode = 'EDIT'
        else:
            op = layout.operator('object.mode_set', text='Object', icon_value=164, emboss=True, depress=False)
            op.mode = 'OBJECT'
        if 'POSE'==bpy.context.mode:
            layout.separator(factor=1.0)
        else:
            if bpy.context.view_layer.objects.active.type == 'ARMATURE':
                layout.separator(factor=1.0)
            else:
                row_43D41 = layout.row(heading='', align=True)
                row_43D41.alert = False
                row_43D41.enabled = True
                row_43D41.active = True
                row_43D41.use_property_split = False
                row_43D41.use_property_decorate = False
                row_43D41.scale_x = 1.2999999523162842
                row_43D41.scale_y = 1.2999999523162842
                row_43D41.alignment = 'Expand'.upper()
                row_43D41.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                op = row_43D41.operator('object.mode_set', text='', icon_value=168, emboss=True, depress=False)
                op.mode = 'TEXTURE_PAINT'
                op = row_43D41.operator('object.mode_set', text='', icon_value=171, emboss=True, depress=False)
                op.mode = 'WEIGHT_PAINT'
                op = row_43D41.operator('sna.set_vertex_paint_mode_8ba67', text='', icon_value=170, emboss=True, depress=False)
                op = row_43D41.operator('object.mode_set', text='', icon_value=167, emboss=True, depress=False)
                op.mode = 'SCULPT'
                op = row_43D41.operator('object.mode_set', text='', icon_value=164, emboss=True, depress=False)
                op.mode = 'OBJECT'
                op = row_43D41.operator('object.mode_set', text='', icon_value=163, emboss=True, depress=False)
                op.mode = 'EDIT'
        if ('SCULPT'==bpy.context.mode or 'POSE'==bpy.context.mode):
            op = layout.operator('object.mode_set', text='Edit', icon_value=163, emboss=True, depress=False)
            op.mode = 'EDIT'
        else:
            if bpy.context.view_layer.objects.active.type == 'ARMATURE':
                op = layout.operator('object.mode_set', text='Pose', icon_value=164, emboss=True, depress=False)
                op.mode = 'POSE'
            else:
                if bpy.context.scene.sna_vpworkflow:
                    if 'PAINT_VERTEX'==bpy.context.mode:
                        op = layout.operator('object.mode_set', text='Edit', icon_value=163, emboss=True, depress=False)
                        op.mode = 'EDIT'
                    else:
                        op = layout.operator('sna.set_vertex_paint_mode_box_select_3230d', text='Vertex Paint', icon_value=170, emboss=True, depress=False)
                else:
                    if bpy.context.scene.sna_wpworkflow:
                        if 'PAINT_WEIGHT'==bpy.context.mode:
                            op = layout.operator('object.mode_set', text='Edit', icon_value=163, emboss=True, depress=False)
                            op.mode = 'EDIT'
                        else:
                            op = layout.operator('sna.set_weight_paint_3b8d6', text='Weight Paint', icon_value=171, emboss=True, depress=False)
                    else:
                        op = layout.operator('object.mode_set', text='Sculpt', icon_value=167, emboss=True, depress=False)
                        op.mode = 'SCULPT'
        layout.separator(factor=1.0)


class SNA_OT_Face_Mode_44E6B(bpy.types.Operator):
    bl_idname = "sna.face_mode_44e6b"
    bl_label = "Face Mode"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if 'EDIT_MESH'==bpy.context.mode:
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='FACE', action='ENABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='EDGE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='DISABLE')
        else:
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='EDIT')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='FACE', action='ENABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='EDGE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='DISABLE')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Vert_Mode_34Ed6(bpy.types.Operator):
    bl_idname = "sna.vert_mode_34ed6"
    bl_label = "Vert Mode"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if 'EDIT_MESH'==bpy.context.mode:
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='FACE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='EDGE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='ENABLE')
        else:
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='EDIT')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='FACE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='EDGE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='ENABLE')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Edge_Mode_74D78(bpy.types.Operator):
    bl_idname = "sna.edge_mode_74d78"
    bl_label = "Edge Mode"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if 'EDIT_MESH'==bpy.context.mode:
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='FACE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='EDGE', action='ENABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='DISABLE')
        else:
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='EDIT')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='FACE', action='DISABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='EDGE', action='ENABLE')
            bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='DISABLE')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Weight_Paint_3B8D6(bpy.types.Operator):
    bl_idname = "sna.set_weight_paint_3b8d6"
    bl_label = "Set Weight Paint"
    bl_description = "Custom Set weight paint mode and auto set box select mode"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.scene.sna_selectweightpaintmode == "NoAuto":
            prev_context = bpy.context.area.type
            bpy.context.area.type = 'VIEW_3D'
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='WEIGHT_PAINT')
            bpy.context.area.type = prev_context
        elif bpy.context.scene.sna_selectweightpaintmode == "Armature":

            def smart_weight_paint():
                ctx        = bpy.context
                active_obj = ctx.active_object
                # 1. Preconditions -----------------------------------------------------------------
                if not (active_obj and active_obj.type == 'MESH'):
                    print("⚠️  Active object must be a mesh.")
                    return
                parent = active_obj.parent
                if not (parent and parent.type == 'ARMATURE'):
                    print("⚠️  Mesh has no armature parent.")
                    return
                # 2. Make sure we’re in Object mode -------------------------------------------------
                if ctx.object.mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
                # 3. Select armature + make mesh active --------------------------------------------
                bpy.ops.object.select_all(action='DESELECT')
                parent.select_set(True)              # keep armature selected (for bone picking)
                active_obj.select_set(True)
                ctx.view_layer.objects.active = active_obj
                # 4. Switch to Weight-Paint mode ----------------------------------------------------
                bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
                # 5. Enable bone-selection on the mesh ---------------------------------------------
                mesh = active_obj.data
                mesh.use_paint_mask          = False
                mesh.use_paint_mask_vertex   = False
                mesh.use_paint_bone_selection = True
                # 6. Activate the Weight-Paint brush tool ------------------------------------------
                try:
                    bpy.ops.wm.tool_set_by_id(name="builtin.brush")          # works in 4.3/4.4
                except RuntimeError:
                    # Fallback: set tool via workspace (never fails if the mode is correct)
                    ctx.workspace.tools.from_space_view3d_mode('PAINT_WEIGHT',
                                                               create=False).idname = "builtin.brush"
                print(" Ready: armature selected, bone selection on, weight-paint brush active.")
            # ------------------------------------------------------------------
            smart_weight_paint()
        elif bpy.context.scene.sna_selectweightpaintmode == "Vertex":
            prev_context = bpy.context.area.type
            bpy.context.area.type = 'VIEW_3D'
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='WEIGHT_PAINT')
            bpy.context.area.type = prev_context
            bpy.context.view_layer.objects.active.data.use_paint_mask_vertex = True
            prev_context = bpy.context.area.type
            bpy.context.area.type = 'VIEW_3D'
            bpy.ops.wm.tool_set_by_id('INVOKE_DEFAULT', name='builtin.select_box')
            bpy.context.area.type = prev_context
        else:
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Vertex_Paint_Mode_Box_Select_3230D(bpy.types.Operator):
    bl_idname = "sna.set_vertex_paint_mode_box_select_3230d"
    bl_label = "Set Vertex Paint Mode Box Select"
    bl_description = "Sets Vertex Paint mode with Box Select"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if ((bpy.context.view_layer.objects.active.data.use_paint_mask_vertex or bpy.context.view_layer.objects.active.data.use_paint_mask) == False):
            bpy.context.view_layer.objects.active.data.use_paint_mask_vertex = True
            prev_context = bpy.context.area.type
            bpy.context.area.type = 'VIEW_3D'
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='VERTEX_PAINT')
            bpy.context.area.type = prev_context
            prev_context = bpy.context.area.type
            bpy.context.area.type = 'VIEW_3D'
            bpy.ops.wm.tool_set_by_id('INVOKE_DEFAULT', name='builtin.select_box')
            bpy.context.area.type = prev_context
        else:
            prev_context = bpy.context.area.type
            bpy.context.area.type = 'VIEW_3D'
            bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='VERTEX_PAINT')
            bpy.context.area.type = prev_context
            prev_context = bpy.context.area.type
            bpy.context.area.type = 'VIEW_3D'
            bpy.ops.wm.tool_set_by_id('INVOKE_DEFAULT', name='builtin.select_box')
            bpy.context.area.type = prev_context
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Vertex_Paint_Mode_8Ba67(bpy.types.Operator):
    bl_idname = "sna.set_vertex_paint_mode_8ba67"
    bl_label = "Set Vertex Paint Mode"
    bl_description = "Sets Vertex Paint Mode. Fixes warning if user has Box Select tool and no selection mask."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.data.use_paint_mask_vertex = True
        prev_context = bpy.context.area.type
        bpy.context.area.type = 'VIEW_3D'
        bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='VERTEX_PAINT')
        bpy.context.area.type = prev_context
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Setpolypenselect_6A432(bpy.types.Operator):
    bl_idname = "sna.setpolypenselect_6a432"
    bl_label = "SetPolyPenSelect"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.object.mode_set('INVOKE_DEFAULT', mode='EDIT')
        bpy.ops.mesh.select_mode('INVOKE_DEFAULT', type='VERT', action='ENABLE')
        bpy.ops.mesh.select_mode('INVOKE_DEFAULT', use_extend=True, type='EDGE', action='ENABLE')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_MT_2C530(bpy.types.Menu):
    bl_idname = "SNA_MT_2C530"
    bl_label = "Pose Pie"

    @classmethod
    def poll(cls, context):
        return not ((not 'POSE'==bpy.context.mode))

    def draw(self, context):
        layout = self.layout.menu_pie()
        op = layout.operator('sn.dummy_button_operator', text='Local', icon_value=0, emboss=True, depress=False)
        layout.separator(factor=1.0)
        op = layout.operator('sn.dummy_button_operator', text='Global', icon_value=0, emboss=False, depress=False)
        layout.separator(factor=1.0)
        layout.separator(factor=1.0)
        layout.separator(factor=1.0)
        op = layout.operator('sn.dummy_button_operator', text='Parent', icon_value=0, emboss=True, depress=False)
        layout.separator(factor=1.0)


class SNA_MT_5FC8E(bpy.types.Menu):
    bl_idname = "SNA_MT_5FC8E"
    bl_label = "Scupt Tools"

    @classmethod
    def poll(cls, context):
        return not ((not 'SCULPT'==bpy.context.mode))

    def draw(self, context):
        layout = self.layout.menu_pie()
        col_ACE1B = layout.column(heading='', align=True)
        col_ACE1B.alert = False
        col_ACE1B.enabled = True
        col_ACE1B.active = True
        col_ACE1B.use_property_split = False
        col_ACE1B.use_property_decorate = False
        col_ACE1B.scale_x = 1.0
        col_ACE1B.scale_y = 1.2000000476837158
        col_ACE1B.alignment = 'Expand'.upper()
        col_ACE1B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_ACE1B.operator('brush.asset_activate', text='Inflate', icon_value=0, emboss=True, depress=False)
        op.asset_library_type = 'ESSENTIALS'
        op.relative_asset_identifier = 'brushes\\essentials_brushes-mesh_sculpt.blend\\Brush\\Inflate/Deflate'
        op = col_ACE1B.operator('brush.asset_activate', text='Snake', icon_value=0, emboss=True, depress=False)
        op.asset_library_type = 'ESSENTIALS'
        op.relative_asset_identifier = 'brushes\\essentials_brushes-mesh_sculpt.blend\\Brush\\Snake Hook'
        op = col_ACE1B.operator('brush.asset_activate', text='Clay', icon_value=0, emboss=True, depress=False)
        op.asset_library_type = 'ESSENTIALS'
        op.relative_asset_identifier = 'brushes\\essentials_brushes-mesh_sculpt.blend\\Brush\\Clay'
        op = col_ACE1B.operator('brush.asset_activate', text='Smooth', icon_value=0, emboss=True, depress=False)
        op.asset_library_type = 'ESSENTIALS'
        op.relative_asset_identifier = 'brushes\\essentials_brushes-mesh_sculpt.blend\\Brush\\Smooth'
        op = layout.operator('brush.asset_activate', text='Grab', icon_value=652, emboss=True, depress=False)
        op.asset_library_type = 'ESSENTIALS'
        op.relative_asset_identifier = 'brushes\\essentials_brushes-mesh_sculpt.blend\\Brush\\Grab'
        op = layout.operator('brush.asset_activate', text='Relax', icon_value=0, emboss=True, depress=False)
        op.asset_library_type = 'ESSENTIALS'
        op.relative_asset_identifier = 'brushes\\essentials_brushes-mesh_sculpt.blend\\Brush\\Relax Slide'
        row_C5F39 = layout.row(heading='', align=True)
        row_C5F39.alert = False
        row_C5F39.enabled = True
        row_C5F39.active = True
        row_C5F39.use_property_split = False
        row_C5F39.use_property_decorate = False
        row_C5F39.scale_x = 1.0
        row_C5F39.scale_y = 1.0
        row_C5F39.alignment = 'Expand'.upper()
        row_C5F39.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_C5F39.prop(bpy.context.view_layer.objects.active, 'use_mesh_mirror_x', text='X', icon_value=0, emboss=True, expand=True, toggle=True)
        row_C5F39.prop(bpy.context.view_layer.objects.active, 'use_mesh_mirror_y', text='Y', icon_value=0, emboss=True)
        row_C5F39.prop(bpy.context.view_layer.objects.active, 'use_mesh_mirror_z', text='Z', icon_value=0, emboss=True)
        layout.separator(factor=1.0)
        layout.separator(factor=1.0)


def sna_add_to_view3d_ht_tool_header_7BEB0(self, context):
    if not ((not 'SCULPT'==bpy.context.mode)):
        layout = self.layout
        op = layout.operator('sna.set_smooth_strength_f31e6', text='', icon_value=496, emboss=True, depress=False)


class SNA_OT_Set_Smooth_Strength_F31E6(bpy.types.Operator):
    bl_idname = "sna.set_smooth_strength_f31e6"
    bl_label = "Set Smooth Strength"
    bl_description = "Sets the strength of the smooth brush lower for working with mouse"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        new_strength = 0.20000000298023224

        def set_smooth_strength(self, context, strength = 0.2):
            # Get current brush name
            b_name = context.tool_settings.sculpt.brush.name
            # Format the asset path dynamically
            brush_path = f"brushes\\essentials_brushes-mesh_sculpt.blend\\Brush\\{b_name}"
            # Store the path directly in the scene or window manager instead of an undefined dict
            context.window_manager.get('pie__sculpt', {})['sna_brushpath'] = brush_path
            # Activate the Smooth brush
            bpy.ops.brush.asset_activate(
                'INVOKE_DEFAULT', 
                asset_library_type='ESSENTIALS', 
                relative_asset_identifier='brushes\\essentials_brushes-mesh_sculpt.blend\\Brush\\Smooth'
            )
            # Set the user-defined strength
            context.tool_settings.sculpt.brush.strength = strength
            # Re-activate the original brush
            bpy.ops.brush.asset_activate(
                'INVOKE_DEFAULT', 
                asset_library_type='ESSENTIALS', 
                relative_asset_identifier=brush_path
            )
            return {"FINISHED"}
        set_smooth_strength(self, context, new_strength)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_MT_30393(bpy.types.Menu):
    bl_idname = "SNA_MT_30393"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not ((not (bpy.context.area.ui_type == 'UV')))

    def draw(self, context):
        layout = self.layout.menu_pie()
        layout.separator(factor=1.0)
        layout.separator(factor=1.0)
        layout.separator(factor=1.0)
        op = layout.operator('sna.toggle_show_stretch_8ca4e', text='Show Stretch', icon_value=0, emboss=True, depress=bpy.context.area.spaces[0].uv_editor.show_stretch)


class SNA_MT_B55D7(bpy.types.Menu):
    bl_idname = "SNA_MT_B55D7"
    bl_label = "Vertex Paint Pie"

    @classmethod
    def poll(cls, context):
        return not ((not ('PAINT_VERTEX'==bpy.context.mode and property_exists("bpy.context.preferences.addons['bl_ext.user_default.vertex_color_master']", globals(), locals()))))

    def draw(self, context):
        layout = self.layout.menu_pie()
        op = layout.operator('vertexcolormaster.gradient', text='Linear Gradient', icon_value=0, emboss=True, depress=False)
        op = layout.operator('paint.vertex_color_set', text='Fill', icon_value=0, emboss=True, depress=False)


class SNA_GROUP_sna_transforminfo(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name='Name', description='', default='', subtype='NONE', maxlen=0)
    location: bpy.props.FloatVectorProperty(name='Location', description='', size=3, default=(0.0, 0.0, 0.0), subtype='TRANSLATION', unit='LENGTH', step=3, precision=6)
    rotation: bpy.props.FloatVectorProperty(name='Rotation', description='', size=4, default=(0.0, 0.0, 0.0, 0.0), subtype='QUATERNION', unit='ROTATION', step=3, precision=6)


class SNA_AddonPreferences_63B78(bpy.types.AddonPreferences):
    bl_idname = __package__

    def draw(self, context):
        if not (False):
            layout = self.layout 
            layout.label(text='Keyboard Shortcuts', icon_value=0)
            layout.prop(find_user_keyconfig('74368'), 'type', text='Compendium Pie Menu', full_event=True)
            layout.prop(find_user_keyconfig('9C020'), 'type', text='Modes Pie Menu', full_event=True)
            layout.prop(find_user_keyconfig('3EA7D'), 'type', text='Sculpt Pie Menu', full_event=True)
            layout.prop(find_user_keyconfig('ADF2F'), 'type', text='Emulate Mouse 3', full_event=True)
            box_1A4F1 = layout.box()
            box_1A4F1.alert = False
            box_1A4F1.enabled = True
            box_1A4F1.active = True
            box_1A4F1.use_property_split = False
            box_1A4F1.use_property_decorate = False
            box_1A4F1.alignment = 'Expand'.upper()
            box_1A4F1.scale_x = 1.0
            box_1A4F1.scale_y = 1.0
            if not True: box_1A4F1.operator_context = "EXEC_DEFAULT"
            box_00D28 = box_1A4F1.box()
            box_00D28.alert = False
            box_00D28.enabled = True
            box_00D28.active = True
            box_00D28.use_property_split = False
            box_00D28.use_property_decorate = False
            box_00D28.alignment = 'Expand'.upper()
            box_00D28.scale_x = 1.0
            box_00D28.scale_y = 1.0
            if not True: box_00D28.operator_context = "EXEC_DEFAULT"
            row_F1237 = box_00D28.row(heading='', align=False)
            row_F1237.alert = False
            row_F1237.enabled = True
            row_F1237.active = True
            row_F1237.use_property_split = False
            row_F1237.use_property_decorate = False
            row_F1237.scale_x = 1.0
            row_F1237.scale_y = 1.0
            row_F1237.alignment = 'Left'.upper()
            row_F1237.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_F1237.label(text='Shift E', icon_value=0)
            row_930BF = row_F1237.row(heading='', align=True)
            row_930BF.alert = False
            row_930BF.enabled = True
            row_930BF.active = True
            row_930BF.use_property_split = False
            row_930BF.use_property_decorate = False
            row_930BF.scale_x = 1.0
            row_930BF.scale_y = 1.0
            row_930BF.alignment = 'Left'.upper()
            row_930BF.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_930BF.operator('sna.toggle_off_shift_es_f193c', text='Off', icon_value=0, emboss=True, depress=False)
            op = row_930BF.operator('sna.toggle_on_shift_es_8ad96', text='On', icon_value=0, emboss=True, depress=False)
            row_4D9B3 = box_00D28.row(heading='', align=False)
            row_4D9B3.alert = False
            row_4D9B3.enabled = True
            row_4D9B3.active = True
            row_4D9B3.use_property_split = False
            row_4D9B3.use_property_decorate = False
            row_4D9B3.scale_x = 1.0
            row_4D9B3.scale_y = 1.0
            row_4D9B3.alignment = 'Left'.upper()
            row_4D9B3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_4D9B3.label(text='Mesh > Edge Crease', icon_value=0)
            row_4D9B3.prop(bpy.context.window_manager.keyconfigs.active.keymaps['Mesh'].keymap_items['transform.edge_crease'], 'active', text='', icon_value=0, emboss=False)
            row_E78BE = box_00D28.row(heading='', align=False)
            row_E78BE.alert = False
            row_E78BE.enabled = True
            row_E78BE.active = True
            row_E78BE.use_property_split = False
            row_E78BE.use_property_decorate = False
            row_E78BE.scale_x = 1.0
            row_E78BE.scale_y = 1.0
            row_E78BE.alignment = 'Left'.upper()
            row_E78BE.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_E78BE.label(text='Pose > Breakdowner', icon_value=0)
            row_E78BE.prop(bpy.context.window_manager.keyconfigs.user.keymaps['Pose'].keymap_items['pose.breakdown'], 'active', text='', icon_value=0, emboss=False)
            row_1C059 = box_1A4F1.row(heading='', align=False)
            row_1C059.alert = False
            row_1C059.enabled = True
            row_1C059.active = True
            row_1C059.use_property_split = False
            row_1C059.use_property_decorate = False
            row_1C059.scale_x = 1.0
            row_1C059.scale_y = 1.0
            row_1C059.alignment = 'Left'.upper()
            row_1C059.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_1C059.label(text='Use Default Pie (If using Compendium Modes Pie, disable this option)', icon_value=0)
            row_1C059.prop(bpy.context.window_manager.keyconfigs.user.keymaps['Object Non-modal'].keymap_items['view3d.object_mode_pie_or_toggle'], 'active', text='', icon_value=0, emboss=False)
            row_80452 = box_1A4F1.row(heading='', align=False)
            row_80452.alert = False
            row_80452.enabled = True
            row_80452.active = True
            row_80452.use_property_split = False
            row_80452.use_property_decorate = False
            row_80452.scale_x = 1.0
            row_80452.scale_y = 1.0
            row_80452.alignment = 'Left'.upper()
            row_80452.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_80452.label(text='Tab Key Object Mode (Also turn off if using Compendium Modes Pie)', icon_value=0)
            row_80452.prop(bpy.context.window_manager.keyconfigs.user.keymaps['Object Non-modal'].keymap_items['object.mode_set'], 'active', text='', icon_value=0, emboss=False)
            box_B7100 = layout.box()
            box_B7100.alert = False
            box_B7100.enabled = True
            box_B7100.active = True
            box_B7100.use_property_split = False
            box_B7100.use_property_decorate = False
            box_B7100.alignment = 'Expand'.upper()
            box_B7100.scale_x = 1.0
            box_B7100.scale_y = 1.0
            if not True: box_B7100.operator_context = "EXEC_DEFAULT"
            box_B7100.label(text=sna_formatchangelog_2DFCA_38FC2(), icon_value=0)
            col_C0F38 = box_B7100.column(heading='', align=False)
            col_C0F38.alert = False
            col_C0F38.enabled = True
            col_C0F38.active = True
            col_C0F38.use_property_split = False
            col_C0F38.use_property_decorate = False
            col_C0F38.scale_x = 1.0
            col_C0F38.scale_y = 1.0
            col_C0F38.alignment = 'Expand'.upper()
            col_C0F38.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_C0F38.label(text='Changed: E Pie Transform Orientations and the Transform Pivot Points are more dynamic', icon_value=69)
            col_C0F38.label(text='Reorganized the E Pie a bit as well.', icon_value=69)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_GROUP_sna_transforminfo)
    bpy.types.Scene.sna_newcollectionname = bpy.props.StringProperty(name='NewCollectionName', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_showtools = bpy.props.BoolProperty(name='ShowTools', description='', default=True)
    bpy.types.Scene.sna_showrendersettings = bpy.props.BoolProperty(name='ShowRenderSettings', description='', default=False)
    bpy.types.Scene.sna_showiteminfo = bpy.props.BoolProperty(name='ShowItemInfo', description='', default=False)
    bpy.types.Scene.sna_showworkflow = bpy.props.BoolProperty(name='ShowWorkflow', description='', default=False)
    bpy.types.Scene.sna_showops = bpy.props.BoolProperty(name='ShowOps', description='', default=False)
    bpy.types.Scene.sna_usecompendiumempty = bpy.props.BoolProperty(name='UseCompendiumEmpty', description='', default=True)
    bpy.types.Object.sna_lastcollection = bpy.props.StringProperty(name='LastCollection', description='', default='original', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_sculptworkflow = bpy.props.BoolProperty(name='SculptWorkflow', description='', default=True)
    bpy.types.Scene.sna_vpworkflow = bpy.props.BoolProperty(name='VPWorkflow', description='', default=False)
    bpy.types.Scene.sna_wpworkflow = bpy.props.BoolProperty(name='WPWorkflow', description='', default=False)
    bpy.types.Scene.sna_camlocs = bpy.props.CollectionProperty(name='CamLocs', description='', type=SNA_GROUP_sna_transforminfo)
    bpy.types.Scene.sna_locationname = bpy.props.StringProperty(name='LocationName', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_showwfoptions = bpy.props.BoolProperty(name='ShowWFOptions', description='', default=False)
    bpy.types.Scene.sna_margin = bpy.props.FloatProperty(name='Margin', description='Space between objects', default=1.0, subtype='NONE', unit='NONE', step=3, precision=2)
    bpy.types.Scene.sna_items = bpy.props.EnumProperty(name='Items', description='', items=[('x', 'x', 'Positive X', 0, 0), ('y', 'y', 'Positive Y', 0, 1), ('z', 'z', 'Positive Z', 0, 2), ('-x', '-x', 'Negative X', 0, 3), ('-y', '-y', 'Negative Y', 0, 4), ('-z', '-z', 'Negative Z', 0, 5)])
    bpy.types.Scene.sna_x_axis = bpy.props.BoolProperty(name='X_Axis', description='', default=True)
    bpy.types.Scene.sna_y_axis = bpy.props.BoolProperty(name='Y_Axis', description='', default=False)
    bpy.types.Scene.sna_z_axis = bpy.props.BoolProperty(name='Z_Axis', description='', default=False)
    bpy.types.Scene.sna_ispositive = bpy.props.BoolProperty(name='IsPositive', description='', default=True)
    bpy.types.Scene.sna_selectweightpaintmode = bpy.props.EnumProperty(name='SelectWeightPaintMode', description='', items=[('NoAuto', 'NoAuto', '', 0, 0), ('Vertex', 'Vertex', '', 0, 1), ('Armature', 'Armature', '', 0, 2)])
    bpy.types.Scene.sna_showmoreobjectopts = bpy.props.BoolProperty(name='ShowMoreObjectOpts', description='', default=False)
    bpy.types.VIEW3D_MT_editor_menus.prepend(sna_add_to_view3d_mt_editor_menus_C65F5)
    bpy.utils.register_class(SNA_MT_D7A07)
    bpy.utils.register_class(SNA_OT_Open_Weight_Paint_Info_96579)
    bpy.utils.register_class(SNA_OT_Open_Weight_Paint_Info_Links_4D4C6)
    bpy.types.OUTLINER_HT_header.prepend(sna_add_to_outliner_ht_header_A76C5)
    bpy.types.VIEW3D_MT_curve_add.append(sna_add_to_view3d_mt_curve_add_7FD4D)
    bpy.types.VIEW3D_MT_mesh_add.append(sna_add_to_view3d_mt_mesh_add_86EDB)
    bpy.utils.register_class(SNA_PT_COMPENDIUM_A8331)
    bpy.utils.register_class(SNA_OT_Toggle_Tools_F006F)
    bpy.utils.register_class(SNA_OT_Toggle_Settings_04Ec7)
    bpy.utils.register_class(SNA_OT_Toggle_Item_Info_B0C71)
    bpy.utils.register_class(SNA_OT_Toggle_Workflow_Panel_C058B)
    bpy.types.VIEW3D_HT_tool_header.append(sna_add_to_view3d_ht_tool_header_6C6E7)
    bpy.utils.register_class(SNA_MT_A3D1B)
    bpy.utils.register_class(SNA_OT_Forgotten_Tools_Link_F1Fdb)
    bpy.utils.register_class(SNA_OT_Edge_Flow_Link_Fd608)
    bpy.utils.register_class(SNA_AddonPreferences_63B78)
    bpy.utils.register_class(SNA_OT_Togglem3_8535A)
    bpy.utils.register_class(SNA_OT_Toggle_Off_Shift_Es_F193C)
    bpy.app.handlers.load_post.append(load_post_handler_F84BC)
    bpy.utils.register_class(SNA_OT_Toggle_On_Shift_Es_8Ad96)
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.utils.register_class(SNA_OT_Set_Transform_Pivot_Dfa9E)
    bpy.utils.register_class(SNA_OT_Show_Ops_F6C25)
    bpy.utils.register_class(SNA_OT_Mirror_Empty_F8D10)
    bpy.utils.register_class(SNA_OT_Send_Selected_To_Backup_5Ac5A)
    bpy.utils.register_class(SNA_OT_Toggle_Show_Creases_48169)
    bpy.utils.register_class(SNA_OT_Toggle_Show_Sharps_28E50)
    bpy.utils.register_class(SNA_OT_Toggle_Show_Bevels_Cb2F7)
    bpy.utils.register_class(SNA_OT_Toggle_Show_Seams_7408D)
    bpy.utils.register_class(SNA_OT_Set_Shading_Matcap_E9F4F)
    bpy.utils.register_class(SNA_OT_Set_Shading_Flat_87Cbc)
    bpy.utils.register_class(SNA_OT_Set_Shading_Preview_9Ad3C)
    bpy.utils.register_class(SNA_OT_Special_Hide_Selected_1C458)
    bpy.utils.register_class(SNA_OT_Special_Show_All_7E124)
    bpy.utils.register_class(SNA_OT_Special_Hide_Unselected_29928)
    bpy.utils.register_class(SNA_OT_Toggle_Wireframe_C8C58)
    bpy.utils.register_class(SNA_OT_Duplicate_Send_To_Backup_8Be30)
    bpy.utils.register_class(SNA_OT_Toggle_Display_In_Front_67De2)
    bpy.utils.register_class(SNA_OT_Toggle_Show_Stretch_8Ca4E)
    bpy.utils.register_class(SNA_OT_Set_Vertex_Paint_Workflow_B1688)
    bpy.utils.register_class(SNA_OT_Set_Weight_Paint_Workflow_C2Eda)
    bpy.utils.register_class(SNA_OT_Set_Sculpt_Workflow_27F56)
    bpy.utils.register_class(SNA_OT_Add_Camera_Loaction_1E5F9)
    bpy.utils.register_class(SNA_OT_Setcameratolocation_78754)
    bpy.utils.register_class(SNA_OT_Remove_Camera_Location_37A38)
    bpy.utils.register_class(SNA_OT_Set_Screen_Peset_45D5E)
    bpy.utils.register_class(SNA_OT_Toggle_Workflow_Options_05D4C)
    bpy.utils.register_class(SNA_OT_Add_Single_Vert_Bfe7D)
    bpy.utils.register_class(SNA_OT_Add_Edge_2Ddef)
    bpy.utils.register_class(SNA_OT_Add_Bezier_Pipe_E6F6D)
    bpy.utils.register_class(SNA_OT_Add_Bezier_Rectangle_F8009)
    bpy.utils.register_class(SNA_OT_Add_Empty_Curve_43Edf)
    bpy.utils.register_class(SNA_OT_Opensidepanel_55C7A)
    bpy.utils.register_class(SNA_OT_Set_Orientation_Cursor_Acb4A)
    bpy.utils.register_class(SNA_OT_Set_Orientation_Global_And_Pivot_Median_465F2)
    bpy.utils.register_class(SNA_OT_Toggle_Show_Face_Normals_D2Fbc)
    bpy.utils.register_class(SNA_OT_Quick_Wrap_63B55)
    bpy.utils.register_class(SNA_OT_Reset_Rotation_Euler_065Ea)
    bpy.utils.register_class(SNA_OT_Reset_Rotation_Quaternion_451Ec)
    bpy.utils.register_class(SNA_OT_Reset_Location_1Beb6)
    bpy.utils.register_class(SNA_OT_Reset_Scale_2228C)
    bpy.utils.register_class(SNA_OT_Set_Orientation_Transform_97638)
    bpy.utils.register_class(SNA_PT_EDIT_TOOLS_8CCA4)
    bpy.utils.register_class(SNA_OT_Seperate_Duplicate_8A92B)
    bpy.utils.register_class(SNA_OT_Even_0Df34)
    bpy.utils.register_class(SNA_OT_Proportional_45B9B)
    bpy.utils.register_class(SNA_PT_ITEM_INFO_98572)
    bpy.utils.register_class(SNA_PT_OBJECT_TOOLS_F8454)
    bpy.utils.register_class(SNA_OT_Explode_Selected_05499)
    bpy.utils.register_class(SNA_OT_Reset_All_World_Origin_943B2)
    bpy.utils.register_class(SNA_OT_Toggle_More_Object_Options_37109)
    bpy.utils.register_class(SNA_OT_Call_Bake_Normals_2223E)
    bpy.utils.register_class(SNA_OT_Bake_Normals_Quick_Settings_8158B)
    bpy.utils.register_class(SNA_PT_SETTINGS_PANEL_A1997)
    bpy.utils.register_class(SNA_PT_VERTEX_PAINT_TOOLS_D5E3C)
    bpy.utils.register_class(SNA_PT_WEIGHT_PAINT_TOOLS_BB3C6)
    bpy.utils.register_class(SNA_OT_Custom_Set_Weight_2F5D4)
    bpy.utils.register_class(SNA_OT_Toggle_Weight_1D114)
    bpy.utils.register_class(SNA_PT_WORKFLOW_4ACA3)
    bpy.utils.register_class(SNA_OT_Toggleautoselectarmature_C5316)
    bpy.utils.register_class(SNA_OT_Set_Snap_Increment_Aff86)
    bpy.utils.register_class(SNA_OT_Set_Snap_Face_1Fc09)
    bpy.utils.register_class(SNA_OT_Set_Pro_Snap_B7A8B)
    bpy.utils.register_class(SNA_MT_F2EBE)
    bpy.utils.register_class(SNA_OT_Face_Mode_44E6B)
    bpy.utils.register_class(SNA_OT_Vert_Mode_34Ed6)
    bpy.utils.register_class(SNA_OT_Edge_Mode_74D78)
    bpy.utils.register_class(SNA_OT_Set_Weight_Paint_3B8D6)
    bpy.utils.register_class(SNA_OT_Set_Vertex_Paint_Mode_Box_Select_3230D)
    bpy.utils.register_class(SNA_OT_Set_Vertex_Paint_Mode_8Ba67)
    bpy.utils.register_class(SNA_OT_Setpolypenselect_6A432)
    bpy.utils.register_class(SNA_MT_2C530)
    bpy.utils.register_class(SNA_MT_5FC8E)
    bpy.types.VIEW3D_HT_tool_header.prepend(sna_add_to_view3d_ht_tool_header_7BEB0)
    bpy.utils.register_class(SNA_OT_Set_Smooth_Strength_F31E6)
    bpy.utils.register_class(SNA_MT_30393)
    bpy.utils.register_class(SNA_MT_B55D7)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'E', 'PRESS',
        ctrl=False, alt=False, shift=True, repeat=False)
    kmi.properties.name = 'SNA_MT_A3D1B'
    addon_keymaps['74368'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Window', space_type='EMPTY')
    kmi = km.keymap_items.new('sna.togglem3_8535a', 'BACK_SLASH', 'PRESS',
        ctrl=False, alt=False, shift=False, repeat=False)
    addon_keymaps['ADF2F'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'TAB', 'PRESS',
        ctrl=False, alt=False, shift=False, repeat=False)
    kmi.properties.name = 'SNA_MT_F2EBE'
    addon_keymaps['9C020'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'E', 'PRESS',
        ctrl=False, alt=False, shift=True, repeat=False)
    kmi.properties.name = 'SNA_MT_2C530'
    addon_keymaps['D7294'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'E', 'PRESS',
        ctrl=False, alt=False, shift=True, repeat=False)
    kmi.properties.name = 'SNA_MT_5FC8E'
    addon_keymaps['3EA7D'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Window', space_type='EMPTY')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'E', 'PRESS',
        ctrl=False, alt=False, shift=True, repeat=False)
    kmi.properties.name = 'SNA_MT_30393'
    addon_keymaps['30196'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Window', space_type='EMPTY')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'E', 'PRESS',
        ctrl=False, alt=False, shift=True, repeat=False)
    kmi.properties.name = 'SNA_MT_B55D7'
    addon_keymaps['555F5'] = (km, kmi)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_showmoreobjectopts
    del bpy.types.Scene.sna_selectweightpaintmode
    del bpy.types.Scene.sna_ispositive
    del bpy.types.Scene.sna_z_axis
    del bpy.types.Scene.sna_y_axis
    del bpy.types.Scene.sna_x_axis
    del bpy.types.Scene.sna_items
    del bpy.types.Scene.sna_margin
    del bpy.types.Scene.sna_showwfoptions
    del bpy.types.Scene.sna_locationname
    del bpy.types.Scene.sna_camlocs
    del bpy.types.Scene.sna_wpworkflow
    del bpy.types.Scene.sna_vpworkflow
    del bpy.types.Scene.sna_sculptworkflow
    del bpy.types.Object.sna_lastcollection
    del bpy.types.Scene.sna_usecompendiumempty
    del bpy.types.Scene.sna_showops
    del bpy.types.Scene.sna_showworkflow
    del bpy.types.Scene.sna_showiteminfo
    del bpy.types.Scene.sna_showrendersettings
    del bpy.types.Scene.sna_showtools
    del bpy.types.Scene.sna_newcollectionname
    bpy.utils.unregister_class(SNA_GROUP_sna_transforminfo)
    bpy.types.VIEW3D_MT_editor_menus.remove(sna_add_to_view3d_mt_editor_menus_C65F5)
    bpy.utils.unregister_class(SNA_MT_D7A07)
    bpy.utils.unregister_class(SNA_OT_Open_Weight_Paint_Info_96579)
    bpy.utils.unregister_class(SNA_OT_Open_Weight_Paint_Info_Links_4D4C6)
    bpy.types.OUTLINER_HT_header.remove(sna_add_to_outliner_ht_header_A76C5)
    bpy.types.VIEW3D_MT_curve_add.remove(sna_add_to_view3d_mt_curve_add_7FD4D)
    bpy.types.VIEW3D_MT_mesh_add.remove(sna_add_to_view3d_mt_mesh_add_86EDB)
    bpy.utils.unregister_class(SNA_PT_COMPENDIUM_A8331)
    bpy.utils.unregister_class(SNA_OT_Toggle_Tools_F006F)
    bpy.utils.unregister_class(SNA_OT_Toggle_Settings_04Ec7)
    bpy.utils.unregister_class(SNA_OT_Toggle_Item_Info_B0C71)
    bpy.utils.unregister_class(SNA_OT_Toggle_Workflow_Panel_C058B)
    bpy.types.VIEW3D_HT_tool_header.remove(sna_add_to_view3d_ht_tool_header_6C6E7)
    bpy.utils.unregister_class(SNA_MT_A3D1B)
    bpy.utils.unregister_class(SNA_OT_Forgotten_Tools_Link_F1Fdb)
    bpy.utils.unregister_class(SNA_OT_Edge_Flow_Link_Fd608)
    bpy.utils.unregister_class(SNA_AddonPreferences_63B78)
    bpy.utils.unregister_class(SNA_OT_Togglem3_8535A)
    bpy.utils.unregister_class(SNA_OT_Toggle_Off_Shift_Es_F193C)
    bpy.app.handlers.load_post.remove(load_post_handler_F84BC)
    bpy.utils.unregister_class(SNA_OT_Toggle_On_Shift_Es_8Ad96)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    bpy.utils.unregister_class(SNA_OT_Set_Transform_Pivot_Dfa9E)
    bpy.utils.unregister_class(SNA_OT_Show_Ops_F6C25)
    bpy.utils.unregister_class(SNA_OT_Mirror_Empty_F8D10)
    bpy.utils.unregister_class(SNA_OT_Send_Selected_To_Backup_5Ac5A)
    bpy.utils.unregister_class(SNA_OT_Toggle_Show_Creases_48169)
    bpy.utils.unregister_class(SNA_OT_Toggle_Show_Sharps_28E50)
    bpy.utils.unregister_class(SNA_OT_Toggle_Show_Bevels_Cb2F7)
    bpy.utils.unregister_class(SNA_OT_Toggle_Show_Seams_7408D)
    bpy.utils.unregister_class(SNA_OT_Set_Shading_Matcap_E9F4F)
    bpy.utils.unregister_class(SNA_OT_Set_Shading_Flat_87Cbc)
    bpy.utils.unregister_class(SNA_OT_Set_Shading_Preview_9Ad3C)
    bpy.utils.unregister_class(SNA_OT_Special_Hide_Selected_1C458)
    bpy.utils.unregister_class(SNA_OT_Special_Show_All_7E124)
    bpy.utils.unregister_class(SNA_OT_Special_Hide_Unselected_29928)
    bpy.utils.unregister_class(SNA_OT_Toggle_Wireframe_C8C58)
    bpy.utils.unregister_class(SNA_OT_Duplicate_Send_To_Backup_8Be30)
    bpy.utils.unregister_class(SNA_OT_Toggle_Display_In_Front_67De2)
    bpy.utils.unregister_class(SNA_OT_Toggle_Show_Stretch_8Ca4E)
    bpy.utils.unregister_class(SNA_OT_Set_Vertex_Paint_Workflow_B1688)
    bpy.utils.unregister_class(SNA_OT_Set_Weight_Paint_Workflow_C2Eda)
    bpy.utils.unregister_class(SNA_OT_Set_Sculpt_Workflow_27F56)
    bpy.utils.unregister_class(SNA_OT_Add_Camera_Loaction_1E5F9)
    bpy.utils.unregister_class(SNA_OT_Setcameratolocation_78754)
    bpy.utils.unregister_class(SNA_OT_Remove_Camera_Location_37A38)
    bpy.utils.unregister_class(SNA_OT_Set_Screen_Peset_45D5E)
    bpy.utils.unregister_class(SNA_OT_Toggle_Workflow_Options_05D4C)
    bpy.utils.unregister_class(SNA_OT_Add_Single_Vert_Bfe7D)
    bpy.utils.unregister_class(SNA_OT_Add_Edge_2Ddef)
    bpy.utils.unregister_class(SNA_OT_Add_Bezier_Pipe_E6F6D)
    bpy.utils.unregister_class(SNA_OT_Add_Bezier_Rectangle_F8009)
    bpy.utils.unregister_class(SNA_OT_Add_Empty_Curve_43Edf)
    bpy.utils.unregister_class(SNA_OT_Opensidepanel_55C7A)
    bpy.utils.unregister_class(SNA_OT_Set_Orientation_Cursor_Acb4A)
    bpy.utils.unregister_class(SNA_OT_Set_Orientation_Global_And_Pivot_Median_465F2)
    bpy.utils.unregister_class(SNA_OT_Toggle_Show_Face_Normals_D2Fbc)
    bpy.utils.unregister_class(SNA_OT_Quick_Wrap_63B55)
    bpy.utils.unregister_class(SNA_OT_Reset_Rotation_Euler_065Ea)
    bpy.utils.unregister_class(SNA_OT_Reset_Rotation_Quaternion_451Ec)
    bpy.utils.unregister_class(SNA_OT_Reset_Location_1Beb6)
    bpy.utils.unregister_class(SNA_OT_Reset_Scale_2228C)
    bpy.utils.unregister_class(SNA_OT_Set_Orientation_Transform_97638)
    bpy.utils.unregister_class(SNA_PT_EDIT_TOOLS_8CCA4)
    bpy.utils.unregister_class(SNA_OT_Seperate_Duplicate_8A92B)
    bpy.utils.unregister_class(SNA_OT_Even_0Df34)
    bpy.utils.unregister_class(SNA_OT_Proportional_45B9B)
    bpy.utils.unregister_class(SNA_PT_ITEM_INFO_98572)
    bpy.utils.unregister_class(SNA_PT_OBJECT_TOOLS_F8454)
    bpy.utils.unregister_class(SNA_OT_Explode_Selected_05499)
    bpy.utils.unregister_class(SNA_OT_Reset_All_World_Origin_943B2)
    bpy.utils.unregister_class(SNA_OT_Toggle_More_Object_Options_37109)
    bpy.utils.unregister_class(SNA_OT_Call_Bake_Normals_2223E)
    bpy.utils.unregister_class(SNA_OT_Bake_Normals_Quick_Settings_8158B)
    bpy.utils.unregister_class(SNA_PT_SETTINGS_PANEL_A1997)
    bpy.utils.unregister_class(SNA_PT_VERTEX_PAINT_TOOLS_D5E3C)
    bpy.utils.unregister_class(SNA_PT_WEIGHT_PAINT_TOOLS_BB3C6)
    bpy.utils.unregister_class(SNA_OT_Custom_Set_Weight_2F5D4)
    bpy.utils.unregister_class(SNA_OT_Toggle_Weight_1D114)
    bpy.utils.unregister_class(SNA_PT_WORKFLOW_4ACA3)
    bpy.utils.unregister_class(SNA_OT_Toggleautoselectarmature_C5316)
    bpy.utils.unregister_class(SNA_OT_Set_Snap_Increment_Aff86)
    bpy.utils.unregister_class(SNA_OT_Set_Snap_Face_1Fc09)
    bpy.utils.unregister_class(SNA_OT_Set_Pro_Snap_B7A8B)
    bpy.utils.unregister_class(SNA_MT_F2EBE)
    bpy.utils.unregister_class(SNA_OT_Face_Mode_44E6B)
    bpy.utils.unregister_class(SNA_OT_Vert_Mode_34Ed6)
    bpy.utils.unregister_class(SNA_OT_Edge_Mode_74D78)
    bpy.utils.unregister_class(SNA_OT_Set_Weight_Paint_3B8D6)
    bpy.utils.unregister_class(SNA_OT_Set_Vertex_Paint_Mode_Box_Select_3230D)
    bpy.utils.unregister_class(SNA_OT_Set_Vertex_Paint_Mode_8Ba67)
    bpy.utils.unregister_class(SNA_OT_Setpolypenselect_6A432)
    bpy.utils.unregister_class(SNA_MT_2C530)
    bpy.utils.unregister_class(SNA_MT_5FC8E)
    bpy.types.VIEW3D_HT_tool_header.remove(sna_add_to_view3d_ht_tool_header_7BEB0)
    bpy.utils.unregister_class(SNA_OT_Set_Smooth_Strength_F31E6)
    bpy.utils.unregister_class(SNA_MT_30393)
    bpy.utils.unregister_class(SNA_MT_B55D7)
