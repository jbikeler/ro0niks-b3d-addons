# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "GameExports",
    "author" : "ro0nik", 
    "description" : "",
    "blender" : (5, 2, 0),
    "version" : (2, 0, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import math
import os


addon_keymaps = {}
_icons = None
functions = {'sna_filepathname': '', 'sna_formattedname': '', }


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


def find_user_keyconfig(key):
    km, kmi = addon_keymaps[key]
    for item in bpy.context.window_manager.keyconfigs.user.keymaps[km.name].keymap_items:
        found_item = False
        if kmi.idname == item.idname:
            found_item = True
            for name in dir(kmi.properties):
                if not name in ["bl_rna", "rna_type"] and not name[0] == "_":
                    if name in kmi.properties and name in item.properties and not kmi.properties[name] == item.properties[name]:
                        found_item = False
        if found_item:
            return item
    print(f"Couldn't find keymap item for {key}, using addon keymap instead. This won't be saved across sessions!")
    return kmi


def sna_formatchangelog_2DFCA_90F56():
    return 'Changelog Version ' + str(tuple(tuple(bpy.context.scene.sn.version))).replace('(', '').replace(')', '').replace(',', '.').replace(' ', '') + ':'


class SNA_PT_GAMEEXPORTS_286E8(bpy.types.Panel):
    bl_label = 'GameExports'
    bl_idname = 'SNA_PT_GAMEEXPORTS_286E8'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'GameExports'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if bpy.context.view_layer.objects.active:
            col_6E08A = layout.column(heading='', align=False)
            col_6E08A.alert = False
            col_6E08A.enabled = True
            col_6E08A.active = True
            col_6E08A.use_property_split = False
            col_6E08A.use_property_decorate = False
            col_6E08A.scale_x = 1.0
            col_6E08A.scale_y = 1.0
            col_6E08A.alignment = 'Center'.upper()
            col_6E08A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_8F9B1 = col_6E08A.row(heading='', align=False)
            row_8F9B1.alert = False
            row_8F9B1.enabled = True
            row_8F9B1.active = True
            row_8F9B1.use_property_split = False
            row_8F9B1.use_property_decorate = False
            row_8F9B1.scale_x = 1.0
            row_8F9B1.scale_y = 1.0
            row_8F9B1.alignment = 'Center'.upper()
            row_8F9B1.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_8F9B1.label(text='Godot Conversion (Meters)', icon_value=0)
            box_D0384 = col_6E08A.box()
            box_D0384.alert = False
            box_D0384.enabled = True
            box_D0384.active = True
            box_D0384.use_property_split = False
            box_D0384.use_property_decorate = False
            box_D0384.alignment = 'Expand'.upper()
            box_D0384.scale_x = 1.0
            box_D0384.scale_y = 1.0
            if not True: box_D0384.operator_context = "EXEC_DEFAULT"
            box_D0384.label(text='Position', icon_value=0)
            col_BDACF = box_D0384.column(heading='', align=False)
            col_BDACF.alert = False
            col_BDACF.enabled = True
            col_BDACF.active = True
            col_BDACF.use_property_split = False
            col_BDACF.use_property_decorate = False
            col_BDACF.scale_x = 1.0
            col_BDACF.scale_y = 1.0
            col_BDACF.alignment = 'Center'.upper()
            col_BDACF.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_DEA8D = col_BDACF.row(heading='', align=True)
            row_DEA8D.alert = False
            row_DEA8D.enabled = True
            row_DEA8D.active = True
            row_DEA8D.use_property_split = False
            row_DEA8D.use_property_decorate = False
            row_DEA8D.scale_x = 1.0
            row_DEA8D.scale_y = 1.0
            row_DEA8D.alignment = 'Expand'.upper()
            row_DEA8D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_DEA8D.operator('sna.copyposition_78e65', text=sna_formatvector_CCB2F(bpy.context.view_layer.objects.active.location, True)[0], icon_value=0, emboss=True, depress=False)
            op.sna_positionaxis = 'X'
            op = row_DEA8D.operator('sna.copyposition_78e65', text=sna_formatvector_CCB2F(bpy.context.view_layer.objects.active.location, True)[1], icon_value=0, emboss=True, depress=False)
            op.sna_positionaxis = 'Y'
            op = row_DEA8D.operator('sna.copyposition_78e65', text=sna_formatvector_CCB2F(bpy.context.view_layer.objects.active.location, True)[2], icon_value=0, emboss=True, depress=False)
            op.sna_positionaxis = 'Z'
            box_1B4FE = col_6E08A.box()
            box_1B4FE.alert = False
            box_1B4FE.enabled = True
            box_1B4FE.active = True
            box_1B4FE.use_property_split = False
            box_1B4FE.use_property_decorate = False
            box_1B4FE.alignment = 'Expand'.upper()
            box_1B4FE.scale_x = 1.0
            box_1B4FE.scale_y = 1.0
            if not True: box_1B4FE.operator_context = "EXEC_DEFAULT"
            box_1B4FE.label(text='Rotation', icon_value=0)
            col_2E3F5 = box_1B4FE.column(heading='', align=False)
            col_2E3F5.alert = False
            col_2E3F5.enabled = True
            col_2E3F5.active = True
            col_2E3F5.use_property_split = False
            col_2E3F5.use_property_decorate = False
            col_2E3F5.scale_x = 1.0
            col_2E3F5.scale_y = 1.0
            col_2E3F5.alignment = 'Center'.upper()
            col_2E3F5.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_B86F4 = col_2E3F5.row(heading='', align=True)
            row_B86F4.alert = False
            row_B86F4.enabled = True
            row_B86F4.active = True
            row_B86F4.use_property_split = False
            row_B86F4.use_property_decorate = False
            row_B86F4.scale_x = 1.0
            row_B86F4.scale_y = 1.0
            row_B86F4.alignment = 'Expand'.upper()
            row_B86F4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_B86F4.operator('sna.copyrotation_0e3bd', text=sna_formatvector_CCB2F((math.degrees(bpy.context.view_layer.objects.active.rotation_euler[0]), math.degrees(bpy.context.view_layer.objects.active.rotation_euler[1]), math.degrees(bpy.context.view_layer.objects.active.rotation_euler[2])), False)[0], icon_value=0, emboss=True, depress=False)
            op = row_B86F4.operator('sna.copyrotation_0e3bd', text=sna_formatvector_CCB2F((math.degrees(bpy.context.view_layer.objects.active.rotation_euler[0]), math.degrees(bpy.context.view_layer.objects.active.rotation_euler[1]), math.degrees(bpy.context.view_layer.objects.active.rotation_euler[2])), False)[1], icon_value=0, emboss=True, depress=False)
            op = row_B86F4.operator('sna.copyrotation_0e3bd', text=sna_formatvector_CCB2F((math.degrees(bpy.context.view_layer.objects.active.rotation_euler[0]), math.degrees(bpy.context.view_layer.objects.active.rotation_euler[1]), math.degrees(bpy.context.view_layer.objects.active.rotation_euler[2])), False)[2], icon_value=0, emboss=True, depress=False)
            box_1AC91 = col_6E08A.box()
            box_1AC91.alert = False
            box_1AC91.enabled = True
            box_1AC91.active = True
            box_1AC91.use_property_split = False
            box_1AC91.use_property_decorate = False
            box_1AC91.alignment = 'Expand'.upper()
            box_1AC91.scale_x = 1.0
            box_1AC91.scale_y = 1.0
            if not True: box_1AC91.operator_context = "EXEC_DEFAULT"
            box_1AC91.label(text='Scale', icon_value=0)
            col_25BC4 = box_1AC91.column(heading='', align=False)
            col_25BC4.alert = False
            col_25BC4.enabled = True
            col_25BC4.active = True
            col_25BC4.use_property_split = False
            col_25BC4.use_property_decorate = False
            col_25BC4.scale_x = 1.0
            col_25BC4.scale_y = 1.0
            col_25BC4.alignment = 'Center'.upper()
            col_25BC4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_53ACB = col_25BC4.row(heading='', align=True)
            row_53ACB.alert = False
            row_53ACB.enabled = True
            row_53ACB.active = True
            row_53ACB.use_property_split = False
            row_53ACB.use_property_decorate = False
            row_53ACB.scale_x = 1.0
            row_53ACB.scale_y = 1.0
            row_53ACB.alignment = 'Expand'.upper()
            row_53ACB.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_53ACB.operator('sna.copyscale_6c3f6', text=sna_formatvector_CCB2F(bpy.context.view_layer.objects.active.scale, False)[0], icon_value=0, emboss=True, depress=False)
            op = row_53ACB.operator('sna.copyscale_6c3f6', text=sna_formatvector_CCB2F(bpy.context.view_layer.objects.active.scale, False)[1], icon_value=0, emboss=True, depress=False)
            op = row_53ACB.operator('sna.copyscale_6c3f6', text=sna_formatvector_CCB2F(bpy.context.view_layer.objects.active.scale, False)[2], icon_value=0, emboss=True, depress=False)
        else:
            row_C4F0E = layout.row(heading='', align=True)
            row_C4F0E.alert = False
            row_C4F0E.enabled = True
            row_C4F0E.active = True
            row_C4F0E.use_property_split = False
            row_C4F0E.use_property_decorate = False
            row_C4F0E.scale_x = 1.0
            row_C4F0E.scale_y = 1.0
            row_C4F0E.alignment = 'Center'.upper()
            row_C4F0E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_C4F0E.label(text='(Select Active Object)', icon_value=0)
        op = layout.operator('sna.godotaxis_600f1', text='Add Godot Axis', icon_value=332, emboss=True, depress=False)


class SNA_OT_Copyposition_78E65(bpy.types.Operator):
    bl_idname = "sna.copyposition_78e65"
    bl_label = "CopyPosition"
    bl_description = "Copy value to clipboard"
    bl_options = {"REGISTER", "UNDO"}

    def sna_positionaxis_enum_items(self, context):
        return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]
    sna_positionaxis: bpy.props.EnumProperty(name='PositionAxis', description='', options={'HIDDEN'}, items=[('X', 'X', 'X', 0, 0), ('Y', 'Y', 'Y', 0, 1), ('Z', 'Z', 'Z', 0, 2)])

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if self.sna_positionaxis == "X":
            exec('copy_to_clipboard(round(bpy.context.object.location.x, 3))')
        elif self.sna_positionaxis == "Y":
            exec('copy_to_clipboard(round(bpy.context.object.location.z, 3))')
        elif self.sna_positionaxis == "Z":
            exec('copy_to_clipboard(round(bpy.context.object.location.y * (-1), 3))')
        else:
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Copyrotation_0E3Bd(bpy.types.Operator):
    bl_idname = "sna.copyrotation_0e3bd"
    bl_label = "CopyRotation"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    def sna_rotaxis_enum_items(self, context):
        return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]
    sna_rotaxis: bpy.props.EnumProperty(name='RotAxis', description='', options={'HIDDEN'}, items=[('X', 'X', 'X', 0, 0), ('Y', 'Y', 'Y', 0, 1), ('Z', 'Z', 'Z', 0, 2)])

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if self.sna_rotaxis == "X":
            exec('copy_to_clipboard(round(bpy.context.object.rotation_euler.x, 3))')
        elif self.sna_rotaxis == "Y":
            exec('copy_to_clipboard(round(bpy.context.object.rotation_euler.z, 3))')
        elif self.sna_rotaxis == "Z":
            exec('copy_to_clipboard(round(bpy.context.object.rotation_euler.y, 3))')
        else:
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_formatvector_CCB2F(Vector, ReverseZ):
    return ['x  ' + str(round(Vector[0], abs(3))), 'y  ' + str(round(Vector[2], abs(3))), 'z  ' + str(float(round(Vector[1], abs(3)) * (-1.0 if ReverseZ else 1.0)))]


class SNA_OT_Copyscale_6C3F6(bpy.types.Operator):
    bl_idname = "sna.copyscale_6c3f6"
    bl_label = "CopyScale"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    def sna_scaleaxis_enum_items(self, context):
        return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]
    sna_scaleaxis: bpy.props.EnumProperty(name='ScaleAxis', description='', options={'HIDDEN'}, items=[('X', 'X', 'X', 0, 0), ('Y', 'Y', 'Y', 0, 1), ('Z', 'Z', 'Z', 0, 2)])

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if self.sna_scaleaxis == "X":
            exec('copy_to_clipboard(round(bpy.context.object.scale.x, 3))')
        elif self.sna_scaleaxis == "Y":
            exec('copy_to_clipboard(round(bpy.context.object.scale.z, 3))')
        elif self.sna_scaleaxis == "Z":
            exec('copy_to_clipboard(round(bpy.context.object.scale.y, 3))')
        else:
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Godotaxis_600F1(bpy.types.Operator):
    bl_idname = "sna.godotaxis_600f1"
    bl_label = "GodotAxis"
    bl_description = "Adds a quick empty to visualize Godot XYZ Axis."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('add_godot_axis()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_MT_13879(bpy.types.Menu):
    bl_idname = "SNA_MT_13879"
    bl_label = ""

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.operator_context = "INVOKE_DEFAULT"
        layout.label(text='Select Active Object', icon_value=707)


def find_first_export_collection():
    for collection in bpy.data.collections:
        if collection.name.endswith("_Export") or collection.name.endswith("_export"):
            return collection
    return None


def find_layer_collection(layer_coll, coll_name):
    if layer_coll.collection.name == coll_name:
        return layer_coll
    for child in layer_coll.children:
        result = find_layer_collection(child, coll_name)
        if result:
            return result
    return None


def activate_and_select_export_collection():
    collection = find_first_export_collection()
    if not collection:
        print("No collection with _Export or _export found.")
        return
    # Try to activate the collection in the current view layer
    layer_collection = find_layer_collection(bpy.context.view_layer.layer_collection, collection.name)
    if layer_collection:
        bpy.context.view_layer.active_layer_collection = layer_collection
    else:
        print(f"Couldn't find layer collection for: {collection.name}")
        return
    # Deselect everything first
    bpy.ops.object.select_all(action='DESELECT')
    # Select objects that exist in the current view layer
    selectable_objects = [obj for obj in collection.objects if obj.name in bpy.context.view_layer.objects]
    if selectable_objects:
        for obj in selectable_objects:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = selectable_objects[0]
        print(f"Activated collection: {collection.name}")
        print(f"Selected {len(selectable_objects)} object(s). First active: {selectable_objects[0].name}")
    else:
        print(f"No selectable objects in collection: {collection.name}")


def get_formatted_export_collection_name():
    for collection in bpy.data.collections:
        if collection.name.endswith("_Export"):
            return collection.name[:-7]
        elif collection.name.endswith("_export"):
            return collection.name[:-7]
    return ""  # Return empty string if no matching collection found


def resolve_path(path):
    """
    Resolves a file system path to an absolute, valid path.
    This function takes a potentially Blender-relative or malformed file path,
    normalizes it, converts it to an absolute path, and checks whether the file exists.
    Args:
        path (str): The file path to resolve. Can be absolute, relative, or Blender-relative (starting with '//').
    Returns:
        str: The absolute path if it exists on the file system; otherwise, an empty string.
    """
    # If the path is empty or None, return immediately
    if not path or path.strip() == "":
        return ""
    # Normalize slashes (Blender expects /)
    normalized_input = path.replace("\\", "/")
    # If it's a Blender-relative path, resolve it
    if normalized_input.startswith("//"):
        resolved = bpy.path.abspath(normalized_input)
    else:
        resolved = normalized_input
    # Clean up the resolved path
    absolute_path = os.path.abspath(resolved)
    # Final existence check
    if os.path.exists(absolute_path):
        return absolute_path
    else:
        return ""


def get_file_path_for_tagged_collection():
    """
    Builds the final file path for export by:
    - Resolving the path stored in the scene's 'sna_export_path' property.
    - Appending a trailing slash if needed.
    - Appending the formatted export collection name.
    """
    input_path = bpy.context.scene.sna_export_path
    if not input_path:
        print("No Export Path property found")
        return ""
    resolved = resolve_path(input_path)
    if resolved:
        # Ensure the path ends with a slash
        if not resolved.endswith(os.sep):
            resolved += os.sep
        final_path = resolved + get_formatted_export_collection_name()
        return final_path
    else:
        print("Resolved path was invalid or did not exist.")
        return ""


def set_active_collection_as_export():
    """
    Marks the active collection as the export collection by appending "_Export".
    If another collection already has the export suffix, that suffix is stripped
    from it and moved to the active collection instead.
    """
    active_collection = bpy.context.view_layer.active_layer_collection.collection
    if active_collection is None:
        print("No active collection found.")
        return
    existing_export = find_first_export_collection()
    # If the active collection is already the export collection, nothing to do
    if existing_export == active_collection:
        print(f"'{active_collection.name}' is already the export collection.")
        return
    # Strip the suffix from the previous export collection, if there is one
    if existing_export is not None:
        if existing_export.name.endswith("_Export"):
            existing_export.name = existing_export.name[:-len("_Export")]
        elif existing_export.name.endswith("_export"):
            existing_export.name = existing_export.name[:-len("_export")]
    # Tag the active collection as the new export collection
    active_collection.name = f"{active_collection.name}_Export"
    print(f"'{active_collection.name}' set as export collection.")


# --- Format Names -------------------------------


def clean_name(name):
    """Replaces spaces and periods with underscores."""
    return name.replace(" ", "_").replace(".", "_")


def _apply_prefix(base_name, prefix):
    if not prefix:
        return base_name
    if base_name.startswith(f"{prefix}_"):
        return base_name
    return f"{prefix}_{base_name}"


def _apply_suffix(base_name, suffix):
    if not suffix:
        return base_name
    if base_name.endswith(f"_{suffix}"):
        return base_name
    return f"{base_name}_{suffix}"


def _apply_rename(base_name, new_base, index):
    """Fully replaces the name with new_base + sequential index."""
    if not new_base:
        return base_name
    return f"{new_base}_{index:03d}"


def _apply_replace(base_name, find_text, replace_text):
    """Find/replace a substring within the cleaned name."""
    if not find_text:
        return base_name
    return base_name.replace(find_text, replace_text)


def format_name_string(base_name, option, format_text, index=1, find_text="", replace_text="", auto_clean=True):
    """
    Applies prefix, suffix, rename, or replace formatting logic.
    """
    cleaned_base = clean_name(base_name) if auto_clean else base_name
    clean_format_text = format_text.strip("_").strip() if format_text else ""
    handlers = {
        'PREFIX': lambda: _apply_prefix(cleaned_base, clean_format_text),
        'SUFFIX': lambda: _apply_suffix(cleaned_base, clean_format_text),
        'RENAME': lambda: _apply_rename(cleaned_base, clean_format_text, index),
        'REPLACE': lambda: _apply_replace(cleaned_base, find_text.strip(), replace_text.strip()),
    }
    handler = handlers.get(option)
    return handler() if handler else cleaned_base


def _get_format_settings(scene, use_extended_logic):
    """Safely pulls formatting-related scene properties, with sane fallbacks."""
    if not use_extended_logic:
        return {
            'option': 'NONE',
            'format_text': '',
            'find_text': '',
            'replace_text': '',
            'auto_clean': True,
        }
    return {
        'option': getattr(scene, 'sna_format_option', 'NONE'),
        'format_text': getattr(scene, 'sna_format_text', ''),
        'find_text': getattr(scene, 'sna_find_text', ''),
        'replace_text': getattr(scene, 'sna_replace_text', ''),
        'auto_clean': getattr(scene, 'sna_auto_clean_names', True),
    }


def rename_selected_objects(use_extended_logic=False):
    """
    Iterates through all selected objects and renames them.
    Mesh data-blocks are also renamed to match; other data types are left alone.
    """
    selected_objs = bpy.context.selected_objects
    if not selected_objs:
        print("No objects selected.")
        return
    settings = _get_format_settings(bpy.context.scene, use_extended_logic)
    for i, obj in enumerate(selected_objs, start=1):
        new_obj_name = format_name_string(
            obj.name,
            settings['option'],
            settings['format_text'],
            index=i,
            find_text=settings['find_text'],
            replace_text=settings['replace_text'],
            auto_clean=settings['auto_clean'],
        )
        obj.name = new_obj_name
        if obj.type == 'MESH' and obj.data:
            obj.data.name = f"{new_obj_name}_Mesh"


# --- Godot Axis ----------------


def add_godot_axis():
    """
    Creates a Godot Axis empty, configures its properties,
    and moves it directly to the 'Ref' collection.
    """
    obj = bpy.data.objects.new("Godot Axis Ref", None)
    obj.empty_display_type = 'ARROWS'
    obj.location = (0.0, 0.0, 0.0)
    obj.rotation_euler = (1.5707999467849731, 0.0, 0.0)
    obj.scale = (3.0, 3.0, 3.0)
    obj.hide_select = True
    move_to_collection(obj, "Ref")
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)


# --- Other Helpers --------------------------


def copy_to_clipboard(value):
    """
    Copies the given value (string, int, float, etc.) to the system clipboard
    using Blender's internal window manager.
    """
    # Convert the value to a string
    clipboard_text = str(value)
    # Assign the string to the clipboard property
    bpy.context.window_manager.clipboard = clipboard_text
    print(f"Copied to clipboard: {clipboard_text}")


def move_to_collection(objects, collection_name):
    """
    Moves a list of objects to a specified collection. 
    Creates the collection if it doesn't exist.
    """
    if not objects:
        return
    # Ensure objects is a list/iterable even if a single object was passed
    if not isinstance(objects, (list, tuple, set)):
        objects = [objects]
    target_collection = bpy.data.collections.get(collection_name)
    if not target_collection:
        target_collection = bpy.data.collections.new(collection_name)
        # Link the brand new collection to the main scene scene hierarchy
        bpy.context.scene.collection.children.link(target_collection)
    # Move each object safely
    for obj in objects:
        if not obj:
            continue
        # Link to the new target collection if not already there
        if obj.name not in target_collection.objects:
            target_collection.objects.link(obj)
        # Unlink from all other collections in the file to prevent duplication
        for col in obj.users_collection:
            if col != target_collection:
                col.objects.unlink(obj)


class SNA_PT_EXPORT_1A2A0(bpy.types.Panel):
    bl_label = 'Export'
    bl_idname = 'SNA_PT_EXPORT_1A2A0'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_5BEAF = layout.column(heading='', align=False)
        col_5BEAF.alert = False
        col_5BEAF.enabled = 'OBJECT'==bpy.context.mode
        col_5BEAF.active = True
        col_5BEAF.use_property_split = False
        col_5BEAF.use_property_decorate = False
        col_5BEAF.scale_x = 1.0
        col_5BEAF.scale_y = 1.0
        col_5BEAF.alignment = 'Expand'.upper()
        col_5BEAF.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        if bpy.context.preferences.addons[__package__].preferences.sna_displayunreal:
            col_9CD8A = col_5BEAF.column(heading='', align=False)
            col_9CD8A.alert = False
            col_9CD8A.enabled = True
            col_9CD8A.active = True
            col_9CD8A.use_property_split = False
            col_9CD8A.use_property_decorate = False
            col_9CD8A.scale_x = 1.0
            col_9CD8A.scale_y = 1.0
            col_9CD8A.alignment = 'Expand'.upper()
            col_9CD8A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_3B8C5 = col_9CD8A.row(heading='', align=False)
            row_3B8C5.alert = False
            row_3B8C5.enabled = True
            row_3B8C5.active = True
            row_3B8C5.use_property_split = False
            row_3B8C5.use_property_decorate = False
            row_3B8C5.scale_x = 1.0
            row_3B8C5.scale_y = 1.0
            row_3B8C5.alignment = 'Expand'.upper()
            row_3B8C5.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_3B8C5.label(text='Unreal Engine (Selected Only)', icon_value=0)
            op = row_3B8C5.operator('sna.info_for_ue_exports_7cb33', text='', icon_value=52, emboss=False, depress=False)
            box_7F080 = col_9CD8A.box()
            box_7F080.alert = False
            box_7F080.enabled = True
            box_7F080.active = True
            box_7F080.use_property_split = False
            box_7F080.use_property_decorate = False
            box_7F080.alignment = 'Expand'.upper()
            box_7F080.scale_x = 1.0
            box_7F080.scale_y = 1.0
            if not True: box_7F080.operator_context = "EXEC_DEFAULT"
            col_89607 = box_7F080.column(heading='', align=False)
            col_89607.alert = False
            col_89607.enabled = True
            col_89607.active = True
            col_89607.use_property_split = False
            col_89607.use_property_decorate = False
            col_89607.scale_x = 1.0
            col_89607.scale_y = 1.0
            col_89607.alignment = 'Expand'.upper()
            col_89607.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_89607.operator('sna.export_fbx_static_mesh_for_ue_6ea59', text='Static Mesh FBX', icon_value=0, emboss=True, depress=False)
            col_1561A = col_89607.column(heading='', align=True)
            col_1561A.alert = False
            col_1561A.enabled = True
            col_1561A.active = True
            col_1561A.use_property_split = False
            col_1561A.use_property_decorate = False
            col_1561A.scale_x = 1.0
            col_1561A.scale_y = 1.0
            col_1561A.alignment = 'Expand'.upper()
            col_1561A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = col_1561A.operator('sna.export_fbx_skeletal_mesh_a08cf', text='Skeletal Mesh FBX', icon_value=0, emboss=True, depress=False)
            op = col_1561A.operator('sna.export_fbx_animation_becb7', text='Selected Animation FBX', icon_value=0, emboss=True, depress=False)
        if bpy.context.preferences.addons[__package__].preferences.sna_displaygodot:
            col_F00E4 = col_5BEAF.column(heading='', align=True)
            col_F00E4.alert = False
            col_F00E4.enabled = True
            col_F00E4.active = True
            col_F00E4.use_property_split = False
            col_F00E4.use_property_decorate = False
            col_F00E4.scale_x = 1.0
            col_F00E4.scale_y = 1.0
            col_F00E4.alignment = 'Expand'.upper()
            col_F00E4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_013FC = col_F00E4.row(heading='', align=False)
            row_013FC.alert = False
            row_013FC.enabled = True
            row_013FC.active = True
            row_013FC.use_property_split = False
            row_013FC.use_property_decorate = False
            row_013FC.scale_x = 1.0
            row_013FC.scale_y = 1.0
            row_013FC.alignment = 'Expand'.upper()
            row_013FC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_013FC.label(text='Godot', icon_value=0)
            op = row_013FC.operator('sna.info_for_godot_exports_d1276', text='', icon_value=52, emboss=False, depress=False)
            box_0BA36 = col_F00E4.box()
            box_0BA36.alert = False
            box_0BA36.enabled = True
            box_0BA36.active = True
            box_0BA36.use_property_split = False
            box_0BA36.use_property_decorate = False
            box_0BA36.alignment = 'Expand'.upper()
            box_0BA36.scale_x = 1.0
            box_0BA36.scale_y = 1.0
            if not True: box_0BA36.operator_context = "EXEC_DEFAULT"
            col_D1311 = box_0BA36.column(heading='', align=False)
            col_D1311.alert = False
            col_D1311.enabled = True
            col_D1311.active = True
            col_D1311.use_property_split = False
            col_D1311.use_property_decorate = False
            col_D1311.scale_x = 1.0
            col_D1311.scale_y = 1.0
            col_D1311.alignment = 'Expand'.upper()
            col_D1311.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_D1311.label(text='GLTF', icon_value=0)
            op = col_D1311.operator('sna.export_static_gltf_for_godot_8e1d6', text='Selected Meshes Only', icon_value=0, emboss=True, depress=False)
            op.sna_meshes_only = True
            op = col_D1311.operator('sna.export_static_gltf_for_godot_8e1d6', text='Selected All', icon_value=0, emboss=True, depress=False)
            op.sna_meshes_only = False
            op = col_D1311.operator('sna.export_animated_mesh_and_armature_gltf_for_godot_8e082', text='Animated Mesh glTF', icon_value=0, emboss=True, depress=False)
            op = col_D1311.operator('sna.export_animated_armature_only_gltf_for_godot_ebe70', text='Armature/Action glTF', icon_value=0, emboss=True, depress=False)
            col_D1311.prop(bpy.context.scene, 'sna_embed_image', text='Embed Image', icon_value=203, emboss=True, toggle=True)
            col_D1311.label(text='Tagged Collection', icon_value=0)
            row_222A4 = col_D1311.row(heading='', align=False)
            row_222A4.alert = False
            row_222A4.enabled = True
            row_222A4.active = True
            row_222A4.use_property_split = False
            row_222A4.use_property_decorate = False
            row_222A4.scale_x = 1.0
            row_222A4.scale_y = 1.0
            row_222A4.alignment = 'Expand'.upper()
            row_222A4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_222A4.operator('sna.export_gltf_from_tagged_collection_8c21a', text='Tagged glTF', icon_value=0, emboss=True, depress=False)
            op = row_222A4.operator('sna.set_active_collection_as_export_17826', text='', icon_value=56, emboss=True, depress=False)
        col_F8545 = col_5BEAF.column(heading='', align=True)
        col_F8545.alert = False
        col_F8545.enabled = True
        col_F8545.active = True
        col_F8545.use_property_split = False
        col_F8545.use_property_decorate = False
        col_F8545.scale_x = 1.0
        col_F8545.scale_y = 1.0
        col_F8545.alignment = 'Expand'.upper()
        col_F8545.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_F8545.label(text='Format Options', icon_value=0)
        box_8E6AA = col_F8545.box()
        box_8E6AA.alert = False
        box_8E6AA.enabled = True
        box_8E6AA.active = True
        box_8E6AA.use_property_split = False
        box_8E6AA.use_property_decorate = False
        box_8E6AA.alignment = 'Expand'.upper()
        box_8E6AA.scale_x = 1.0
        box_8E6AA.scale_y = 1.0
        if not True: box_8E6AA.operator_context = "EXEC_DEFAULT"
        col_AB752 = box_8E6AA.column(heading='', align=False)
        col_AB752.alert = False
        col_AB752.enabled = True
        col_AB752.active = True
        col_AB752.use_property_split = False
        col_AB752.use_property_decorate = False
        col_AB752.scale_x = 1.0
        col_AB752.scale_y = 1.0
        col_AB752.alignment = 'Expand'.upper()
        col_AB752.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_97023 = col_AB752.row(heading='', align=False)
        row_97023.alert = False
        row_97023.enabled = True
        row_97023.active = True
        row_97023.use_property_split = False
        row_97023.use_property_decorate = False
        row_97023.scale_x = 1.0
        row_97023.scale_y = 1.0
        row_97023.alignment = 'Expand'.upper()
        row_97023.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_97023.prop(bpy.context.scene, 'sna_format_option', text='', icon_value=0, emboss=True)
        op = row_97023.operator('sna.clean_up_object_names_a4fb9', text='', icon_value=662, emboss=True, depress=False)
        if bpy.context.scene.sna_format_option == "REPLACE":
            col_475DF = col_AB752.column(heading='', align=False)
            col_475DF.alert = False
            col_475DF.enabled = True
            col_475DF.active = True
            col_475DF.use_property_split = False
            col_475DF.use_property_decorate = False
            col_475DF.scale_x = 1.0
            col_475DF.scale_y = 1.0
            col_475DF.alignment = 'Expand'.upper()
            col_475DF.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_475DF.prop(bpy.context.scene, 'sna_find_text', text='Find', icon_value=0, emboss=True)
            col_475DF.prop(bpy.context.scene, 'sna_replace_text', text='Replace', icon_value=0, emboss=True)
        else:
            col_AB752.prop(bpy.context.scene, 'sna_format_text', text='', icon_value=0, emboss=True)
        row_7680B = col_AB752.row(heading='', align=True)
        row_7680B.alert = False
        row_7680B.enabled = True
        row_7680B.active = True
        row_7680B.use_property_split = False
        row_7680B.use_property_decorate = False
        row_7680B.scale_x = 1.0
        row_7680B.scale_y = 1.0
        row_7680B.alignment = 'Expand'.upper()
        row_7680B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_7680B.operator('sna.run_format_48bc3', text='Format', icon_value=0, emboss=True, depress=False)
        row_7680B.prop(bpy.context.scene, 'sna_auto_clean_names', text='', icon_value=202, emboss=True)
        col_BE8D4 = col_5BEAF.column(heading='', align=False)
        col_BE8D4.alert = False
        col_BE8D4.enabled = True
        col_BE8D4.active = True
        col_BE8D4.use_property_split = False
        col_BE8D4.use_property_decorate = False
        col_BE8D4.scale_x = 1.0
        col_BE8D4.scale_y = 1.0
        col_BE8D4.alignment = 'Expand'.upper()
        col_BE8D4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_BE8D4.label(text='Save Path', icon_value=0)
        col_BE8D4.prop(bpy.context.scene, 'sna_export_path', text='', icon_value=0, emboss=True)
        col_BE8D4.prop(bpy.context.scene, 'sna_use_active_name', text=('Use Active Name' if bpy.context.scene.sna_use_active_name else 'Use Collection Name'), icon_value=0, emboss=True, toggle=True)


class SNA_OT_Info_For_Ue_Exports_7Cb33(bpy.types.Operator):
    bl_idname = "sna.info_for_ue_exports_7cb33"
    bl_label = "Info for UE Exports"
    bl_description = "More information on exporting to Unreal Engine"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.wm.call_menu(name="SNA_MT_55AC9")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Info_For_Godot_Exports_D1276(bpy.types.Operator):
    bl_idname = "sna.info_for_godot_exports_d1276"
    bl_label = "Info for Godot Exports"
    bl_description = "More information on exporting to Godot"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.wm.call_menu(name="SNA_MT_6F70B")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_topbar_mt_editor_menus_9FF35(self, context):
    if not ((not 'OBJECT'==bpy.context.mode)):
        layout = self.layout
        if bpy.context.preferences.addons[__package__].preferences.sna_show_exports_in_header:
            row_CA2F7 = layout.row(heading='', align=False)
            row_CA2F7.alert = False
            row_CA2F7.enabled = True
            row_CA2F7.active = True
            row_CA2F7.use_property_split = False
            row_CA2F7.use_property_decorate = False
            row_CA2F7.scale_x = 1.0
            row_CA2F7.scale_y = 1.0
            row_CA2F7.alignment = 'Expand'.upper()
            row_CA2F7.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_CA2F7.separator(factor=0.0)
            row_CA2F7.popover('SNA_PT_EXPORT_1A2A0', text='Export', icon_value=0)
            row_CA2F7.separator(factor=0.0)


class SNA_OT_Clean_Up_Object_Names_A4Fb9(bpy.types.Operator):
    bl_idname = "sna.clean_up_object_names_a4fb9"
    bl_label = "Clean Up Object Names"
    bl_description = "Will format the object names of selected items to remove spaces and change . to _. Will also name mesh names in objects of to have the _Mesh suffix. "
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('rename_selected_objects()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Format_Option_F756A(bpy.types.Operator):
    bl_idname = "sna.set_format_option_f756a"
    bl_label = "Set Format Option"
    bl_description = "Set the Format Option to Prefix, Suffix, or Replace. Replace option will replace the entire name of each selected mesh and append a number based on its order in the selection."
    bl_options = {"REGISTER", "UNDO"}
    sna_option: bpy.props.StringProperty(name='option', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_format_option = self.sna_option
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Run_Format_48Bc3(bpy.types.Operator):
    bl_idname = "sna.run_format_48bc3"
    bl_label = "Run Format"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('rename_selected_objects(True)')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Set_Active_Collection_As_Export_17826(bpy.types.Operator):
    bl_idname = "sna.set_active_collection_as_export_17826"
    bl_label = "Set Active Collection as Export"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('set_active_collection_as_export()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Export_Static_Gltf_For_Godot_8E1D6(bpy.types.Operator):
    bl_idname = "sna.export_static_gltf_for_godot_8e1d6"
    bl_label = "Export Static glTF for Godot"
    bl_description = "Exports only selected mesh and populates settings for Godot. Recommended file format. Good for batches."
    bl_options = {"REGISTER", "UNDO"}
    sna_meshes_only: bpy.props.BoolProperty(name='meshes_only', description='', options={'HIDDEN'}, default=False)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        meshes_only = self.sna_meshes_only
        can_export = None

        def filter_selected_by_mesh(meshes_only=False):
            """
            If meshes_only is True, deselects any selected object that isn't a MESH.
            If the active object gets deselected in the process, a remaining
            selected object (if any) is promoted to active.
            Returns True if any objects remain selected afterward.
            """
            if meshes_only:
                for obj in bpy.context.selected_objects:
                    if obj.type != 'MESH':
                        obj.select_set(False)
            remaining = bpy.context.selected_objects
            active_obj = bpy.context.view_layer.objects.active
            if remaining and active_obj not in remaining:
                bpy.context.view_layer.objects.active = remaining[0]
            return len(remaining) > 0
        active_obj = getattr(bpy.context.view_layer.objects, "active", None)
        if not active_obj:
            print(f"Warning: No Active Object")
            self.report({'WARNING'}, "No Active Object found!")
            can_export = False
            return {'CANCELLED'}
        if filter_selected_by_mesh(meshes_only):
            can_export = True
        else:
            can_export = False
        if can_export:
            bpy.ops.export_scene.gltf('INVOKE_DEFAULT', filepath=sna_getpath_500BE(False), export_image_format=('AUTO' if bpy.context.scene.sna_embed_image else 'NONE'), export_materials='EXPORT', export_cameras=(not self.sna_meshes_only), use_selection=True, export_apply=True, export_animations=False, export_lights=(not self.sna_meshes_only))
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Export_Animated_Mesh_And_Armature_Gltf_For_Godot_8E082(bpy.types.Operator):
    bl_idname = "sna.export_animated_mesh_and_armature_gltf_for_godot_8e082"
    bl_label = "Export Animated Mesh and Armature glTF for Godot"
    bl_description = "Exports only selected meshes and actions and populates settings for Godot. Mesh and actions are all in the same file and don't need to be exported seperately. Select Mesh then Armature as the active object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        can_export = None

        def can_export_anim_mesh():
            """
            Validates that exactly a mesh + its armature are selected,
            with the armature as the active object.
            """
            active_obj = getattr(bpy.context.view_layer.objects, "active", None)
            selected = list(bpy.context.view_layer.objects.selected)
            if active_obj is None or active_obj.type != 'ARMATURE':
                return False
            if len(selected) != 2:
                return False
            other_objs = [obj for obj in selected if obj != active_obj]
            if len(other_objs) != 1 or other_objs[0].type != 'MESH':
                return False
            return True
        active_obj = getattr(bpy.context.view_layer.objects, "active", None)
        if not active_obj:
            print(f"Warning: No Active Object")
            self.report({'WARNING'}, "No Active Object found!")
            can_export = False
            return {'CANCELLED'}
        if can_export_anim_mesh():
            can_export = True
        else:
            self.report({'WARNING'}, "Select a mesh and its armature (active object) to export.")
            can_export = False
        if can_export:
            bpy.ops.export_scene.gltf('INVOKE_DEFAULT', filepath=sna_getpath_500BE(True), export_image_format=('AUTO' if bpy.context.scene.sna_embed_image else 'NONE'), export_materials='EXPORT', use_selection=True, export_apply=True, export_animations=True, export_animation_mode='ACTIONS', export_def_bones=True, export_bake_animation=True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Export_Animated_Armature_Only_Gltf_For_Godot_Ebe70(bpy.types.Operator):
    bl_idname = "sna.export_animated_armature_only_gltf_for_godot_ebe70"
    bl_label = "Export Animated Armature Only glTF for Godot"
    bl_description = "Exports only Armature and actions and populates settings for Godot. Select Armature only as the active object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        can_export = None

        def can_export_armature_selection():
            """
            Validates that the active object is an armature.
            """
            active_obj = getattr(bpy.context.view_layer.objects, "active", None)
            return active_obj is not None and active_obj.type == 'ARMATURE'
        active_obj = getattr(bpy.context.view_layer.objects, "active", None)
        if not active_obj:
            print(f"Warning: No Active Object")
            self.report({'WARNING'}, "No Active Object found!")
            can_export = False
            return {'CANCELLED'}
        if can_export_armature_selection():
            can_export = True
        else:
            self.report({'WARNING'}, "Select armature only as (active object) to export.")
            can_export = False
        if can_export:
            bpy.ops.export_scene.gltf('INVOKE_DEFAULT', filepath=sna_getpath_500BE(True), export_image_format=('AUTO' if bpy.context.scene.sna_embed_image else 'NONE'), export_materials='EXPORT', use_selection=True, export_apply=True, export_animations=True, export_animation_mode='ACTIONS', export_def_bones=True, export_bake_animation=True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Export_Static_Obj_For_Godot_71B7B(bpy.types.Operator):
    bl_idname = "sna.export_static_obj_for_godot_71b7b"
    bl_label = "Export Static OBJ for Godot"
    bl_description = "Exports only selected mesh and populates settings for Godot. Better for single one off meshes"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (bpy.context.view_layer.objects.active.type == 'MESH' and property_exists("bpy.context.view_layer.objects.active", globals(), locals()) and (len(list(bpy.context.view_layer.objects.selected)) < 2)):
            bpy.ops.wm.obj_export('INVOKE_DEFAULT', filepath=sna_getpath_500BE(True), export_selected_objects=True, export_materials=False)
        else:
            bpy.ops.wm.call_menu(name="SNA_MT_D70D0")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_MT_D70D0(bpy.types.Menu):
    bl_idname = "SNA_MT_D70D0"
    bl_label = "SELECTION ERROR"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.operator_context = "INVOKE_DEFAULT"
        layout.label(text='Select only 1 mesh object as active', icon_value=0)


class SNA_OT_Export_Gltf_From_Tagged_Collection_8C21A(bpy.types.Operator):
    bl_idname = "sna.export_gltf_from_tagged_collection_8c21a"
    bl_label = "Export GlTF from Tagged Collection"
    bl_description = "Will automatically select and export objects in the first collection with the _export or _Export suffix"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        formatted_file_path = None
        activate_and_select_export_collection()
        if context.scene.sna_auto_clean_names:
            rename_selected_objects()
        formatted_file_path = get_file_path_for_tagged_collection()
        bpy.ops.export_scene.gltf('INVOKE_DEFAULT', filepath=formatted_file_path, export_image_format=('AUTO' if bpy.context.scene.sna_embed_image else 'NONE'), export_materials='EXPORT', use_selection=True, export_apply=True, export_animations=False)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_getpath_500BE(force_use_active):
    force_use_active = force_use_active
    path = None

    def get_file_path_name(sna_use_active_name=True):
        """
        Builds the export file path using either the active object's name 
        or its collection's name.
        """
        source_name = None
        if sna_use_active_name:
            active_obj = getattr(bpy.context.view_layer.objects, "active", None)
            if active_obj:
                source_name = active_obj.name
            else:
                # Global UI warning without needing 'self' or 'operator'
                bpy.ops.wm.report_id(
                    'EXEC_DEFAULT', 
                    type={'WARNING'}, 
                    message="No Active Object found, defaulting to collection name."
                )
                active_collection = bpy.context.view_layer.active_layer_collection.collection
                if active_collection:
                    source_name = active_collection.name
        if not source_name:
            active_collection = bpy.context.view_layer.active_layer_collection.collection
            if active_collection:
                source_name = active_collection.name
            else:
                source_name = "Untitled"
        formatted_name = source_name.replace(' ', '').replace('.', '_')
        input_path = bpy.context.scene.sna_export_path
        final_path = bpy.path.abspath(input_path) + formatted_name
        return final_path
    if force_use_active:
        path = get_file_path_name(True)
    else:
        path = get_file_path_name(bpy.context.scene.sna_use_active_name)
    return path


class SNA_MT_55AC9(bpy.types.Menu):
    bl_idname = "SNA_MT_55AC9"
    bl_label = "UE Export Info"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.operator_context = "INVOKE_DEFAULT"
        layout.label(text='CHECKLIST', icon_value=8)
        layout.label(text='Object origin is centered in world', icon_value=4)
        layout.label(text='Transforms applied', icon_value=4)
        layout.label(text='ANIMATIONS', icon_value=227)
        layout.label(text="Armature object and armature (parent of first bone) should both be named 'Root'", icon_value=69)
        layout.label(text="(UE) On import in engine, the animation's 'Import Uniform Scale' might need to be 100 vs 1", icon_value=69)
        layout.label(text='(UE/ARP) Be sure the same action is active on both ARP rig and export rig, then select export rig and export with Compendium preset', icon_value=69)
        layout.label(text="(ARP) If the exported rig's animation are not lining up with the animations from Blender: ", icon_value=69)
        layout.label(text='    - Set both the export rig and the ARP rig to rest position in Pose Mode', icon_value=0)
        layout.label(text='    - Select all and clear/reset transforms (alt + r)', icon_value=0)
        layout.label(text='    - Select all and apply Pose as Rest Pose (ctrl + a) or maybe apply other things in that menu ¯\_(ツ)_/¯', icon_value=0)
        layout.label(text='NOTES', icon_value=215)
        layout.label(text='Everything can be exported from Blender with Metric as the Unit System and Unit Scale set to 1.00', icon_value=69)
        layout.label(text='Lining up static objects (like the bow in the hand), you can copy the trasforms but  invert the rotation y and z (ex. y 10d in Blender is y -10 in UE5)', icon_value=69)
        layout.label(text='    - Should try playing with export settings XYZ to get better results', icon_value=0)
        layout.label(text='Have not found this makes a difference but you could try setting Units > Length > Centemeter (vs Meters)', icon_value=69)
        layout.label(text='For batch export of static mesh: ', icon_value=69)
        layout.label(text='    - Select all and export them into 1 FBX file', icon_value=0)
        layout.label(text='    - Be sure they are aligned to the world origin', icon_value=0)
        layout.label(text="    - In UE, uncheck 'Combine Meshes' during import to have each mesh seperated in UE", icon_value=0)
        op = layout.operator('sna.browerlinksforueexports_67489', text='(Open Brower) Sources for info on exporting to UE', icon_value=0, emboss=True, depress=False)


class SNA_OT_Browerlinksforueexports_67489(bpy.types.Operator):
    bl_idname = "sna.browerlinksforueexports_67489"
    bl_label = "BrowerLinksForUEExports"
    bl_description = "Browser popup for more info on exporting to UE"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('bpy.ops.wm.url_open(url="https://www.reddit.com/r/unrealengine/comments/zzv6ej/imported_bone_transform_is_different_from/")')
        exec('bpy.ops.wm.url_open(url="https://forums.unrealengine.com/t/blender-to-ue4-import-error-imported-bone-transform-is-different-from-original/138274/9")')
        exec('bpy.ops.wm.url_open(url="https://www.reddit.com/r/unrealengine/comments/r1uacc/need_help_warning_imported_bone_transform_is/")')
        exec('bpy.ops.wm.url_open(url="https://www.reddit.com/r/unrealengine/comments/v4nogy/imported_animations_make_mesh_incredibly_small/")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Browerlinksforgodotexports_Fc190(bpy.types.Operator):
    bl_idname = "sna.browerlinksforgodotexports_fc190"
    bl_label = "BrowerLinksForGodotExports"
    bl_description = "Browser popup for more info on exporting to Godot"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('bpy.ops.wm.url_open(url="https://www.youtube.com/watch?v=_eIAl_HZWXM")')
        exec('bpy.ops.wm.url_open(url="https://docs.godotengine.org/en/stable/tutorials/assets_pipeline/importing_3d_scenes/available_formats.html#importing-obj-files-in-godot")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_MT_6F70B(bpy.types.Menu):
    bl_idname = "SNA_MT_6F70B"
    bl_label = "Godot Export Info"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.operator_context = "INVOKE_DEFAULT"
        layout.label(text='CHECKLIST', icon_value=8)
        layout.label(text='Godot uses +Y as forward. Face toward +Y and apply rotation.', icon_value=4)
        layout.label(text='If your using the Export Tagged workflow, very last part of the collection name MUST be _export or _Export with nothing after it. ', icon_value=4)
        layout.label(text='ANIMATIONS', icon_value=227)
        layout.label(text='End Key Frame property is bigger or the same as the full anim', icon_value=69)
        layout.label(text='The -loop suffix will autoconfigure the anim to loop', icon_value=69)
        layout.label(text='- Animations are tied to the glTF file in Godot so you need to set looping on import. Settings > Loop Mode > Loop', icon_value=0)
        layout.label(text="- Also the anims can be edited in Godot so you'll need to edit them in Blender then Reimport", icon_value=0)
        layout.label(text='NOTES', icon_value=215)
        layout.label(text='In Godot, if you want a glFT to share the same material', icon_value=69)
        layout.label(text='- Open a model(glTF) that has the texture you want to share/save', icon_value=0)
        layout.label(text='- Actions > Extract Material > Select Folder > Select Material > Extract(bottom left) > Reimport', icon_value=0)
        layout.label(text='- Open model(s) you want to add this texture to', icon_value=0)
        layout.label(text='- In Materials tab > Enable Use External (right) > Select your .tres material you just created ', icon_value=0)
        layout.label(text='- In Scene tab(object still open) > Select root Scene > Set Embedded Image to Discard All Textures(right, in glTF section) > Reimport(bottom left)', icon_value=0)
        layout.label(text='- Can remove dup textures used for other models', icon_value=0)
        layout.label(text='Glb files are recommended and REQUIRED if skeltal mesh with anims', icon_value=69)
        layout.label(text='- If you need individual .mesh files', icon_value=0)
        layout.label(text='    - Double click/open glb file after dragging into Godot', icon_value=0)
        layout.label(text='    - Actions(top Left) > Set Mesh Save Paths > (Select directory for .mesh files)', icon_value=0)
        op = layout.operator('sna.browerlinksforgodotexports_fc190', text='(Open Brower) Sources for info on exporting to Godot', icon_value=0, emboss=True, depress=False)


class SNA_OT_Quickexport_8Dd7B(bpy.types.Operator):
    bl_idname = "sna.quickexport_8dd7b"
    bl_label = "QuickExport"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.scene.sna_quick_export_default == "UE5 Static":
            bpy.ops.sna.export_fbx_static_mesh_for_ue_6ea59('INVOKE_DEFAULT', )
        elif bpy.context.scene.sna_quick_export_default == "Godot Static":
            bpy.ops.sna.export_static_gltf_for_godot_8e1d6('INVOKE_DEFAULT', sna_meshes_only=False)
        else:
            pass
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Export_Fbx_Static_Mesh_For_Ue_6Ea59(bpy.types.Operator):
    bl_idname = "sna.export_fbx_static_mesh_for_ue_6ea59"
    bl_label = "Export FBX Static Mesh for UE"
    bl_description = "Exports only selected meshes and populates settings for UE"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (bpy.context.view_layer.objects.active.type == 'MESH' and property_exists("bpy.context.view_layer.objects.active", globals(), locals())):
            bpy.ops.export_scene.fbx('INVOKE_DEFAULT', filepath='', use_selection=True, apply_unit_scale=True, use_space_transform=True, object_types={'MESH'}, mesh_smooth_type='FACE', bake_anim=False, axis_forward='X', axis_up='Z')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Export_Fbx_Skeletal_Mesh_A08Cf(bpy.types.Operator):
    bl_idname = "sna.export_fbx_skeletal_mesh_a08cf"
    bl_label = "Export FBX Skeletal Mesh"
    bl_description = "Exports only mesh and armature. Select meshes then armature last as active. UE > Check Skeletal Mesh > Check Mesh > Uncheck Animations"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (bpy.context.view_layer.objects.active.type == 'ARMATURE' and property_exists("bpy.context.view_layer.objects.active", globals(), locals()) and (len(list(bpy.context.view_layer.objects.selected)) == 2)):
            bpy.ops.export_scene.fbx('INVOKE_DEFAULT', filepath='', use_selection=True, apply_unit_scale=True, use_space_transform=True, object_types={'ARMATURE', 'MESH'}, mesh_smooth_type='FACE', add_leaf_bones=False, bake_anim=False, axis_forward='X', axis_up='Z')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Export_Fbx_Animation_Becb7(bpy.types.Operator):
    bl_idname = "sna.export_fbx_animation_becb7"
    bl_label = "Export FBX Animation"
    bl_description = "Exports armature and selected animation. Select meshes then armature last as active. UE > Uncheck Mesh > Select Skeletion from previous > Check Animations"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (bpy.context.view_layer.objects.active.type == 'ARMATURE' and property_exists("bpy.context.view_layer.objects.active", globals(), locals()) and (len(list(bpy.context.view_layer.objects.selected)) == 2)):
            bpy.ops.export_scene.fbx('INVOKE_DEFAULT', filepath='', use_selection=True, apply_unit_scale=True, use_space_transform=True, object_types={'ARMATURE'}, mesh_smooth_type='FACE', add_leaf_bones=False, bake_anim=True, bake_anim_use_all_bones=True, bake_anim_use_nla_strips=False, bake_anim_use_all_actions=False, bake_anim_force_startend_keying=True, bake_anim_simplify_factor=0.0, axis_forward='X', axis_up='Z')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_AddonPreferences_F218B(bpy.types.AddonPreferences):
    bl_idname = __package__
    sna_show_exports_in_header: bpy.props.BoolProperty(name='Show Exports in Header', description='', default=True)
    sna_displayunreal: bpy.props.BoolProperty(name='DisplayUnreal', description='', default=True)
    sna_displaygodot: bpy.props.BoolProperty(name='DisplayGodot', description='', default=True)

    def draw(self, context):
        if not (False):
            layout = self.layout 
            col_6BB35 = layout.column(heading='', align=False)
            col_6BB35.alert = False
            col_6BB35.enabled = True
            col_6BB35.active = True
            col_6BB35.use_property_split = False
            col_6BB35.use_property_decorate = False
            col_6BB35.scale_x = 1.0
            col_6BB35.scale_y = 1.0
            col_6BB35.alignment = 'Expand'.upper()
            col_6BB35.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_6BB35.prop(bpy.context.preferences.addons[__package__].preferences, 'sna_show_exports_in_header', text='Show Exports in Header', icon_value=0, emboss=True)
            col_6BB35.prop(bpy.context.preferences.addons[__package__].preferences, 'sna_displaygodot', text='Show Godot Options', icon_value=0, emboss=True)
            col_6BB35.prop(bpy.context.preferences.addons[__package__].preferences, 'sna_displayunreal', text='Show Unreal Options', icon_value=0, emboss=True)
            layout.prop(find_user_keyconfig('CBDE1'), 'type', text='Export Menu Shortcut', full_event=True)
            box_3BE65 = layout.box()
            box_3BE65.alert = False
            box_3BE65.enabled = True
            box_3BE65.active = True
            box_3BE65.use_property_split = False
            box_3BE65.use_property_decorate = False
            box_3BE65.alignment = 'Expand'.upper()
            box_3BE65.scale_x = 1.0
            box_3BE65.scale_y = 1.0
            if not True: box_3BE65.operator_context = "EXEC_DEFAULT"
            box_3BE65.label(text=sna_formatchangelog_2DFCA_90F56(), icon_value=0)
            col_6A13C = box_3BE65.column(heading='', align=False)
            col_6A13C.alert = False
            col_6A13C.enabled = True
            col_6A13C.active = True
            col_6A13C.use_property_split = False
            col_6A13C.use_property_decorate = False
            col_6A13C.scale_x = 1.0
            col_6A13C.scale_y = 1.0
            col_6A13C.alignment = 'Expand'.upper()
            col_6A13C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_6A13C.label(text='Update to 2.0 for B3D 5.2- Mostly intails rewriting all of the behind the scenes loc in python instead of Serpens Nodes', icon_value=69)
            col_6A13C.label(text='Overhauled the Export menu', icon_value=69)
            col_6A13C.label(text='Fixed: Icons for 5.2', icon_value=69)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_embed_image = bpy.props.BoolProperty(name='Embed Image', description='If true(highlighted), will embed images as materials in file', default=True)
    bpy.types.Scene.sna_quick_export_default = bpy.props.EnumProperty(name='Quick Export Default', description='', items=[('UE5 Static', 'UE5 Static', '', 0, 0), ('Godot Static', 'Godot Static', '', 0, 1)])
    bpy.types.Scene.sna_export_path = bpy.props.StringProperty(name='Export Path', description='Automatically open to path directory when selecting export option. If empty, the export path will be the same as the current working file.', default='', subtype='DIR_PATH', maxlen=0)
    bpy.types.Scene.sna_format_option = bpy.props.EnumProperty(name='format_option', description='', items=[('SUFFIX', 'SUFFIX', 'Adds Text as suffix to selected objects', 0, 0), ('PREFIX', 'PREFIX', 'Adds Text as prefix to selected objects', 0, 1), ('REPLACE', 'REPLACE', 'Replaces the names of selected objects with Text and appends numbered suffix.', 0, 2), ('RENAME', 'RENAME', '', 0, 3)])
    bpy.types.Scene.sna_format_text = bpy.props.StringProperty(name='format_text', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_find_text = bpy.props.StringProperty(name='find_text', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_replace_text = bpy.props.StringProperty(name='replace_text', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_auto_clean_names = bpy.props.BoolProperty(name='Auto Clean Names', description='If true, will automatically format names by replacing spaces and periods with underscores.', default=True)
    bpy.types.Scene.sna_use_active_name = bpy.props.BoolProperty(name='Use Active Name', description='Use Collection Name will auto populate the file name with active collections name. Use Active Name will use active objects name', default=True)
    bpy.utils.register_class(SNA_PT_GAMEEXPORTS_286E8)
    bpy.utils.register_class(SNA_OT_Copyposition_78E65)
    bpy.utils.register_class(SNA_OT_Copyrotation_0E3Bd)
    bpy.utils.register_class(SNA_OT_Copyscale_6C3F6)
    bpy.utils.register_class(SNA_OT_Godotaxis_600F1)
    bpy.utils.register_class(SNA_MT_13879)
    bpy.utils.register_class(SNA_AddonPreferences_F218B)
    bpy.utils.register_class(SNA_PT_EXPORT_1A2A0)
    bpy.utils.register_class(SNA_OT_Info_For_Ue_Exports_7Cb33)
    bpy.utils.register_class(SNA_OT_Info_For_Godot_Exports_D1276)
    bpy.types.TOPBAR_MT_editor_menus.append(sna_add_to_topbar_mt_editor_menus_9FF35)
    bpy.utils.register_class(SNA_OT_Clean_Up_Object_Names_A4Fb9)
    bpy.utils.register_class(SNA_OT_Set_Format_Option_F756A)
    bpy.utils.register_class(SNA_OT_Run_Format_48Bc3)
    bpy.utils.register_class(SNA_OT_Set_Active_Collection_As_Export_17826)
    bpy.utils.register_class(SNA_OT_Export_Static_Gltf_For_Godot_8E1D6)
    bpy.utils.register_class(SNA_OT_Export_Animated_Mesh_And_Armature_Gltf_For_Godot_8E082)
    bpy.utils.register_class(SNA_OT_Export_Animated_Armature_Only_Gltf_For_Godot_Ebe70)
    bpy.utils.register_class(SNA_OT_Export_Static_Obj_For_Godot_71B7B)
    bpy.utils.register_class(SNA_MT_D70D0)
    bpy.utils.register_class(SNA_OT_Export_Gltf_From_Tagged_Collection_8C21A)
    bpy.utils.register_class(SNA_MT_55AC9)
    bpy.utils.register_class(SNA_OT_Browerlinksforueexports_67489)
    bpy.utils.register_class(SNA_OT_Browerlinksforgodotexports_Fc190)
    bpy.utils.register_class(SNA_MT_6F70B)
    bpy.utils.register_class(SNA_OT_Quickexport_8Dd7B)
    bpy.utils.register_class(SNA_OT_Export_Fbx_Static_Mesh_For_Ue_6Ea59)
    bpy.utils.register_class(SNA_OT_Export_Fbx_Skeletal_Mesh_A08Cf)
    bpy.utils.register_class(SNA_OT_Export_Fbx_Animation_Becb7)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_panel', 'S', 'PRESS',
        ctrl=True, alt=True, shift=True, repeat=False)
    kmi.properties.name = 'SNA_PT_EXPORT_1A2A0'
    kmi.properties.keep_open = True
    addon_keymaps['CBDE1'] = (km, kmi)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_use_active_name
    del bpy.types.Scene.sna_auto_clean_names
    del bpy.types.Scene.sna_replace_text
    del bpy.types.Scene.sna_find_text
    del bpy.types.Scene.sna_format_text
    del bpy.types.Scene.sna_format_option
    del bpy.types.Scene.sna_export_path
    del bpy.types.Scene.sna_quick_export_default
    del bpy.types.Scene.sna_embed_image
    bpy.utils.unregister_class(SNA_PT_GAMEEXPORTS_286E8)
    bpy.utils.unregister_class(SNA_OT_Copyposition_78E65)
    bpy.utils.unregister_class(SNA_OT_Copyrotation_0E3Bd)
    bpy.utils.unregister_class(SNA_OT_Copyscale_6C3F6)
    bpy.utils.unregister_class(SNA_OT_Godotaxis_600F1)
    bpy.utils.unregister_class(SNA_MT_13879)
    bpy.utils.unregister_class(SNA_AddonPreferences_F218B)
    bpy.utils.unregister_class(SNA_PT_EXPORT_1A2A0)
    bpy.utils.unregister_class(SNA_OT_Info_For_Ue_Exports_7Cb33)
    bpy.utils.unregister_class(SNA_OT_Info_For_Godot_Exports_D1276)
    bpy.types.TOPBAR_MT_editor_menus.remove(sna_add_to_topbar_mt_editor_menus_9FF35)
    bpy.utils.unregister_class(SNA_OT_Clean_Up_Object_Names_A4Fb9)
    bpy.utils.unregister_class(SNA_OT_Set_Format_Option_F756A)
    bpy.utils.unregister_class(SNA_OT_Run_Format_48Bc3)
    bpy.utils.unregister_class(SNA_OT_Set_Active_Collection_As_Export_17826)
    bpy.utils.unregister_class(SNA_OT_Export_Static_Gltf_For_Godot_8E1D6)
    bpy.utils.unregister_class(SNA_OT_Export_Animated_Mesh_And_Armature_Gltf_For_Godot_8E082)
    bpy.utils.unregister_class(SNA_OT_Export_Animated_Armature_Only_Gltf_For_Godot_Ebe70)
    bpy.utils.unregister_class(SNA_OT_Export_Static_Obj_For_Godot_71B7B)
    bpy.utils.unregister_class(SNA_MT_D70D0)
    bpy.utils.unregister_class(SNA_OT_Export_Gltf_From_Tagged_Collection_8C21A)
    bpy.utils.unregister_class(SNA_MT_55AC9)
    bpy.utils.unregister_class(SNA_OT_Browerlinksforueexports_67489)
    bpy.utils.unregister_class(SNA_OT_Browerlinksforgodotexports_Fc190)
    bpy.utils.unregister_class(SNA_MT_6F70B)
    bpy.utils.unregister_class(SNA_OT_Quickexport_8Dd7B)
    bpy.utils.unregister_class(SNA_OT_Export_Fbx_Static_Mesh_For_Ue_6Ea59)
    bpy.utils.unregister_class(SNA_OT_Export_Fbx_Skeletal_Mesh_A08Cf)
    bpy.utils.unregister_class(SNA_OT_Export_Fbx_Animation_Becb7)
